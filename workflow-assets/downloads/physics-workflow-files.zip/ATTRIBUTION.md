# Credits

The HyperSnips file adapts snippets from E. J. Mastnak and Gilles Castel, with later personal triggers and Windows command integration. Derivative/vector macros and layout ideas are adapted from Mastnak's published configurations. See https://ejmastnak.com/tutorials/vim-latex/intro/ and https://castel.dev/post/lecture-notes-1/ for original authorship and their published terms.

The figure workflow is inspired by https://castel.dev/post/lecture-notes-2/ and https://github.com/sleepymalc/VSCode-LaTeX-Inkscape. The Windows extension and fixed native presets are custom adaptations; they are not those authors' original software. Dependencies such as Inkscape, HyperSnips and LaTeX packages retain their own licences. This bundle does not change or grant a new licence for third-party material.
