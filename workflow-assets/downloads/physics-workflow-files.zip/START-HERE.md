# Physics notes workflow — Windows

Read the English tutorial first. Install VS Code, MiKTeX and Inkscape from their official sites and the listed VS Code extensions. Install the accompanying VSIX using Extensions: Install from VSIX.

Copy `.mastnak-snippets` into your notes folder. Copy the course starter and create its build folder. Update all `C:/path/to/...` settings and the `\incfig` path in `mastnak-stile.tex`. Merge editor settings and keyboard bindings into your existing files; do not blindly replace unrelated preferences. The installed VSIX carries command-box and figure shortcut bindings.

Inkscape presets have a separate INSTALL.md. Restart the applications after configuration. Build the sample lecture, then the main document. MiKTeX compilation and GUI shortcut verification must be done locally; neither is claimed as verified in this bundle.

The public snippet copy fixes visible braces for lrc. Other triggers are taken from the active personal file. The custom extension's interface messages are currently Italian, although the tutorial is English.
