# Install the native Inkscape presets on Windows

1. In Inkscape open Edit → Preferences → System. Find **User extensions**.
2. Close Inkscape after saving your work. Copy `castel_presets.py` and all `castel_*.inx` files into that user extensions folder. Copy files, not a nested folder. Use the Python/inkex runtime supplied by Inkscape.
3. Reopen Inkscape. The commands appear under Extensions → Appunti Castel. Try the library first.
4. For the prepared keys, open Edit → Preferences → Interface → Keyboard Shortcuts and import `physics-notes.xml`. Choose **Physics notes - Castel presets** as the keyboard file. This full map includes the standard native bindings. Importing a full map changes your current keyboard map; export a copy of any personalised map first. The author has not verified the key presses in the Windows interface yet.
5. If your build does not expose extension actions in this list, use the menu commands. `shortcuts.xml` lists the extension action bindings for a keymap; merge them with your existing keymap rather than replacing its native bindings. The native preset code is tested; this user-folder installation route and GUI shortcut assignment still need local verification.

The author's own portable installation uses its `share/inkscape/extensions` folder and a preserved copy of `share/inkscape/keys/default.xml` with these bindings merged. No Linux/X11 helper is required.
