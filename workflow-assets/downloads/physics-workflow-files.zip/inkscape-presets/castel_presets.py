#!/usr/bin/env python3
"""Native Inkscape effects: minimal mathematical objects and composable styles."""
import math
import inkex

OBJECTS = {
    'vertex': ('Vertice nero', '1'), 'axes2d': ('Assi xy', '2'),
    'axes3d': ('Assi xyz', '3'), 'sphere': ('Sfera con equatore', '4'),
    'circle': ('Cerchio vuoto', '7'), 'photon': ('Fotone', '8'),
    'gluon': ('Gluone', '9'), 'loop': ('Loop', '0'),
    'fermion': ('Fermione', 'j'),
    'manifold': ('Superficie curva con reticolo', None),
    'lightcone': ('Cono di luce', None), 'bloch': ('Sfera con assi e vettore', None),
    'cylinder': ('Cilindro', None), 'fermioncurve': ('Fermione curvo', None),
    'photoncurve': ('Fotone curvo', None), 'gluoncurve': ('Gluone curvo', None),
    'photonloop': ('Loop ondulato', None), 'gluonloop': ('Loop a spirale', None),
    'bubble': ('Diagramma a bolla', None), 'exchange': ('Scambio di un bosone', None),
    'doublewell': ('Potenziale a doppio pozzo', None),
}
STYLES = {
    'normal': ('Contorno sottile - ripristina', 's'),
    'thick': ('Contorno spesso', 'g'), 'verythick': ('Contorno molto spesso', 'h'),
    'dotted': ('Linea puntinata', 'p'), 'dashed': ('Linea tratteggiata', 'e'),
    'arrow': ('Freccia finale', 'l'), 'doublearrow': ('Frecce alle due estremita', 'y'),
    'noarrow': ('Togli frecce', 'x'), 'gray': ('Riempimento grigio chiaro', 'f'),
    'white': ('Riempimento bianco', 'w'), 'black': ('Riempimento nero', 'b'),
    'transparent': ('Nessun riempimento', 'r'),
}


def marker(svg):
    """Reuse only our own marker; avoid collisions with a user's similarly named object."""
    for candidate in svg.defs:
        if candidate.get('data-castel-preset') == 'open-arrow':
            return candidate.get_id()
    m = inkex.Marker()
    m.set('id', svg.get_unique_id('castel-arrow-'))
    m.set('data-castel-preset', 'open-arrow')
    for key, value in {'orient': 'auto-start-reverse', 'markerUnits': 'strokeWidth',
                       'refX': '0', 'refY': '0', 'markerWidth': '8',
                       'markerHeight': '8', 'viewBox': '-7 -4 8 8',
                       'style': 'overflow:visible'}.items():
        m.set(key, value)
    p = inkex.PathElement(d='M -5.4,-2.2 Q -4.5,-0.8 0,0 Q -4.5,0.8 -5.4,2.2')
    p.style = {'fill': 'none', 'stroke': '#000000', 'stroke-width': '0.9',
               'stroke-linecap': 'round', 'stroke-linejoin': 'round'}
    m.append(p)
    svg.defs.append(m)
    return m.get_id()


def shape(group, tag, **attributes):
    # Public inkex constructors keep elements editable with native shape tools.
    constructors = {'circle': inkex.Circle, 'ellipse': inkex.Ellipse, 'rect': inkex.Rectangle}
    el = constructors[tag]()
    for key, value in attributes.items():
        el.set(key.replace('_', '-'), str(value))
    group.append(el)
    return el


def path(group, d, **style):
    el = inkex.PathElement(d=d)
    el.style = {'fill': 'none', 'stroke': '#000000', 'stroke-width': '0.1411',
                'stroke-linecap': 'round', 'stroke-linejoin': 'round', **style}
    group.append(el)
    return el


def label(group, x, y, content):
    el = inkex.TextElement(x=str(x), y=str(y))
    el.text = content
    el.style = {'fill': '#000000', 'stroke': 'none', 'font-size': '3',
                'font-family': 'serif', 'text-anchor': 'middle'}
    group.append(el)
    return el


def sampled(group, points, **style):
    return path(group, 'M ' + ' L '.join(f'{x:.5f},{y:.5f}' for x, y in points), **style)


def propagator(group, kind, curved=False, angle=90, closed=False):
    if closed:
        count = 720; turns = 16
    else:
        count = 480; turns = 9 if kind == 'gluon' else 6
    points = []
    for i in range(count + 1):
        u = i / count
        if closed:
            phi = 2 * math.pi * u
            x, y = 14 * math.cos(phi), 14 * math.sin(phi)
            tx, ty, nx, ny = -math.sin(phi), math.cos(phi), math.cos(phi), math.sin(phi)
        elif curved:
            theta = math.radians(angle); radius = 22 / math.sin(theta/2)
            phi = (u - .5) * theta
            x, y = radius * math.sin(phi), radius * (math.cos(theta/2) - math.cos(phi))
            tx, ty, nx, ny = math.cos(phi), math.sin(phi), -math.sin(phi), math.cos(phi)
        else:
            x, y = -22 + 44*u, 0
            tx, ty, nx, ny = 1, 0, 0, 1
        phase = 2 * math.pi * turns * u
        if kind == 'photon':
            offset = 1.65 * math.sin(phase)
            x += nx*offset; y += ny*offset
        elif kind == 'gluon':
            tangent = (1.8 if closed else 1.15) * math.sin(phase)
            normal = (1.6 if closed else 2.1) * (1-math.cos(phase))
            x += tx*tangent + nx*normal; y += ty*tangent + ny*normal
        points.append((x,y))
    return sampled(group, points)


def make_object(svg, operation, angle=90):
    g = inkex.Group.new(OBJECTS[operation][0])
    g.set('id', svg.get_unique_id('castel-' + operation + '-'))
    g.set('data-castel-preset', operation)
    arrow = 'url(#' + marker(svg) + ')'
    if operation in ('axes2d', 'axes3d'):
        if operation == 'axes2d':
            path(g, 'M -22,16 H 23', **{'marker-end': arrow})
            path(g, 'M -16,22 V -22', **{'marker-end': arrow})
            label(g, 24, 20, '$x$'); label(g, -20, -23, '$y$')
        else:
            for d in ('M 0,0 L 22,8', 'M 0,0 L -17,13', 'M 0,0 L 0,-23'):
                path(g, d, **{'marker-end': arrow})
            label(g, 24, 11, '$x$'); label(g, -20, 16, '$y$'); label(g, 3, -25, '$z$')
    elif operation in ('sphere', 'bloch'):
        shape(g, 'circle', cx=0, cy=0, r=19,
              style='fill:none;stroke:#000000;stroke-width:0.1411')
        path(g, 'M -19,0 A 19,5.8 0 0 0 19,0')
        path(g, 'M -19,0 A 19,5.8 0 0 1 19,0', **{'stroke-dasharray': '0.8,0.8'})
        path(g, 'M 0,19 A 5.8,19 0 0 1 0,-19', **{'stroke-dasharray': '0.8,0.8'})
        path(g, 'M 0,19 A 5.8,19 0 0 0 0,-19')
        if operation == 'bloch':
            for d in ('M 0,0 L 25,0', 'M 0,0 L -12,17', 'M 0,0 L 0,-25', 'M 0,0 L 10,-14'):
                path(g, d, **{'marker-end': arrow})
            label(g, 27, 2, '$x$'); label(g,-15,20,'$y$'); label(g,3,-27,'$z$')
    elif operation in ('circle', 'vertex'):
        radius = 19 if operation == 'circle' else 0.6
        shape(g, 'circle', cx=0, cy=0, r=radius,
              style=('fill:none;stroke:#000000;stroke-width:0.1411'
                     if operation == 'circle' else 'fill:#000000;stroke:none'))
    elif operation == 'fermion':
        path(g, 'M -22,0 H 22')
        path(g, 'M -1,0 H 1', **{'marker-end': arrow})
    elif operation == 'photon':
        # Alternating cubic lobes with matching tangents, not a noisy freehand trace.
        parts = ['M -22,0']
        for i in range(12):
            x = -22 + i * 44 / 12; step = 44 / 12; sign = -1 if i % 2 == 0 else 1
            parts.append(f'C {x+step/3},{sign*2.6} {x+2*step/3},{sign*2.6} {x+step},0')
        path(g, ' '.join(parts))
    elif operation == 'gluon':
        # Projection of a helix. Loops stay editable as a single path.
        points = []
        for i in range(451):
            t = 18 * math.pi * i / 450
            x = -22 + 44 * i / 450 + 1.15 * math.sin(t)
            y = 2.1 * (1 - math.cos(t))
            points.append(f'{x:.5f},{y:.5f}')
        path(g, 'M ' + ' L '.join(points))
    elif operation == 'loop':
        path(g, 'M 14,0 A 14,14 0 1 1 -14,0 A 14,14 0 1 1 14,0')
    elif operation in ('photoncurve', 'gluoncurve', 'fermioncurve', 'photonloop', 'gluonloop'):
        kind = operation.replace('curve','').replace('loop','')
        propagator(g, kind, curved=operation.endswith('curve'), angle=angle, closed=operation.endswith('loop'))
        if kind == 'fermion':
            radius=22/math.sin(math.radians(angle)/2)
            y=radius*(math.cos(math.radians(angle)/2)-1)
            path(g,f'M -1,{y} H 1',**{'marker-end':arrow})
    elif operation == 'manifold':
        def project(u,v):
            z=.35*(u*u-v*v)
            return 18*u+10*v, 5*u+9*v-18*z
        border = []
        for side in range(4):
            for j in range(81):
                t=-1+2*j/80
                u,v=[(t,-1),(1,t),(-t,1),(-1,-t)][side]
                border.append(project(u,v))
        el=sampled(g,border,fill='#000000',**{'fill-opacity':'0.035'}); el.set('d',el.get('d')+' Z')
        for fixed in [-1+i/3 for i in range(7)]:
            for axis in (0,1):
                sampled(g,[project(fixed,-1+2*j/80) if axis==0 else project(-1+2*j/80,fixed)
                           for j in range(81)],**{'stroke-width':'0.085'})
    elif operation == 'cylinder':
        path(g,'M -15,-16 A 15,4.5 0 1 0 15,-16 A 15,4.5 0 1 0 -15,-16')
        path(g,'M -15,-16 V 16 M 15,-16 V 16')
        path(g,'M -15,16 A 15,4.5 0 0 0 15,16')
        path(g,'M -15,16 A 15,4.5 0 0 1 15,16',**{'stroke-dasharray':'0.8,0.8'})
    elif operation == 'lightcone':
        path(g,'M -18,-22 L 0,0 L 18,-22 M -18,22 L 0,0 L 18,22')
        for y in (-22,22):
            path(g,f'M -18,{y} A 18,5 0 0 0 18,{y}')
            path(g,f'M -18,{y} A 18,5 0 0 1 18,{y}',**{'stroke-dasharray':'0.8,0.8'})
        path(g,'M 0,0 V -31',**{'marker-end':arrow})
        path(g,'M 0,0 H 28',**{'marker-end':arrow})
        label(g,3,-31,'$ct$'); label(g,29,4,'$x$')
    elif operation == 'bubble':
        path(g,'M -28,0 H -12 M 12,0 H 28')
        path(g,'M -12,0 A 12,12 0 0 1 12,0 M -12,0 A 12,12 0 0 0 12,0')
        for x in (-12,12):
            shape(g,'circle',cx=x,cy=0,r=.6,style='fill:#000000;stroke:none')
    elif operation == 'exchange':
        for x,sign in [(-16,-1),(16,1)]:
            path(g,f'M {x+sign*14},-16 L {x},0 L {x+sign*14},16')
            shape(g,'circle',cx=x,cy=0,r=.6,style='fill:#000000;stroke:none')
        sub=inkex.Group(); sub.transform.add_scale(32/44,1); g.append(sub)
        propagator(sub,'photon')
    elif operation == 'doublewell':
        points=[]
        for j in range(201):
            t=-1.5+3*j/200; points.append((16*t,8-10*(t*t-1)**2))
        sampled(g,points)
        path(g,'M -28,9 H 29',**{'marker-end':arrow})
        path(g,'M 0,12 V -18',**{'marker-end':arrow})
        label(g,30,13,'$\\phi$'); label(g,5,-19,'$V$')
    return g


def selected_shapes(svg):
    seen = set()
    for selected in svg.selection.values():
        for el in selected.iter():
            if el in seen:
                continue
            seen.add(el)
            # Text labels, clip paths, groups and definitions keep their styles.
            if isinstance(el, inkex.ShapeElement) and el.tag not in (
                inkex.addNS('g', 'svg'), inkex.addNS('text', 'svg'),
                inkex.addNS('tspan', 'svg'), inkex.addNS('use', 'svg'),
            ) and not any(p.tag in (inkex.addNS('defs', 'svg'), inkex.addNS('clipPath', 'svg'))
                          for p in el.iterancestors()):
                yield el


def apply_style(svg, operation):
    elements = list(selected_shapes(svg))
    if not elements:
        raise inkex.AbortExtension('Seleziona prima una linea o una forma con F1.')
    arrow = 'url(#' + marker(svg) + ')' if operation in ('arrow', 'doublearrow') else None
    widths = {name: svg.unittouu(value) for name, value in
              [('normal', '0.4pt'), ('thick', '0.8pt'), ('verythick', '1.2pt')]}
    for el in elements:
        st = el.style
        transform = el.composed_transform()
        scale = max(1e-12, abs(transform.a * transform.d - transform.b * transform.c) ** .5)
        local_widths = {name: value / scale for name, value in widths.items()}
        if operation == 'normal':
            st.update({'fill': 'none', 'fill-opacity': '1', 'stroke': '#000000',
                       'stroke-opacity': '1', 'stroke-width': str(local_widths['normal']),
                       'stroke-dasharray': 'none', 'marker-start': 'none', 'marker-mid': 'none',
                       'marker-end': 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round'})
        elif operation in ('thick', 'verythick'):
            st.update({'stroke': '#000000', 'stroke-opacity': '1',
                       'stroke-width': str(local_widths[operation])})
        elif operation in ('dotted', 'dashed'):
            st.update({'stroke': '#000000', 'stroke-opacity': '1', 'stroke-linecap': 'round'})
            if el.specified_style().get('stroke-width') is None:
                st['stroke-width'] = str(local_widths['normal'])
            if operation == 'dotted':
                st['stroke-dasharray'] = f'0,{svg.unittouu("2.4pt") / scale}'
            else:
                gap = svg.unittouu('3pt') / scale; st['stroke-dasharray'] = f'{gap},{gap}'
        elif operation in ('arrow', 'doublearrow'):
            st.update({'stroke': '#000000', 'stroke-opacity': '1', 'marker-end': arrow,
                       'marker-start': arrow if operation == 'doublearrow' else 'none'})
        elif operation == 'noarrow':
            st.update({'marker-start': 'none', 'marker-mid': 'none', 'marker-end': 'none'})
        elif operation in ('gray', 'white', 'black', 'transparent'):
            fill = {'gray': '#000000', 'white': '#ffffff', 'black': '#000000', 'transparent': 'none'}[operation]
            st.update({'fill': fill, 'fill-opacity': '0.12' if operation == 'gray' else '1'})


class CastelPresets(inkex.EffectExtension):
    def add_arguments(self, pars):
        pars.add_argument('--operation', default='axes3d', choices=list(OBJECTS) + list(STYLES))
        pars.add_argument('--angle', type=float, default=90)
        pars.add_argument('--size', type=float, default=1)

    def effect(self):
        op = self.options.operation
        if op in STYLES:
            apply_style(self.svg, op)
            return
        angle = max(10,min(170,self.options.angle))
        size = max(.05,min(10,self.options.size))
        g = make_object(self.svg, op, angle)
        view = self.svg.get_viewbox()
        named = self.svg.namedview
        if named.get('inkscape:cx') is not None and named.get('inkscape:cy') is not None:
            center = named.center
        else:
            center = inkex.Vector2d(view[0] + view[2]/2, view[1] + view[3]/2)
        layer = self.svg.get_current_layer()
        placement = inkex.Transform()
        placement.add_translate(center.x, center.y)
        placement.add_scale(self.svg.unittouu('1mm') * size)
        # Drawing coordinates stay correct even inside a transformed current layer.
        g.transform = -layer.composed_transform() @ placement
        layer.append(g)


if __name__ == '__main__':
    CastelPresets().run()
