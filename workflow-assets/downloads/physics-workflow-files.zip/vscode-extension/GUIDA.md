# Comandi di matematica · guida pratica

## Aprire e usare

**Ctrl+Alt+M** apre la casella sul punto del cursore o sulla selezione. In modalità Insert puoi anche digitare **;;** (Shift+virgola due volte). Non digitare ;; sopra una selezione: apri con la scorciatoia per conservarla. **mq** apre la stessa casella con matrix(2x2) già scritto.

**Mentre scrivi compaiono i suggerimenti:** ↑/↓ sceglie, **Tab completa** il modello nella casella senza applicarlo. **Invio** completa un suggerimento selezionato oppure applica la riga “Applica al documento” quando il comando è completo; **Esc** annulla; **Ctrl+Z** annulla la modifica. **Tab / Shift+Tab** percorrono i campi della ricetta. Il collegamento jk di Vim dipende dalla tua configurazione: questi campi sono snippet nativi di VS Code.

I tre pulsanti della casella sono: **elenco** (cerca comando e descrizione), **occhio** (confronto prima/dopo, senza applicare), **libro** (questa guida). Puoi combinare comandi separandoli con un punto e virgola.

## Tre prove iniziali

### Matrice 4×4 e riquadro

1. In un file .tex apri la casella e scrivi matrix(4x4).
2. Riempi le celle con Tab. Con l'ultimo Tab esci dai campi.
3. Metti il cursore dentro la matrice; apri la casella con Ctrl+Alt+M.
4. Scrivi box(3x3)@1,1; vline@3; hline@3 e premi Invio.

Il riquadro usa TikZ + libreria fit: nessuna dipendenza da nicematrix. Sono necessarie due compilazioni per stabilizzare la posizione. Puoi aggiungere i separatori anche dopo il riquadro; aggiungi righe/colonne **prima** del riquadro. Matrici con celle unite, specifiche array complesse e NiceArray non vengono modificate automaticamente.

### Equazioni allineate

Seleziona questo testo e apri Ctrl+Alt+M → align(=):

```latex
E = T + V
p = mv
F = ma
```

Risultato:

$$
\begin{aligned}
E &= T+V \\
p &= mv \\
F &= ma
\end{aligned}
$$

### Misura in spazio degli impulsi

Scrivi measure(p,4). Il cursore si mette nell'integrando:

$$
\int \frac{\mathrm{d}^4p}{(2\pi)^4}\,\square
$$

measure(x,4,plain) genera invece una misura senza fattore di Fourier.

## Catalogo completo

| Comando | Effetto |
|---|---|
| `matrix(4x4)` | Matrice con 16 campi |
| `identity(4)` | Identità |
| `diag(a,b,c)` | Diagonale |
| `zero(4x4)` | Matrice nulla |
| `matrix(4x4,A_{ij})` | Elementi con indici |
| `blockdiag(A,B)` | Matrice a blocchi |
| `pauli(2)` | Matrice di Pauli |
| `metric(+---)` | Metrica di Minkowski |
| `gamma(0,dirac)` | Gamma: base Dirac o Weyl |
| `box(3x3)@1,1` | Riquadro sul blocco |
| `hline@3` | Linea dopo riga 3 |
| `vline@3` | Linea dopo colonna 3 |
| `row(add)@2` | Aggiunge una riga |
| `col(add)@2` | Aggiunge una colonna |
| `delim([])` | Parentesi quadre |
| `align(=)` | Allinea le righe sull’uguale |
| `env(align*)` | Cambia ambiente |
| `number(off)` | Disattiva numerazione |
| `box` | Riquadra la formula |
| `under("termine cinetico")` | Annotazione sotto |
| `over("ipotesi")` | Annotazione sopra |
| `above("=","!")` | Simbolo sopra un altro |
| `note("equilibrio")@right` | Nota a destra |
| `unwrap` | Rimuove il comando esterno |
| `color(blue)` | Colore della selezione |
| `measure(p,4)` | Misura d⁴p/(2π)⁴ |
| `measure(x,4,plain)` | Misura d⁴x |
| `onshell(p)` | Misura d³p/((2π)³2Eₚ) |
| `fourier(x,p,4)` | Fourier: segno configurabile |
| `delta(4,p-q)` | Delta di Dirac |
| `comm(A,B)` | Commutatore |
| `anticomm(A,B)` | Anticommutatore |
| `slash(p)` | Contrazione gamma·p |
| `diracbar(\psi)` | Barra di Dirac |
| `chiral(L)` | Proiettore chirale |
| `prop(scalar,p,m)` | Propagatore scalare (+---) |
| `prop(fermion,p,m)` | Propagatore fermionico (+---) |
| `action(4)` | Azione |
| `correlator` | Correlatore ordinato |
| `timeorder` | Ordinamento temporale |
| `normalorder` | Ordinamento normale |
| `dyson(t_0,t)` | Esponenziale di Dyson |
| `partial(S,T;V,N)` | Derivata a V,N fissati |
| `average(A)` | Valore medio |
| `fluct(A)` | Varianza |
| `trace(A)` | Traccia |
| `partition(canonical)` | Partizione canonica |
| `partition(grand)` | Gran-partizione |
| `rho(canonical)` | Matrice densità |
| `occupation(fermi)` | Distribuzione Fermi |
| `occupation(bose)` | Distribuzione Bose |
| `thermo(dU)` | Differenziale termodinamico |
| `label("eq:energia")` | Etichetta |
| `ref("eq:energia")` | Riferimento |
| `preview` | Anteprima matematica in tempo reale |
| `help` | Guida |
| `recipes` | Apri le ricette personali |

## Rappresentazioni e convenzioni

Il profilo iniziale usa metrica **(+---)**. prop(scalar,p,m) restituisce i/(p²−m²+iε); prop(fermion,p,m) restituisce i(γ^μp_μ+m)/(p²−m²+iε). Il fattore i è incluso: non è la convenzione di tutti i testi per il simbolo del propagatore. Cambiando metric a -+++ i due preset vengono bloccati per evitare di usare una formula del profilo sbagliato.

fourier(x,p,4) inserisce la trasformata inversa nella convenzione scelta, con misura d⁴p/(2π)⁴ e segno iniziale − nell'esponenziale. fourierSign può essere + o −. onshell(p) usa d³p/[(2π)³2E_p]. Unità naturali nei preset QFT; γ⁵=iγ⁰γ¹γ²γ³. gamma richiede sempre dirac oppure weyl; metric richiede sempre +--- oppure -+++.

thermo presume un sistema semplice con una sola specie, lavoro −p dV e nessun altro termine di lavoro. Le ricette scrivono formule: non calcolano né verificano fisicamente gli appunti.

## Annotazioni e selezione

under("termine cinetico") / over("ipotesi") applicano brace alla selezione oppure alla formula corrente. Per due righe usa under("prima riga\nseconda riga").

note("equilibrio")@right aggiunge una nota dopo la riga selezionata; senza selezione opera sulla riga corrente di align. Mantieni ogni riga della derivazione su una riga del sorgente. Il testo viene affiancato con spazio matematico; non impone un margine destro fisso.

label("eq:energia") aggiunge un'etichetta senza sostituire la formula. Richiede un ambiente numerato; le etichette duplicate nel file corrente sono rifiutate. Nei blocchi align seleziona solo la riga se devi decidere dove collocare manualmente una label.

unwrap elimina un ambiente completo o un comando selezionato con un solo argomento. Per trasformare un termine specifico selezionalo: senza selezione il bersaglio è la formula corrente, non un termine dedotto automaticamente.

## Ricette personali

Scrivi recipes nella casella. Si apre .mastnak-snippets/math-workflow.json, cercato nelle cartelle superiori al tuo .tex. Se scrivi altrove, imposta mastnak.math.recipesPath nelle impostazioni VS Code al percorso di quel file.

Esempi già presenti: boltz(E), phifour(\lambda/4!,\phi), finale. finale applica box; number(off) all'equazione corrente.

Ogni ricetta contiene description, parameters e **template** oppure **commands**. Nei template, \ deve essere scritto \\ nel JSON. I parametri sono indicati da ${1}, ${2}, ecc.; se omessi diventano campi da riempire. Non viene eseguito codice JavaScript o Python dal file delle ricette.

```json
"peso": {
  "description": "Peso di Boltzmann",
  "parameters": ["energia"],
  "template": "e^{-\\beta ${1}}"
}
```

## Anteprima matematica

Ctrl+Alt+P oppure preview nella casella apre il pannello matematico di LaTeX Workshop. Segue la formula corrente. Usa MathJax: i riquadri TikZ e altre macro LaTeX avanzate vanno controllati nel PDF compilato. L'occhio nella casella è invece un confronto del sorgente prima/dopo.

## Casi gestiti con prudenza

Il lettore riconosce parentesi graffe, commenti, comandi ed ambienti annidati; non espande macro arbitrarie. Una selezione incompleta può richiedere correzione prima di essere trasformata. Usa l'anteprima per strutture complesse. I diagrammi di Feynman, i preset specifici di gauge e le espansioni in modi complete non sono inclusi in questa versione.
