'use strict';
const S=require('./structure');
function args(s){const out=[];let start=0,depth=0,quote='',escape=false;
 for(let i=0;i<s.length;i++){const c=s[i];if(quote){if(c===quote&&!escape)quote='';escape=c==='\\'&&!escape;if(c!=='\\')escape=false;continue;}if(c==='"'||c==="'"){quote=c;continue;}if('({['.includes(c))depth++;if(')}]'.includes(c))depth--;if((c===','||c===';')&&!depth){out.push(s.slice(start,i).trim());start=i+1;}}
 if(depth||quote)throw Error('Completa parentesi e virgolette del comando.');out.push(s.slice(start).trim());return out.filter(Boolean).map(x=>/^(["']).*\1$/.test(x)?x.slice(1,-1):x);
}
function commands(s){let depth=0,q='',start=0,out=[];for(let i=0;i<s.length;i++){const c=s[i];if(q){if(c===q&&s[i-1]!=='\\')q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='(')depth++;if(c===')')depth--;if(c===';'&&!depth){out.push(s.slice(start,i).trim());start=i+1;}}if(depth||q)throw Error('Completa il comando.');out.push(s.slice(start).trim());return out.filter(Boolean).map(x=>{const m=/^([a-z][\w-]*)(?:\((.*)\))?(?:@(.+))?$/i.exec(x);if(!m)throw Error('Sintassi: nome(parametri)@bersaglio.');return {name:m[1].toLowerCase(),args:args(m[2]||''),at:m[3]};});}
function n(x,max=20){if(!/^\d+$/.test(x||'')||+x<1||+x>max)throw Error('Inserisci un intero da 1 a '+max+'.');return +x;}
function dims(x){const m=/^(\d+)x(\d+)$/.exec(x||'');if(!m)throw Error('Dimensioni: 4x4.');return [n(m[1]),n(m[2])];}
const slug=x=>{if(!/^[A-Za-z0-9:_.-]+$/.test(x||''))throw Error('Etichetta: usa lettere, numeri, : _ . -');return x;};
function recipe(c,conventions){const a=c.args,p=a[0]||'p',m=a[1]||'m';
 switch(c.name){
 case 'measure':{const d=a[1]||'4';if(!/^(?:[1-9]|[12]\d|d)$/.test(d))throw Error('Dimensione da 1 a 29, oppure d.');const plain=a[2]==='plain'||(!a[2]&&p==='x');return '\\int '+(plain?'\\mathrm{d}^{'+d+'}'+p:'\\frac{\\mathrm{d}^{'+d+'}'+p+'}{(2\\pi)^{'+d+'}}')+'\\, {{}}';}
 case 'onshell':return '\\int \\frac{\\mathrm{d}^3\\mathbf{'+p+'}}{(2\\pi)^3\\,2E_{'+p+'}}\\, {{}}';
 case 'delta':return '\\delta^{('+ (a[0]||'4') +')}\\!\\left('+ (a[1]||'p-q') +'\\right)';
 case 'comm':return '\\left['+(a[0]||'{{}}')+', '+(a[1]||'{{}}')+'\\right]';
 case 'anticomm':return '\\left\\{'+(a[0]||'{{}}')+', '+(a[1]||'{{}}')+'\\right\\}';
 case 'slash':return '\\gamma^\\mu '+p+'_\\mu';
 case 'diracbar':return (a[0]||'\\psi')+'^{\\dagger}\\gamma^0';
 case 'chiral':if(!['l','r'].includes((a[0]||'').toLowerCase()))throw Error('chiral(L) oppure chiral(R).');return '\\frac{1 '+(a[0].toLowerCase()==='l'?'-':'+')+' \\gamma^5}{2}';
 case 'prop':{if(conventions.metric!=='+---')throw Error('I propagatori pronti usano la metrica +---.');const kind=a[0],mom=a[1]||'p',mass=a[2]||'m';if(kind==='scalar')return '\\frac{i}{'+mom+'^2-'+mass+'^2+i\\epsilon}';if(kind==='fermion')return '\\frac{i(\\gamma^\\mu '+mom+'_\\mu+'+mass+')}{'+mom+'^2-'+mass+'^2+i\\epsilon}';throw Error('prop(scalar,p,m) oppure prop(fermion,p,m).');}
 case 'fourier':{const x=a[0]||'x',mom=a[1]||'p',d=a[2]||'4',sign=conventions.fourierSign==='+'?'+':'-';return '\\int \\frac{\\mathrm{d}^{'+d+'}'+mom+'}{(2\\pi)^{'+d+'}}\\,e^{'+sign+'i'+mom+'\\cdot '+x+'}\\,{{}}';}
 case 'action':return 'S=\\int \\mathrm{d}^{'+(a[0]||'4')+'}x\\,\\mathcal{L}';
 case 'correlator':return '\\langle 0|\\mathrm{T}\\!\\left\\{'+(a[0]||'{{}}')+'\\right\\}|0\\rangle';
 case 'timeorder':return '\\mathrm{T}\\!\\left\\{'+(a[0]||'{{}}')+'\\right\\}';
 case 'normalorder':return '\\mathopen{:}'+(a[0]||'{{}}')+'\\mathclose{:}';
 case 'dyson':return '\\mathrm{T}\\exp\\!\\left[-i\\int_{'+(a[0]||'t_0')+'}^{'+(a[1]||'t')+'}\\mathrm{d}t\\,H_I(t)\\right]';
 case 'partial':if(a.length<2)throw Error('partial(S,T;V,N)');return '\\left(\\frac{\\partial '+a[0]+'}{\\partial '+a[1]+'}\\right)'+(a.length>2?'_{'+a.slice(2).join(',')+'}':'');
 case 'average':return '\\left\\langle '+(a[0]||'{{}}')+' \\right\\rangle';
 case 'fluct':return '\\left\\langle '+(a[0]||'A')+'^2\\right\\rangle-\\left\\langle '+(a[0]||'A')+'\\right\\rangle^2';
 case 'trace':return '\\operatorname{Tr}\\!\\left('+(a[0]||'{{}}')+'\\right)';
 case 'partition':if(a[0]==='canonical')return 'Z=\\operatorname{Tr}\\!\\left(e^{-\\beta H}\\right)';if(a[0]==='grand')return '\\Xi=\\operatorname{Tr}\\!\\left(e^{-\\beta(H-\\mu N)}\\right)';throw Error('partition(canonical) oppure partition(grand)');
 case 'rho':if(a[0]!=='canonical')throw Error('rho(canonical)');return '\\rho=\\frac{e^{-\\beta H}}{Z}';
 case 'occupation':if(!['fermi','bose'].includes(a[0]))throw Error('occupation(fermi) oppure occupation(bose)');return '\\frac{1}{e^{\\beta('+ (a[1]||'\\varepsilon')+'-\\mu)}'+(a[0]==='fermi'?'+':'-')+'1}';
 case 'thermo':{const presets={dU:'\\mathrm{d}U=T\\,\\mathrm{d}S-p\\,\\mathrm{d}V+\\mu\\,\\mathrm{d}N',dF:'\\mathrm{d}F=-S\\,\\mathrm{d}T-p\\,\\mathrm{d}V+\\mu\\,\\mathrm{d}N',dG:'\\mathrm{d}G=-S\\,\\mathrm{d}T+V\\,\\mathrm{d}p+\\mu\\,\\mathrm{d}N',dH:'\\mathrm{d}H=T\\,\\mathrm{d}S+V\\,\\mathrm{d}p+\\mu\\,\\mathrm{d}N',dOmega:'\\mathrm{d}\\Omega=-S\\,\\mathrm{d}T-p\\,\\mathrm{d}V-N\\,\\mathrm{d}\\mu'};if(!presets[a[0]])throw Error('thermo(dU), dF, dG, dH oppure dOmega.');return presets[a[0]];}
 case 'label':return '\\label{'+slug(a[0])+'}';
 case 'above':return '\\overset{\\text{'+(a[1]||'!')+'}}{'+(a[0]||'=')+'}';
 case 'ref':return '\\eqref{'+slug(a[0])+'}';
 default:return null;
 }
}
const catalog=[
 ['matrix(4x4)','Matrice con 16 campi'],['identity(4)','Identità'],['diag(a,b,c)','Diagonale'],['zero(4x4)','Matrice nulla'],['matrix(4x4,A_{ij})','Elementi con indici'],['blockdiag(A,B)','Matrice a blocchi'],['pauli(2)','Matrice di Pauli'],['metric(+---)','Metrica di Minkowski'],['gamma(0,dirac)','Gamma: base Dirac o Weyl'],
 ['box(3x3)@1,1','Riquadro sul blocco'],['hline@3','Linea dopo riga 3'],['vline@3','Linea dopo colonna 3'],['row(add)@2','Aggiunge una riga'],['col(add)@2','Aggiunge una colonna'],['delim([])','Parentesi quadre'],
 ['align(=)','Allinea le righe sull’uguale'],['env(align*)','Cambia ambiente'],['number(off)','Disattiva numerazione'],['box','Riquadra la formula'],['under("termine cinetico")','Annotazione sotto'],['over("ipotesi")','Annotazione sopra'],['above("=","!")','Simbolo sopra un altro'],['note("equilibrio")@right','Nota a destra'],['unwrap','Rimuove il comando esterno'],['color(blue)','Colore della selezione'],
 ['measure(p,4)','Misura d⁴p/(2π)⁴'],['measure(x,4,plain)','Misura d⁴x'],['onshell(p)','Misura d³p/((2π)³2Eₚ)'],['fourier(x,p,4)','Fourier: segno configurabile'],['delta(4,p-q)','Delta di Dirac'],['comm','Commutatore'],['anticomm','Anticommutatore'],['slash(p)','Contrazione gamma·p'],['diracbar(\\psi)','Barra di Dirac'],['chiral(L)','Proiettore chirale'],['prop(scalar,p,m)','Propagatore scalare (+---)'],['prop(fermion,p,m)','Propagatore fermionico (+---)'],['action(4)','Azione'],['correlator','Correlatore ordinato'],['timeorder','Ordinamento temporale'],['normalorder','Ordinamento normale'],['dyson(t_0,t)','Esponenziale di Dyson'],
 ['partial(S,T;V,N)','Derivata a V,N fissati'],['average','Valore medio'],['fluct(A)','Varianza'],['trace','Traccia'],['partition(canonical)','Partizione canonica'],['partition(grand)','Gran-partizione'],['rho(canonical)','Matrice densità'],['occupation(fermi)','Distribuzione Fermi'],['occupation(bose)','Distribuzione Bose'],['thermo(dU)','Differenziale termodinamico'],['label("eq:energia")','Etichetta'],['ref("eq:energia")','Riferimento'],['preview','Anteprima matematica in tempo reale'],['help','Guida'],['recipes','Apri le ricette personali']
];
module.exports={args,commands,n,dims,slug,recipe,catalog};
