'use strict';
const fs=require('fs'),path=require('path');
function courseRoot(file){let d=path.dirname(file);for(let i=0;i<8;i++){if(fs.existsSync(path.join(d,'main.tex')))return d;const up=path.dirname(d);if(up===d)break;d=up;}throw Error('Apri una lezione di un corso con main.tex.');}
function name(s){if(!/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(s))throw Error('Nome: lettere, numeri, trattini; niente spazi.');return s;}
function locations(root,n){name(n);return {svg:path.join(root,'figures','inkscape',n+'.svg'),pdf:path.join(root,'build','inkscape',n+'.pdf'),tex:path.join(root,'build','inkscape',n+'.pdf_tex')};}
function template(){return '<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="120mm" height="80mm" viewBox="0 0 120 80"><rect x="0" y="0" width="120" height="80" fill="white" id="sfondo"/></svg>\n';}
function insertion(n){name(n);return '\\begin{figure}[htbp]\n  \\centering\n  \\incfig{'+n+'}\n  \\caption{${1}}\n  \\label{fig:'+n+'}\n\\end{figure}\n$0';}
function exportArgs(svg,pdf){return [svg,'--export-type=pdf','--export-latex','--export-area-drawing','--export-filename='+pdf];}
module.exports={courseRoot,name,locations,template,insertion,exportArgs};
