'use strict';
const vscode = require('vscode');
function activate(context) {
 const labels = new Set();
 function update(editor) {
  vscode.commands.executeCommand('setContext', 'mastnak.inkscapeLabel', !!editor && labels.has(editor.document.uri.toString()));
 }
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.figures.label', async () => {
  const document = await vscode.workspace.openTextDocument({language: 'latex', content: '$$'});
  labels.add(document.uri.toString());
  const editor = await vscode.window.showTextDocument(document, {preview: false});
  editor.selection = new vscode.Selection(new vscode.Position(0, 1), new vscode.Position(0, 1));
  update(editor);
 }));
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.figures.labelCopy', async () => {
  const editor = vscode.window.activeTextEditor;
  if (!editor || !labels.has(editor.document.uri.toString())) {
   await vscode.window.showWarningMessage('Apri prima “Mastnak: Etichetta LaTeX per Inkscape”.'); return;
  }
  const text = editor.document.getText().trim();
  if (!text || text === '$$') { await vscode.window.showWarningMessage('Scrivi prima l’etichetta.'); return; }
  await vscode.env.clipboard.writeText(text);
  await vscode.window.showInformationMessage('Etichetta copiata. In Inkscape: T, clic nel disegno, Ctrl+V.');
 }));
 context.subscriptions.push(vscode.window.onDidChangeActiveTextEditor(update),
  vscode.workspace.onDidCloseTextDocument(document => {labels.delete(document.uri.toString()); update(vscode.window.activeTextEditor); }));
 update(vscode.window.activeTextEditor);
}
module.exports = {activate};
