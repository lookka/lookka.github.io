'use strict';
const S=require('./structure'),R=require('./recipes');
const mathWrap=s=>'\\[\n'+s+'\n\\]';
function filled(rows,cols,f){return {rows:Array.from({length:rows},(_,i)=>Array.from({length:cols},(_,j)=>f(i+1,j+1))),delimiter:'b',hlines:[],vlines:[],spec:'',prefix:'',suffix:''};}
function matrixRecipe(c){const a=c.args;let m;
 if(['matrix','zero'].includes(c.name)){const [rows,cols]=R.dims(a[0]);let format=a[1];if(format&&!/^[A-Za-z]+_\{ij\}$/.test(format))throw Error('Modello supportato: A_{ij} (sostituisci A con il nome desiderato).');m=filled(rows,cols,(i,j)=>c.name==='zero'?'0':format?format.replace('{ij}','{'+i+j+'}'):'{{}}');}
 else if(c.name==='identity'){const k=R.n(a[0]);m=filled(k,k,(i,j)=>i===j?'1':'0');}
 else if(c.name==='diag'||c.name==='blockdiag'){if(!a.length||a.length>20)throw Error('Indica da 1 a 20 elementi diagonali.');m=filled(a.length,a.length,(i,j)=>i===j?a[i-1]:'0');}
 else if(c.name==='pauli'){const k=R.n(a[0],3);m=filled(2,2,(i,j)=>({1:[['0','1'],['1','0']],2:[['0','-i'],['i','0']],3:[['1','0'],['0','-1']]})[k][i-1][j-1]);}
 else if(c.name==='metric'){if(!['+---','-+++'].includes(a[0]))throw Error('metric(+---) oppure metric(-+++)');m=filled(4,4,(i,j)=>i===j?(a[0][i-1]==='+'?'1':'-1'):'0');}
 else if(c.name==='gamma'){
  if(!/^[01235]$/.test(a[0]||'')||!['dirac','weyl'].includes(a[1]))throw Error('gamma(0,dirac), gamma(1,weyl), … gamma(5,dirac).');
  const k=+a[0],basis=a[1];let values;
  if((k===0&&basis==='dirac')||(k===5&&basis==='weyl')){const sign=k===0?1:-1;values=filled(4,4,(i,j)=>i===j?String(i<=2?sign:-sign):'0').rows;}
  else if(k===0||k===5)values=filled(4,4,(i,j)=>Math.abs(i-j)===2?'1':'0').rows;
  else{const sig=({1:[['0','1'],['1','0']],2:[['0','-i'],['i','0']],3:[['1','0'],['0','-1']]})[k];values=filled(4,4,(i,j)=>{if(i<=2&&j>2)return sig[i-1][j-3];if(i>2&&j<=2){const x=sig[i-3][j-1];return x==='0'?'0':x.startsWith('-')?x.slice(1):'-'+x;}return '0';}).rows;}
  m={...filled(4,4,()=>''),rows:values};
 }else return null;
 return S.renderMatrix(m);
}
function matrixTarget(text,start,end){let t=S.target(text,start,end,'matrix');
 if(t.env){const p=/\\left(\\[A-Za-z]+|\\[{}]|[()[\]|.])\s*$/.exec(text.slice(0,t.start));const q=/^\s*\\right(\\[A-Za-z]+|\\[{}]|[()[\]|.])/.exec(text.slice(t.end));if(p&&q){t.start-=p[0].length;t.end+=q[0].length;t.text=text.slice(t.start,t.end);}}
 return t;
}
function parseMatrix(t){const m=S.matrix(t.text),p=/^\s*\\left(\\[A-Za-z]+|\\[{}]|[()[\]|.])\s*$/.exec(m.prefix),q=/^\s*\\right(\\[A-Za-z]+|\\[{}]|[()[\]|.])\s*$/.exec(m.suffix);
 if(p&&q){m.delimiter=({'[':'b','(':'p','|':'v','\\{':'B','\\Vert':'V','.':'none'})[p[1]];if(!m.delimiter)throw Error('Parentesi esterne non supportate.');m.prefix='';m.suffix='';}return m;
}
function region(c,rows,cols){const [h,w]=R.dims(c.args[0]);const at=/^(\d+),(\d+)$/.exec(c.at||'1,1');if(!at)throw Error('Bersaglio: @1,1.');const r=+at[1],col=+at[2];if(r<1||col<1||r+h-1>rows||col+w-1>cols)throw Error('Il riquadro supera i limiti della matrice.');return [r,col,h,w];}
function transformation(c,input,id){const a=c.args,s=input.trim();switch(c.name){
 case 'box':if(a.length)return null;return '\\boxed{'+S.unwrapMath(s)+'}';
 case 'under':case 'over':{const text=(a[0]||'').split('\\n').map(x=>x.replace(/[{}%$&#_^]/g,ch=>'\\'+ch)).join(' \\\\ ');if(!text)throw Error('Inserisci il testo dell’annotazione.');return '\\'+c.name+'brace{'+S.unwrapMath(s)+'}'+(c.name==='under'?'_':'^')+'{\\substack{\\text{'+text.replace(/ \\\\ /g,'} \\\\ \\text{')+'}}}';}
 case 'color':if(!/^[A-Za-z]+(?:!\d+(?:![A-Za-z]+)?)?$/.test(a[0]||''))throw Error('Colore: blue, red, blue!50, …');return '{\\color{'+a[0]+'}'+S.unwrapMath(s)+'}';
 case 'above':return '\\overset{\\text{'+(a[1]||'!')+'}}{'+(a[0]||'=')+'}';
 case 'unwrap':{const e=S.enclosing(s,0,s.length);if(e)return S.unwrapMath(s);const head=/^\\[A-Za-z]+\s*/.exec(s);if(!head||s[head[0].length]!=='{')throw Error('Seleziona un comando con un solo argomento, es. \\boxed{…}.');const g=S.groupAt(s,head[0].length);if(g.end!==s.length)throw Error('unwrap supporta un singolo argomento completo.');return g.text;}
 case 'env':{if(!/^[A-Za-z]+\*?$/.test(a[0]||''))throw Error('Nome ambiente: align*, equation, …');return '\\begin{'+a[0]+'}\n'+S.unwrapMath(s)+'\n\\end{'+a[0]+'}';}
 case 'align':{
  if((a[0]||'=')!=='=')throw Error('Al momento è supportato align(=).');let body=S.unwrapMath(s);const tok=S.scan(body);if(tok.some(t=>t.kind==='&'))return '\\begin{align*}\n'+body+'\n\\end{align*}';
  const rows=S.split(body,tok.some(t=>t.kind==='row')?'row':'\n').map(x=>x.trim()).filter(Boolean);
  if(!rows.length)throw Error('Seleziona le equazioni da allineare.');
  return '\\begin{align*}\n'+rows.map(x=>{const eq=S.scan(x).find(t=>t.kind==='=');return '  '+(eq?x.slice(0,eq.at).trimEnd()+' &'+x.slice(eq.at):'& '+x);}).join(' \\\\\n')+'\n\\end{align*}';
 }
 case 'number':{if(!['on','off'].includes(a[0]))throw Error('number(on) oppure number(off).');const e=S.enclosing(s,0,s.length);if(!e)throw Error('Serve un ambiente completo.');let name=e.name.replace(/\*$/,'');if(['displaymath','inline'].includes(name))name='equation';if(!/^(equation|align|alignat|gather|multline)$/.test(name))throw Error('Questo ambiente non supporta la numerazione.');if(a[0]==='off')name+='*';return '\\begin{'+name+'}\n'+S.unwrapMath(s)+'\n\\end{'+name+'}';}
 case 'delim':case 'hline':case 'vline':case 'row':case 'col':case 'matrixbox':return null;
 case 'note':{
  if(c.at!=='right'||!a[0])throw Error('note("testo")@right');
  if(/\\label\b|\\tag\b/.test(s))throw Error('Per la nota seleziona solo la riga, senza label/tag.');
  return s.replace(/\\\\\s*$/,'')+' \\qquad\\text{('+a[0]+')}'+(/\\\\\s*$/.test(s)?' \\\\':'');
 }
 default:return undefined;
}}
function replace(text,t,value){if(typeof text!=='string')text=text.text;return {text:text.slice(0,t.start)+value+text.slice(t.end),start:t.start,end:t.start+value.length};}
function plan(command,document,start,end,options={}){
 let cs=R.commands(command);if(!cs.length)throw Error('Scrivi un comando.');
 for(let depth=0;depth<8;depth++){let changed=false;cs=cs.flatMap(c=>{const p=options.personal?.[c.name];if(!p?.commands)return [c];changed=true;const expanded=p.commands.replace(/\$\{(\d+)\}/g,(_,i)=>c.args[+i-1]||'');return R.commands(expanded);});if(cs.length>64)throw Error('Ricetta troppo lunga.');if(!changed)break;if(depth===7)throw Error('Ricetta ricorsiva: massimo 8 livelli.');}
 let state={text:document,start,end},generated=false;const id=options.id||'mqbox';const conventions={metric:'+---',fourierSign:'-',...options.conventions};
 for(const c of cs){
  if(['preview','help','recipes'].includes(c.name)){if(cs.length!==1)throw Error('Questo comando va eseguito da solo.');return {action:c.name};}
  if(c.name==='label'){
   const label=R.slug(c.args[0]);if(state.text.includes('\\label{'+label+'}'))throw Error('Questa etichetta esiste già.');
   const e=S.enclosing(state.text,state.start,state.end,e=>/^(equation|align|gather|multline)\*?$/.test(e.name));if(!e)throw Error('Metti il cursore nell’equazione da etichettare.');if(e.name.endsWith('*'))throw Error('Attiva prima la numerazione con number(on).');
   state=replace(state,{start:e.bodyEnd,end:e.bodyEnd},'\n\\label{'+label+'}\n');continue;
  }
  let out=matrixRecipe(c);if(out===null)out=R.recipe(c,conventions);
  if(out===null&&options.personal&&options.personal[c.name]){const preset=options.personal[c.name];if(!preset.template||typeof preset.template!=='string')throw Error('Ricetta personale senza template.');out=preset.template.replace(/\$\{(\d+)\}/g,(_,i)=>c.args[+i-1]||'{{'+(preset.parameters?.[+i-1]||'campo')+'}}');}
  if(out!==null){generated=true;const inside=S.enclosing(state.text,state.start,state.end,e=>S.mathNames.test(e.name));if(!inside&&!['label','ref'].includes(c.name)&&!(cs.length>1&&state.end>state.start))out=mathWrap(out);state=replace(state,{start:state.start,end:state.end},out);continue;}
  if(['hline','vline','row','col','delim'].includes(c.name)||(c.name==='box'&&c.args.length)){
   let t;
   try{t=matrixTarget(state.text,state.start,state.end);}catch(e){if(c.name!=='delim')throw e;}
   if(t&&c.name==='delim'&&!S.environments(t.text).some(e=>/^(?:[bpBvV]?matrix|array)$/.test(e.name)))t=undefined;
   if(t){const m=parseMatrix(t);if(m.rows.flat().some(x=>/\\tikz|\\node/.test(x))&&['row','col'].includes(c.name))throw Error('Aggiungi righe/colonne prima del riquadro, per conservare i riferimenti delle celle.');
    if(c.name==='box'){
     const [r,col,h,w]=region(c,m.rows.length,m.rows[0].length),names=[];
     for(let i=r-1;i<r+h-1;i++)for(let j=col-1;j<col+w-1;j++){if(/\\tikz/.test(m.rows[i][j]))throw Error('Queste celle hanno già un riquadro.');const name=id+'-'+i+'-'+j;names.push('('+name+')');m.rows[i][j]='\\tikz[remember picture,baseline=('+name+'.base)] \\node[inner sep=1pt,outer sep=0pt] ('+name+') {$\\textstyle '+m.rows[i][j]+'$};';}
     m.suffix+='\n\\tikz[remember picture,overlay] \\node[draw,fit='+names.join('')+',inner sep=2pt] {};';
    }else if(c.name==='delim'){
     const d=({'[]':'b','()':'p','||':'v','{}':'B','none':'none'})[c.args[0]];if(!d)throw Error('delim([]), delim(()), delim(||), delim({}) oppure delim(none).');m.delimiter=d;
    }else if(c.name==='hline'||c.name==='vline'){
     const max=c.name==='hline'?m.rows.length-1:m.rows[0].length-1;if(max<1)throw Error('Non ci sono separatori interni.');const pos=R.n(c.at,max),key=c.name==='hline'?'hlines':'vlines';if(!m[key].includes(pos))m[key].push(pos);
    }else{
     if(c.args[0]!=='add')throw Error('row(add)@2 oppure col(add)@2');const isRow=c.name==='row',pos=R.n(c.at,isRow?m.rows.length:m.rows[0].length);if((isRow?m.rows.length:m.rows[0].length)>=20)throw Error('Limite: 20 celle per direzione.');
     if(isRow){m.rows.splice(pos,0,Array(m.rows[0].length).fill('{{}}'));m.hlines=m.hlines.map(x=>x>pos?x+1:x);}else{m.rows.forEach(r=>r.splice(pos,0,'{{}}'));m.vlines=m.vlines.map(x=>x>pos?x+1:x);m.spec='';}generated=true;
    }
    state=replace(state,t,S.renderMatrix(m));continue;
   }
   if(c.name==='delim'){const t=S.target(state.text,state.start,state.end),pairs={'[]':['[',']'],'()':['(',')'],'||':['|','|'],'{}':['\\{','\\}']},p=pairs[c.args[0]];if(!p)throw Error('Parentesi non riconosciute.');let body=S.unwrapMath(t.text);body=body.replace(/^\\left(?:\\[{}]|[()[\]|])\s*/,'').replace(/\s*\\right(?:\\[{}]|[()[\]|])$/,'');let value='\\left'+p[0]+body+'\\right'+p[1];if(t.env)value=t.env.open+'\n'+value+'\n'+t.env.close;state=replace(state,t,value);continue;}
  }
  let t;
  if(c.name==='note'){if(state.end===state.start){const e=S.enclosing(state.text,state.start,state.end,e=>S.mathNames.test(e.name));if(!e||!/^align\*?$/.test(e.name))throw Error('Seleziona la riga da annotare, oppure metti il cursore in una riga di align.');let a=state.text.lastIndexOf('\n',state.start-1)+1,b=state.text.indexOf('\n',state.start);if(b<0)b=state.text.length;t={start:a,end:b,text:state.text.slice(a,b)};}else t={start:state.start,end:state.end,text:state.text.slice(state.start,state.end)};}
  else t=S.target(state.text,state.start,state.end);
  out=transformation(c,t.text,options.id||'mqbox');
  if(out===undefined||out===null)throw Error('Comando sconosciuto: '+c.name+'. Apri i suggerimenti con il pulsante elenco.');
  if(t.env&&!['env','align','number','unwrap'].includes(c.name))out=t.env.open+'\n'+out+'\n'+t.env.close;
  if(c.name==='label'&&/\\label\{/.test(t.text))throw Error('Etichetta già presente.');
  state=replace(state,t,out);
 }
 let from=0;while(from<document.length&&from<state.text.length&&document[from]===state.text[from])from++;
 let oldEnd=document.length,newEnd=state.text.length;while(oldEnd>from&&newEnd>from&&document[oldEnd-1]===state.text[newEnd-1]){oldEnd--;newEnd--;}
 return {start:from,end:oldEnd,value:state.text.slice(from,newEnd),document:state.text,generated};
}
function snippet(value,generated){const escape=x=>x.replace(/\\/g,'\\\\').replace(/\$/g,'\\$').replace(/}/g,'\\}');if(!generated)return escape(value)+'$0';let i=1,last=0,result='';const re=/\{\{([^{}]*)\}\}/g;let m;while((m=re.exec(value))){result+=escape(value.slice(last,m.index))+'${'+i+++':'+''+'}';last=re.lastIndex;}return result+escape(value.slice(last))+'$0';}
module.exports={plan,snippet,matrixRecipe};
