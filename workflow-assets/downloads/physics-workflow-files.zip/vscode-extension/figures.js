'use strict';
const vscode=require('vscode'),fs=require('fs'),path=require('path'),cp=require('child_process'),C=require('./figures-core');
function activate(context){
 const roots=new Map(),timers=new Map(),queues=new Map(),out=vscode.window.createOutputChannel('Mastnak · Inkscape');context.subscriptions.push(out);
 function executable(){const configured=vscode.workspace.getConfiguration('mastnak.figures').get('inkscapePath');const candidates=[configured,path.join(process.env.USERPROFILE||'','Documents','Codex','Tools','Inkscape','bin','inkscape.exe'),'C:/Program Files/Inkscape/bin/inkscape.exe'];const p=candidates.find(p=>p&&fs.existsSync(p));if(!p)throw Error('Inkscape non trovato: configura mastnak.figures.inkscapePath.');return p;}
 function run(file,args){return new Promise((resolve,reject)=>cp.execFile(file,args,{windowsHide:true,timeout:60000,maxBuffer:4*1024*1024},(err,stdout,stderr)=>{if(stderr)out.appendLine(stderr.trim());if(err)reject(Error(stderr||err.message));else resolve(stdout);}));}
 async function exportOne(svg,compile=true){
  if(!vscode.workspace.isTrusted)throw Error('Apri il progetto come cartella attendibile prima di esportare.');
  const root=C.courseRoot(svg),n=path.basename(svg,'.svg'),f=C.locations(root,n);
  if(path.resolve(f.svg)!==path.resolve(svg))throw Error('La figura deve essere nella cartella figures/inkscape del corso.');
  const bin=executable();fs.mkdirSync(path.dirname(f.pdf),{recursive:true});
  const temp=fs.mkdtempSync(path.join(path.dirname(f.pdf),'.export-'));const pdf=path.join(temp,n+'.pdf'),tex=pdf+'_tex';
  try{await run(bin,C.exportArgs(svg,pdf));if(!fs.existsSync(pdf)||!fs.existsSync(tex))throw Error('Esportazione incompleta: controlla il disegno in Inkscape.');fs.renameSync(pdf,f.pdf);fs.renameSync(tex,f.tex);out.appendLine('Esportata '+n);}
  finally{fs.rmSync(temp,{recursive:true,force:true});}
  const editor=vscode.window.activeTextEditor;
  if(compile&&editor&&editor.document.languageId==='latex'&&vscode.workspace.getConfiguration('mastnak.figures').get('autoBuild',true)){try{if(C.courseRoot(editor.document.fileName)===root)await vscode.commands.executeCommand('latex-workshop.build');}catch(e){out.appendLine('Compilazione: '+e.message);}}
 }
 function enqueue(svg){const prev=queues.get(svg)||Promise.resolve();const next=prev.catch(()=>{}).then(()=>exportOne(svg)).catch(e=>{out.appendLine(e.message);vscode.window.showErrorMessage('Inkscape: '+e.message);});queues.set(svg,next);next.finally(()=>{if(queues.get(svg)===next)queues.delete(svg);});return next;}
 function changed(uri){const svg=uri.fsPath;clearTimeout(timers.get(svg));timers.set(svg,setTimeout(()=>{timers.delete(svg);enqueue(svg);},800));}
 function watch(root){if(roots.has(root))return;const w=vscode.workspace.createFileSystemWatcher(new vscode.RelativePattern(root,'figures/inkscape/*.svg'));roots.set(root,w);context.subscriptions.push(w,w.onDidCreate(changed),w.onDidChange(changed));}
 function fromEditor(){const e=vscode.window.activeTextEditor;if(!e||e.document.languageId!=='latex')throw Error('Apri il file .tex in cui vuoi inserire la figura.');const root=C.courseRoot(e.document.fileName);watch(root);return {editor:e,root};}
 async function pick(root){const dir=path.join(root,'figures','inkscape');if(!fs.existsSync(dir))throw Error('Non ci sono figure: usa “Mastnak: Crea figura Inkscape”.');const items=fs.readdirSync(dir).filter(n=>/\.svg$/i.test(n)).map(n=>n.slice(0,-4));if(!items.length)throw Error('Non ci sono figure SVG.');const n=await vscode.window.showQuickPick(items,{title:'Figure del corso'});return n&&C.locations(root,n);}
 function launch(svg){const child=cp.spawn(executable(),[svg],{detached:true,stdio:'ignore',windowsHide:false});child.on('error',e=>vscode.window.showErrorMessage(e.message));child.unref();}
 function register(id,fn){context.subscriptions.push(vscode.commands.registerCommand(id,async()=>{try{if(!vscode.workspace.isTrusted)throw Error('Prima apri una cartella attendibile.');await fn();}catch(e){vscode.window.showErrorMessage(e.message);}}));}
 register('mastnak.figures.create',async()=>{const {editor,root}=fromEditor();executable();const n=await vscode.window.showInputBox({title:'Nuova figura Inkscape',prompt:'Nome, per esempio diagramma-fasi',validateInput:s=>{try{C.name(s);if(fs.existsSync(C.locations(root,s).svg))return 'Esiste già: usa Apri figura.';}catch(e){return e.message;}}});if(!n)return;const f=C.locations(root,n);fs.mkdirSync(path.dirname(f.svg),{recursive:true});fs.writeFileSync(f.svg,C.template(),{flag:'wx'});await exportOne(f.svg,false);await editor.insertSnippet(new vscode.SnippetString(C.insertion(n)));launch(f.svg);});
 register('mastnak.figures.edit',async()=>{const {root}=fromEditor(),f=await pick(root);if(f)launch(f.svg);});
 register('mastnak.figures.export',async()=>{const {root}=fromEditor(),f=await pick(root);if(f)await enqueue(f.svg);});
 register('mastnak.figures.palette',async()=>{const {root}=fromEditor();const dir=path.join(root,'figures','inkscape-tools');fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,'stili.svg');if(!fs.existsSync(file))fs.copyFileSync(path.join(__dirname,'stili.svg'),file);launch(file);});
 function ensure(e){if(!e||e.document.languageId!=='latex')return;try{watch(C.courseRoot(e.document.fileName));}catch{}}
 ensure(vscode.window.activeTextEditor);context.subscriptions.push(vscode.window.onDidChangeActiveTextEditor(ensure),{dispose(){for(const t of timers.values())clearTimeout(t);}});
}
module.exports={activate};
