'use strict';
const vscode=require('vscode'),fs=require('fs'),path=require('path'),E=require('./engine'),R=require('./recipes'),C=require('./completion');
let busy=false,completeCurrent=null;
function activate(context){
 require('./figures').activate(context);
 require('./labels').activate(context);
 const previews=new Map();let serial=0;
 context.subscriptions.push(vscode.workspace.registerTextDocumentContentProvider('mastnak-preview',{provideTextDocumentContent:u=>previews.get(u.toString())||''}));
 function personalPath(editor){const configured=vscode.workspace.getConfiguration('mastnak.math',editor.document.uri).get('recipesPath');if(configured)return configured;let dir=path.dirname(editor.document.uri.fsPath);for(let i=0;i<6;i++){const p=path.join(dir,'.mastnak-snippets','math-workflow.json');if(fs.existsSync(p))return p;const parent=path.dirname(dir);if(parent===dir)break;dir=parent;}return null;}
 function preferences(editor){const p=personalPath(editor);if(!p)return {personal:{},conventions:{metric:'+---',fourierSign:'-'}};const data=JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));return {personal:data.recipes||{},conventions:data.conventions||{}};}
 async function help(){await vscode.commands.executeCommand('markdown.showPreview',vscode.Uri.file(path.join(context.extensionPath,'GUIDA.md')));}
 async function previewMath(){await vscode.commands.executeCommand('latex-workshop.openMathPreviewPanel');}
 async function open(initial=''){
  if(busy)return;
  const editor=vscode.window.activeTextEditor;if(!editor||editor.document.languageId!=='latex'){vscode.window.showInformationMessage('Apri un file .tex per usare i comandi di matematica.');return;}
  busy=true;
  const doc=editor.document,text=doc.getText(),version=doc.version,selection=editor.selection,start=doc.offsetAt(selection.start),end=doc.offsetAt(selection.end);
  const id='mq'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
  let settings;try{settings=preferences(editor);}catch(e){busy=false;vscode.window.showErrorMessage('Correggi math-workflow.json: '+e.message);return;}
  const input=vscode.window.createQuickPick();input.title='Matematica · comando';input.placeholder='Scrivi · ↑/↓ scegli · Tab completa · Invio applica · Esc chiude';input.ignoreFocusOut=true;input.matchOnDescription=false;input.matchOnDetail=false;input.value=initial;
  const eye={iconPath:new vscode.ThemeIcon('eye'),tooltip:'Confronta prima e dopo senza applicare'},list={iconPath:new vscode.ThemeIcon('list-unordered'),tooltip:'Comandi e ricette'},book={iconPath:new vscode.ThemeIcon('book'),tooltip:'Guida con esempi'};input.buttons=[list,eye,book];
  const build=()=>E.plan(input.value,text,start,end,{...settings,id});
  function validate(){let p,error;try{if(input.value.trim())p=build();}catch(e){error=e.message;}input.validationMessage=error;input.title=error?'Matematica · '+error:'Matematica · Tab completa, Invio applica';const suggestions=C.suggestions(input.value,settings.personal).map(s=>({...s,action:'complete',alwaysShow:true}));input.items=p?[{label:input.value,description:'↵ Applica '+(p.action||'al documento'),action:'apply',alwaysShow:true},...suggestions]:suggestions;input.activeItems=input.items.length?[input.items[0]]:[];}
  completeCurrent=()=>{if(input.activeItems[0]?.action==='apply')return;const item=input.activeItems.find(x=>x.action==='complete')||input.items.find(x=>x.action==='complete');if(item){input.value=item.command;validate();}};
  vscode.commands.executeCommand('setContext','mastnak.math.open',true);
  let accepting=false,picking=false;
  const subscriptions=[];
  subscriptions.push(input.onDidChangeValue(validate));
  subscriptions.push(input.onDidTriggerButton(async button=>{
   if(button===book){await help();return;}
   if(button===list){input.value='';validate();return;}
   try{const p=build();if(p.action){input.validationMessage='Scegli una modifica per vedere l’anteprima.';return;}const k=++serial,u1=vscode.Uri.parse('mastnak-preview:/'+k+'/prima.tex'),u2=vscode.Uri.parse('mastnak-preview:/'+k+'/dopo.tex');previews.set(u1.toString(),text);previews.set(u2.toString(),p.document.replace(/\{\{([^{}]*)\}\}/g,'$1'));await vscode.commands.executeCommand('vscode.diff',u1,u2,'Anteprima · '+input.value,{preview:true,preserveFocus:true});}catch(e){input.validationMessage=e.message;}
  }));
  subscriptions.push(input.onDidAccept(async()=>{
   if(accepting)return;const selected=input.activeItems[0];if(selected?.action==='complete'){input.value=selected.command;validate();return;}let p;try{p=build();}catch(e){input.validationMessage=e.message;input.title='Matematica · '+e.message;return;}
   accepting=true;
   try{
    if(doc.isClosed||doc.version!==version){input.validationMessage='Il documento è cambiato: chiudi e riapri la casella.';return;}
    if(p.action){input.hide();if(p.action==='help')await help();if(p.action==='preview'){await vscode.window.showTextDocument(doc,{preserveFocus:false});await previewMath();}if(p.action==='recipes'){const file=personalPath(editor);if(file)await vscode.window.showTextDocument(vscode.Uri.file(file));else vscode.window.showInformationMessage('Imposta mastnak.math.recipesPath per aprire le ricette personali.');}return;}
    const range=new vscode.Range(doc.positionAt(p.start),doc.positionAt(p.end));
    await vscode.window.showTextDocument(doc,{preserveFocus:false});
    await vscode.commands.executeCommand('hsnips.leaveSnippet');
    if(doc.version!==version){input.validationMessage='Il documento è cambiato: riapri la casella.';return;}
    const ok=await editor.insertSnippet(new vscode.SnippetString(E.snippet(p.value,p.generated)),range,{undoStopBefore:true,undoStopAfter:true});
    if(ok)input.hide();else input.validationMessage='Modifica non applicata.';
   }catch(e){input.validationMessage=e.message;}finally{accepting=false;}
  }));
  subscriptions.push(input.onDidHide(()=>{if(picking)return;subscriptions.forEach(s=>s.dispose());input.dispose();busy=false;completeCurrent=null;vscode.commands.executeCommand('setContext','mastnak.math.open',false);}));
  validate();input.show();
 }
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.math',()=>open()));
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.math.complete',()=>completeCurrent?.()));
 // Wait until HyperSnips has deleted its trigger before snapshotting the file.
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.matrix',()=>setTimeout(()=>open('matrix(2x2)'),100)));
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.math.trigger',()=>setTimeout(()=>open(),100)));
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.math.help',help));
 context.subscriptions.push(vscode.commands.registerCommand('mastnak.math.preview',previewMath));
}
module.exports={activate};
