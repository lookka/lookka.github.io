'use strict';
// Conservative LaTeX scanner: comments, escaped delimiters, brace groups and
// nested environments are tracked. Unknown macro semantics are not expanded.
function escaped(s,i){let n=0;while(i>0&&s[--i]==='\\')n++;return n%2===1;}
function scan(s){
 const tokens=[];let depth=0,env=0,comment=false;
 for(let i=0;i<s.length;i++){
  const ch=s[i];
  if(comment){if(ch==='\n')comment=false;else continue;}
  if(ch==='%'&&!escaped(s,i)){comment=true;continue;}
  if(ch==='\\'&&!escaped(s,i)){
   const m=/^\\(begin|end)\{([^{}]+)\}/.exec(s.slice(i));
   if(m){env+=m[1]==='begin'?1:-1;i+=m[0].length-1;continue;}
   if(s[i+1]==='\\'&&depth===0&&env===0){tokens.push({kind:'row',at:i,len:2});i++;continue;}
   const cmd=/^\\[A-Za-z@]+/.exec(s.slice(i));if(cmd){i+=cmd[0].length-1;continue;}
   i++;continue;
  }
  if(ch==='{'&&!escaped(s,i))depth++;
  if(ch==='}'&&!escaped(s,i))depth--;
  if(depth<0||env<0)throw Error('Delimitatori LaTeX non bilanciati.');
  if(depth===0&&env===0&&(ch==='&'||ch==='='||ch==='\n'))tokens.push({kind:ch,at:i,len:1});
 }
 if(depth||env)throw Error('Completa prima parentesi e ambienti LaTeX.');
 return tokens;
}
function split(s,kind){const ts=scan(s).filter(t=>t.kind===kind);let last=0;const out=[];for(const t of ts){out.push(s.slice(last,t.at));last=t.at+t.len;}out.push(s.slice(last));return out;}
function environments(text){
 const stack=[],out=[];const re=/%[^\n]*|\\(?:begin|end)\{([^{}]+)\}|\\\[|\\\]|\\\(|\\\)/g;let m;
 while((m=re.exec(text))){if(m[0][0]==='%'){if(escaped(text,m.index))re.lastIndex=m.index+1;continue;}if(escaped(text,m.index))continue;
  const open=m[0].startsWith('\\begin')||m[0]==='\\['||m[0]==='\\(';
  const name=m[1]||(m[0].includes('[')||m[0].includes(']')?'displaymath':'inline');
  if(open)stack.push({name,start:m.index,bodyStart:re.lastIndex,open:m[0]});
  else{const a=stack.pop();if(a&&a.name===name)out.push({...a,bodyEnd:m.index,end:re.lastIndex,close:m[0]});}
 }
 // Dollar math is handled separately and never crosses comments or environments.
 let dollar=null;const ds=/%[^\n]*|\$\$?/g;
 while((m=ds.exec(text))){if(m[0][0]==='%'){if(escaped(text,m.index))ds.lastIndex=m.index+1;continue;}if(escaped(text,m.index))continue;
  if(!dollar)dollar={start:m.index,bodyStart:ds.lastIndex,open:m[0]};
  else if(dollar.open===m[0]){out.push({...dollar,name:m[0]==='$$'?'displaymath':'inline',bodyEnd:m.index,end:ds.lastIndex,close:m[0]});dollar=null;}
 }
 return out;
}
const mathNames=/^(?:inline|displaymath|equation\*?|align(?:at)?\*?|aligned(?:at)?|gather(?:ed)?\*?|multline\*?|split|cases|[bpBvV]?matrix|array|[bpv]?NiceArray|[bpv]?NiceMatrix)$/;
function enclosing(text,start,end=start,filter=()=>true){return environments(text).filter(e=>e.start<=start&&e.end>=end&&filter(e)).sort((a,b)=>(a.end-a.start)-(b.end-b.start))[0];}
function target(text,start,end,kind='math'){
 if(end>start){const e=enclosing(text,start,end);return {start,end,text:text.slice(start,end),env:e&&e.start===start&&e.end===end?e:undefined};}
 const e=enclosing(text,start,end,e=>kind==='matrix'?/^(?:[bpBvV]?matrix|array|[bpv]?NiceArray|[bpv]?NiceMatrix)$/.test(e.name):mathNames.test(e.name));
 if(!e)throw Error(kind==='matrix'?'Metti il cursore dentro una matrice.':'Seleziona una formula oppure metti il cursore in un ambiente matematico.');
 return {start:e.start,end:e.end,text:text.slice(e.start,e.end),env:e};
}
function unwrapMath(s){const e=enclosing(s,0,s.length);return e&&mathNames.test(e.name)?s.slice(e.bodyStart,e.bodyEnd).trim():s.trim();}
function groupAt(s,i,open='{',close='}'){
 if(s[i]!==open)throw Error('Gruppo LaTeX atteso.');let n=1;
 for(let j=i+1;j<s.length;j++){if(escaped(s,j))continue;if(s[j]===open)n++;if(s[j]===close&&!--n)return {text:s.slice(i+1,j),end:j+1};}
 throw Error('Gruppo LaTeX incompleto.');
}
function matrix(s){
 const e=environments(s).find(e=>/^(?:[bpBvV]?matrix|array|[bpv]?NiceArray|[bpv]?NiceMatrix)$/.test(e.name));
 if(!e)throw Error('Matrice non riconosciuta.');
 if(/Nice/.test(e.name))throw Error('Per modificare questa matrice usa prima il formato array/matrix standard.');
 let bodyStart=e.bodyStart,spec='';
 while(/\s/.test(s[bodyStart]||'')&&bodyStart<s.length)bodyStart++;
 if(e.name==='array'){const g=groupAt(s,bodyStart);spec=g.text;bodyStart=g.end;
  if(!/^[cl r|]+$/.test(spec))throw Error('Questa specifica array è complessa: usa colonne c, l o r per modificarla.');}
 const body=s.slice(bodyStart,e.bodyEnd);
 let rows=split(body,'row').map(x=>x.trim()).filter(Boolean),hlines=[];
 rows=rows.map((row,i)=>{if(/^\\hline\b/.test(row)){hlines.push(i);row=row.replace(/^\\hline\s*/,'');}if(/\\(?:cline|multicolumn|multirow|Block)\b/.test(row))throw Error('Matrice con celle unite o linee parziali: modifica non automatica.');return split(row,'&').map(x=>x.trim());});
 if(!rows.length||rows.some(r=>r.length!==rows[0].length))throw Error('La matrice deve avere lo stesso numero di celle in ogni riga.');
 const cols=rows[0].length;
 if(rows.length>20||cols>20)throw Error('Limite: 20 righe e 20 colonne.');
 const vlines=[];let c=0;for(const x of spec.replace(/\s/g,'')){if(x==='|'){if(c>0&&c<cols)vlines.push(c);}else c++;}
 const delimiter=({bmatrix:'b',pmatrix:'p',vmatrix:'v',Bmatrix:'B',Vmatrix:'V',matrix:'none'})[e.name]||'none';
 return {rows,hlines,vlines,delimiter,spec,prefix:s.slice(0,e.start),suffix:s.slice(e.end)};
}
function renderMatrix(m){
 let k=0;const spec=m.spec?m.spec.replace(/\|/g,'').replace(/[clr]/g,x=>x+(m.vlines.includes(++k)?'|':'')):Array.from({length:m.rows[0].length},(_,i)=>'c'+(m.vlines.includes(i+1)?'|':'')).join('');
 const body=m.rows.map((r,i)=>(m.hlines.includes(i)?'  \\hline\n':'')+'  '+r.join(' & ')).join(' \\\\\n');
 let s='\\begin{array}{'+spec+'}\n'+body+'\n\\end{array}';
 if(m.delimiter!=='none'){const [a,b]=({b:['[',']'],p:['(',')'],v:['|','|'],B:['\\{','\\}'],V:['\\Vert','\\Vert']})[m.delimiter];s='\\left'+a+'\n'+s+'\n\\right'+b;}
 return m.prefix+s+m.suffix;
}
module.exports={escaped,scan,split,environments,enclosing,target,unwrapMath,groupAt,matrix,renderMatrix,mathNames};
