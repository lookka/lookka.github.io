'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const {extract,preprocess,labelPreamble}=require('./latex');

function references(text){
    const blocks=new Map(extract(text).map(block=>[block.start,block.end]));
    const result=[],ignored=new Set(['verbatim','verbatim*','Verbatim','lstlisting','minted','comment']);
    const escaped=index=>{let count=0;while(index>0&&text[--index]==='\\')++count;return count%2===1;};
    let i=0;
    while(i<text.length){
        if(blocks.has(i)){i=blocks.get(i);continue;}
        if(text[i]==='%'&&!escaped(i)){const end=text.indexOf('\n',i);i=end<0?text.length:end+1;continue;}
        if(text[i]!=='\\'||escaped(i)){++i;continue;}
        const verb=text.slice(i).match(/^\\verb\*?([^A-Za-z\s])/);
        if(verb){const end=text.indexOf(verb[1],i+verb[0].length);if(end<0)throw new Error('verb non chiuso');i=end+1;continue;}
        const begin=text.slice(i).match(/^\\begin\s*\{([^}]+)\}/);
        if(begin&&ignored.has(begin[1])){const marker='\\end{'+begin[1]+'}',end=text.indexOf(marker,i+begin[0].length);if(end<0)throw new Error('Ambiente '+begin[1]+' non chiuso');i=end+marker.length;continue;}
        const command=text.slice(i).match(/^\\(input|include|includeonly)(?![A-Za-z@])\s*/);
        if(!command){++i;continue;}
        const start=i,argument=i+command[0].length;let end,value;
        if(text[argument]==='{'){end=text.indexOf('}',argument+1);if(end<0)throw new Error(command[1]+': parentesi non chiusa');value=text.slice(argument+1,end);++end;}
        else if(command[1]==='input'){const bare=text.slice(argument).match(/^[^\s%{}]+/);if(!bare)throw new Error('input: nome file mancante');value=bare[0];end=argument+value.length;}
        else{++i;continue;}
        result.push({start,end,command:command[1],value,line:text.slice(0,start).split('\n').length});i=end;
    }
    return result;
}
async function prepareProject(sourcePath,directory,options){
    sourcePath=path.resolve(sourcePath);const root=path.dirname(sourcePath),snapshots=new Map(),outputs=new Map(),figures=[];
    let totalBytes=0;
    const initial=await fs.readFile(sourcePath,'utf8'),shared=labelPreamble(initial)+'\n'+(options.texPreamble||'');
    const canonical=file=>process.platform==='win32'?path.resolve(file).toLowerCase():path.resolve(file);
    function resolveName(value){
        value=value.trim();if(value.startsWith('"')&&value.endsWith('"'))value=value.slice(1,-1);
        if(!value||/[\\{}%#\r\n]/.test(value))throw new Error('input/include: serve un nome file letterale, senza macro: '+value);
        return path.resolve(root,/\.[^/]+$/.test(value)?value:value+'.tex');
    }
    const shadow=file=>'pyxis-input-'+crypto.createHash('sha256').update(canonical(file)).digest('hex').slice(0,24);
    const only=references(initial).filter(ref=>ref.command==='includeonly').at(-1);
    const selected=only?new Set(only.value.trim()?only.value.split(',').map(value=>canonical(resolveName(value))):[]):null;
    async function visit(file,stack){
        file=canonical(file);
        if(stack.includes(file))throw new Error('input/include ciclico: '+[...stack,file].join(' -> '));
        if(outputs.has(file))return outputs.get(file);
        if(snapshots.size>=128)throw new Error('Progetto LaTeX: massimo 128 file');
        let original;
        try{original=file===canonical(sourcePath)?initial:await fs.readFile(file,'utf8');}catch(error){throw new Error('File LaTeX non leggibile: '+file+' ('+error.code+')');}
        totalBytes+=Buffer.byteLength(original);if(totalBytes>8*1024*1024)throw new Error('Progetto LaTeX oltre 8 MiB di sorgenti');
        snapshots.set(file,original);
        const destination=path.join(directory,file===canonical(sourcePath)?path.basename(sourcePath):shadow(file)+'.tex');
        const prepared=await preprocess(original,{...options,sourcePath:file,cacheDir:options.cacheDir||path.join(root,'.pyxis_cache'),pinCache:false,texPreamble:file===canonical(sourcePath)?(options.texPreamble||''):shared});
        figures.push(...prepared.figures.map(figure=>({...figure,sourcePath:file})));
        const edits=[];
        for(const ref of references(prepared.text)){
            if(ref.command==='includeonly'){
                const names=ref.value.trim()?ref.value.split(',').map(value=>shadow(resolveName(value))):[];
                edits.push({...ref,replacement:'\\includeonly{'+names.join(',')+'}'});continue;
            }
            const child=resolveName(ref.value);
            if(ref.command==='include'&&selected&&!selected.has(canonical(child)))continue;
            await visit(child,[...stack,file]);
            edits.push({...ref,replacement:'\\'+ref.command+'{'+shadow(child)+(ref.command==='input'?'.tex':'')+'}'});
        }
        let text=prepared.text;
        for(const edit of edits.reverse())text=text.slice(0,edit.start)+edit.replacement+'\n'.repeat((text.slice(edit.start,edit.end).match(/\n/g)||[]).length)+text.slice(edit.end);
        await fs.writeFile(destination,text,'utf8');outputs.set(file,destination);return destination;
    }
    const derived=await visit(sourcePath,[]);
    return {derived,figures,snapshots,files:outputs.size};
}
module.exports={references,prepareProject};
async function rootDocument(file){
    const seen=new Set();
    for(let depth=0;depth<8;++depth){
        file=path.resolve(file);const key=process.platform==='win32'?file.toLowerCase():file;
        if(seen.has(key))throw new Error('Indicazione TeX root ciclica');seen.add(key);
        const text=await fs.readFile(file,'utf8');
        const marker=text.split(/\r?\n/).slice(0,40).join('\n').match(/^\s*%\s*!\s*TeX\s+root\s*=\s*(.+)$/im);
        if(!marker)return file;
        const target=marker[1].trim();if(!/\.tex$/i.test(target)||/[{}\r\n]/.test(target))throw new Error('TeX root: percorso .tex letterale richiesto');
        file=path.resolve(path.dirname(file),target);
    }
    throw new Error('Troppi rinvii TeX root');
}
module.exports.rootDocument=rootDocument;
