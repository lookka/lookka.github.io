'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const { render } = require('../../vscode/backend');
const { atomicWrite } = require('../../vscode/cache');

function escaped(text, index) {
    let slashes = 0;
    while (index > 0 && text[--index] === '\\') ++slashes;
    return slashes % 2 === 1;
}
function skipOptions(text, index) {
    while (/\s/.test(text[index] || '') && index < text.length) ++index;
    if (text[index] !== '[') return { end: index, options: '' };
    const start = ++index; let depth = 1;
    while (index < text.length) {
        if (text[index] === '[' && !escaped(text, index)) ++depth;
        if (text[index] === ']' && !escaped(text, index) && --depth === 0) return { end: index + 1, options: text.slice(start, index) };
        ++index;
    }
    throw new Error('Opzioni dell’ambiente pyxis non chiuse');
}
function optionsSource(options) {
    if (!options.trim()) return '';
    const keys = new Set();
    return options.split(',').map(option => {
        const match = option.trim().match(/^(width|theme)\s*=\s*([\w.-]+)$/);
        if (!match || keys.has(match[1])) throw new Error(`Opzione pyxis non valida o duplicata: ${option}`);
        keys.add(match[1]);
        if (match[1] === 'width' && (!Number.isFinite(Number(match[2])) || Number(match[2]) <= 0)) throw new Error('width deve essere positiva, in mm');
        return match[1] + ' ' + match[2] + '\n';
    }).join('');
}
function latexSource(body) {
    // Accept TeX comments while preserving percent signs in quoted labels.
    return body.split('\n').map(line => {
        let quoted = false;
        for (let i = 0; i < line.length; ++i) {
            if (line[i] === '"') quoted = !quoted;
            if (line[i] === '%' && !quoted && !escaped(line, i)) return line.slice(0, i) + '#' + line.slice(i + 1);
        }
        return line;
    }).join('\n');
}
function extract(text) {
    const blocks = [];
    const verbatim = new Set(['verbatim', 'verbatim*', 'Verbatim', 'lstlisting', 'minted', 'comment']);
    let i = 0;
    while (i < text.length) {
        if (text[i] === '%' && !escaped(text, i)) { const end = text.indexOf('\n', i); i = end < 0 ? text.length : end + 1; continue; }
        if (text[i] !== '\\' || escaped(text, i)) { ++i; continue; }
        const verb = text.slice(i).match(/^\\verb\*?([^A-Za-z\s])/);
        if (verb) {
            const end = text.indexOf(verb[1], i + verb[0].length);
            if (end < 0 || text.slice(i, end).includes('\n')) throw new Error('Comando verb non chiuso');
            i = end + 1; continue;
        }
        const begin = text.slice(i).match(/^\\begin\s*\{([^}]+)\}/);
        if (!begin) { ++i; continue; }
        if (verbatim.has(begin[1])) {
            const marker = '\\end{' + begin[1] + '}'; const end = text.indexOf(marker, i + begin[0].length);
            if (end < 0) throw new Error(`Ambiente ${begin[1]} non chiuso`);
            i = end + marker.length; continue;
        }
        if (begin[1] !== 'pyxis') { i += begin[0].length; continue; }
        const start = i;
        const opts = skipOptions(text, i + begin[0].length);
        const bodyStart = opts.end;
        // A delimiter occupies its own line; occurrences inside a quoted label
        // or a comment remain ordinary Pyxis text.
        const ending = /^[ \t]*\\end\s*\{pyxis\}[ \t]*(?:%[^\r\n]*)?(?=\r?$)/gm;
        ending.lastIndex = bodyStart;
        const end = ending.exec(text);
        if (!end) throw new Error(`Ambiente pyxis non chiuso alla riga ${text.slice(0, start).split('\n').length}`);
        const body = text.slice(bodyStart, end.index);
        if (/^[ \t]*\\begin\s*\{pyxis\}/m.test(body)) throw new Error('Ambienti pyxis annidati non supportati');
        const sourceLine = text.slice(0, bodyStart).split('\n').length;
        const prefix = optionsSource(opts.options);
        blocks.push({ start, end: end.index + end[0].length, body, prefix, sourceLine });
        i = end.index + end[0].length;
    }
    return blocks;
}
function labelPreamble(text) {
    // Share package declarations with label TeX, excluding document-level setup.
    // Macro definitions needed by labels can be supplied through texPreamble.
    const preamble = text.split(/\\begin\s*\{document\}/)[0];
    const uncommented = preamble.split('\n').map(line => {
        for (let i = 0; i < line.length; ++i) if (line[i] === '%' && !escaped(line, i)) return line.slice(0, i);
        return line;
    }).join('\n');
    const declarations = [...uncommented.matchAll(/\\usepackage\s*(\[[^\]]*\])?\s*\{([^}]+)\}/g)].map(match => {
        const packages = match[2].split(',').map(s => s.trim()).filter(s => s !== 'pyxis' && s !== 'graphicx');
        return {index:match.index,text:packages.length ? '\\usepackage' + (match[1] || '') + '{' + packages.join(',') + '}' : ''};
    });
    const whitespace=index=>{while(/\s/.test(uncommented[index]||'')&&index<uncommented.length)++index;return index;};
    function group(index,open,close){
        index=whitespace(index);if(uncommented[index]!==open)return null;
        let depth=1,cursor=index+1;
        for(;cursor<uncommented.length;++cursor){if(escaped(uncommented,cursor))continue;if(uncommented[cursor]===open)++depth;if(uncommented[cursor]===close&&--depth===0)return cursor+1;}
        throw new Error('Definizione macro LaTeX non chiusa');
    }
    const macro=/\\(?:newcommand|renewcommand|providecommand|DeclareMathOperator)\*?(?![A-Za-z@])/g;
    let match;
    while((match=macro.exec(uncommented))){
        let end=whitespace(macro.lastIndex),nameEnd=group(end,'{','}');
        if(nameEnd===null){const name=uncommented.slice(end).match(/^\\(?:[A-Za-z@]+|.)/);if(!name)continue;nameEnd=end+name[0].length;}
        end=nameEnd;
        for(let option=0;option<2;++option){const optionEnd=group(end,'[',']');if(optionEnd===null)break;end=optionEnd;}
        const bodyEnd=group(end,'{','}');if(bodyEnd===null)continue;
        declarations.push({index:match.index,text:uncommented.slice(match.index,bodyEnd)});macro.lastIndex=bodyEnd;
    }
    return declarations.sort((a,b)=>a.index-b.index).map(item=>item.text).filter(Boolean).join('\n');
}
async function preprocess(text, { sourcePath, compiler, cacheDir, ...options }) {
    const blocks = extract(text);
    cacheDir = cacheDir || path.join(path.dirname(sourcePath), '.pyxis_cache');
    const preamble = labelPreamble(text) + '\n' + (options.texPreamble || '');
    const replacements = []; const figures = [];
    // Sequential per document limits TeX process pressure. Separate editor requests
    // and documents remain asynchronous, and matching renders share one promise.
    for (const block of blocks) {
        let cache;
        const started = performance.now();
        try {
            const result = await render(block.prefix + latexSource(block.body), ['pdf'], { ...options, compiler, cacheDir,
                pinCache: options.pinCache !== false,
                texPreamble: preamble, onCache: state => { cache = state; } });
            const figurePath = path.resolve(cacheDir, cache.key, 'figure.pdf');
            const safePath = figurePath.replace(/\\/g, '/');
            if (/[{}%#\r\n]/.test(safePath)) throw new Error('Il percorso del documento contiene caratteri non supportati da LaTeX');
            const newlines = (text.slice(block.start, block.end).match(/\n/g) || []).length;
            replacements.push({ ...block, replacement: '\\includegraphics{\\detokenize{' + safePath + '}}' + '\n'.repeat(newlines) });
            figures.push({ path: figurePath, bytes: result.pdf.length, cached: cache.hit, milliseconds: performance.now() - started, line: block.sourceLine });
        } catch (error) {
            const prefixLines = (block.prefix.match(/\n/g) || []).length;
            const message = error.message.replace(/riga (\d+)/g, (_, row) => 'riga ' + (block.sourceLine + Number(row) - prefixLines - 1));
            throw new Error(sourcePath + ': ' + message);
        }
    }
    let output = text;
    for (const replacement of replacements.reverse()) output = output.slice(0, replacement.start) + replacement.replacement + output.slice(replacement.end);
    return { text: output, figures };
}
async function writeDocument(sourcePath, destination, options) {
    sourcePath = path.resolve(sourcePath); destination = path.resolve(destination);
    if (sourcePath === destination) throw new Error('Il documento originale non può essere sovrascritto');
    const original = await fs.readFile(sourcePath, 'utf8');
    const prepared = await preprocess(original, { ...options, sourcePath });
    await atomicWrite(destination, prepared.text);
    return prepared;
}
module.exports = { extract, optionsSource, labelPreamble, latexSource, preprocess, writeDocument };
