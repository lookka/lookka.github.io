#pragma once
#include "pyxis.hpp"
#include <functional>
namespace pyxis {
void resolve_constraint(Scene&, Object&, const std::function<void(size_t)>& resolve);
void resolve_clipping(Scene&);
}
