#include "packages/common.hpp"
namespace pyxis {
namespace {
using namespace packages;
using Generator=void(*)(const Block&,Builder&);
const std::map<std::string,Generator> registry{{"qft.feynman",feynman},{"quantum.circuit",circuit},{"quantum.tensor-network",tensor_network},{"quantum.bloch",bloch},{"statmech.ising",ising},{"statmech.phase-flow",phase_flow},{"statmech.phase-diagram",phase_diagram},{"statmech.lorenz",lorenz},{"relativity.penrose",penrose},{"relativity.embedding",embedding},{"relativity.light-cones",light_cones},{"relativity.geodesic",geodesic}};
}
std::vector<SourceLine> semantic(std::istream& input) {
    using namespace packages;
    std::vector<SourceLine> out;std::set<std::string> imports,ids;
    std::string raw;size_t n=0;
    while(std::getline(input,raw)){
        ++n;auto s=clean(raw);
        try {
            if(s.rfind("profile ",0)==0){
                auto profile=trim(s.substr(8));
                static const std::map<std::string,std::vector<std::string>> profiles{{"qft",{"qft"}},{"quantum",{"quantum"}},{"relativity",{"relativity"}},{"statmech",{"statmech"}},{"research",{"qft","quantum","relativity","statmech"}}};
                auto preset=profiles.find(profile);if(preset==profiles.end())throw std::runtime_error("profile: qft, quantum, relativity, statmech, research");
                for(const auto& p:preset->second)if(imports.insert(p).second)out.push_back({"_use "+p,n});
                continue;
            }
            if(s.rfind("use ",0)==0){for(auto p:split(s.substr(4))){if(p!="qft"&&p!="quantum"&&p!="statmech"&&p!="relativity")throw std::runtime_error("pacchetto sconosciuto: "+p);if(imports.insert(p).second)out.push_back({"_use "+p,n});}continue;}
            if(s.rfind("theme:",0)==0){out.push_back({"theme "+trim(s.substr(6)),n});continue;}
            if(s.empty()||s.back()!='{'||s.find('"')!=std::string::npos){out.push_back({raw,n});continue;}
            std::istringstream header(s.substr(0,s.size()-1));std::string type,id,extra;header>>type>>id;
            std::string qualified=type;
            if(type.find('.')==std::string::npos){
                std::vector<std::string> matches;for(const auto& p:imports)if(registry.count(p+"."+type))matches.push_back(p+"."+type);
                if(matches.size()>1)throw std::runtime_error("nome ambiguo: usa il prefisso del pacchetto");
                if(matches.size()==1)qualified=matches.front();
            }
            auto generator=registry.find(qualified);
            if(generator==registry.end()){
                if(type.find('.')!=std::string::npos)throw std::runtime_error("oggetto del pacchetto non disponibile: "+type);
                out.push_back({raw,n});continue;
            }
            if(!imports.count(qualified.substr(0,qualified.find('.'))))throw std::runtime_error("importa prima il pacchetto con use");
            if(!identifier(id)||header>>extra)throw std::runtime_error("intestazione attesa: tipo nome {");
            if(!ids.insert(id).second)throw std::runtime_error("nome del gruppo gia' utilizzato: "+id);
            Block b{qualified,id,n,{}, {}};bool closed=false;
            while(std::getline(input,raw)){
                ++n;auto prop=clean(raw);if(prop.empty())continue;if(prop=="}"){closed=true;break;}
                auto colon=prop.find(':');if(colon==std::string::npos)throw std::runtime_error("proprieta' attesa: nome: valore");
                auto k=trim(prop.substr(0,colon)),v=trim(prop.substr(colon+1));
                if(k.empty()||v.empty()||b.properties.count(k))throw std::runtime_error("proprieta' vuota o duplicata");
                b.properties.emplace(k,SourceLine{v,n});b.order.push_back(k);
            }
            if(!closed)throw std::runtime_error("blocco non chiuso, iniziato alla riga "+std::to_string(b.line));
            Builder builder{out,b,{}};generator->second(b,builder);
        }catch(const std::exception& e){throw std::runtime_error("riga "+std::to_string(n)+": "+e.what());}
    }
    if(input.bad())throw std::runtime_error("errore durante la lettura del sorgente");
    return out;
}
}
