#include "common.hpp"
#include "../numerics.hpp"
namespace pyxis::packages {
void penrose(const Block& b,Builder& out) {
    b.allow({"metric","spin","bands"});auto metric=b.get("metric","minkowski");
    if(metric!="kerr"&&(b.properties.count("spin")||b.properties.count("bands")))throw std::runtime_error("spin/bands richiedono metric: kerr");
    if(metric=="kerr"){
        double spin=real(b.get("spin","0.7"),1e-6,0.999999);
        unsigned bands=integer(b.get("bands","3"),3,7);if(bands%2==0)throw std::runtime_error("Kerr: bands dispari (3,5,7)");
        int half=static_cast<int>(bands/2);
        for(int band=-half;band<=half;++band){
            double y=2*band;bool outer=band%2==0;std::string id="band"+std::to_string(band+half+1);
            out.path(id+"_right_infinity",{{1,y-1},{2,y},{1,y+1}});out.path(id+"_left_infinity",{{-1,y-1},{-2,y},{-1,y+1}});
            for(unsigned side=0;side<2;++side)for(unsigned future=0;future<2;++future){auto name=out.line(id+"_horizon"+std::to_string(side*2+future),0,y,side?-1:1,y+(future?1:-1));if(!outer)out.emit("stroke "+name+" dashed");}
            out.label(id+"_right",1.1,y,outer?"$r>r_+$":"$r<r_-$",true);out.label(id+"_left",-1.1,y,outer?"$r>r_+$":"$r<r_-$",true);
            out.label(id+"_right_spatial",2.35,y,outer?"$i^0_+$":"$i^0_-$",true);out.label(id+"_left_spatial",-2.35,y,outer?"$i^0_+$":"$i^0_-$",true);
            auto label=out.object("label",id+"_horizon_label",b.id+"."+id+"_horizon1.center \""+(outer?"$r_+$":"$r_-$")+"\"");out.emit("placement "+label+" auto n 4");
            if(band<half)out.label(id+"_between",0,y+1,"$r_-<r<r_+$",true);
        }
        double edge=2*half+1;
        out.label("continued_future",0,edge+0.4,"$\\vdots$",true);out.label("continued_past",0,-edge-0.4,"$\\vdots$",true);
        std::ostringstream spinLabel;spinLabel<<std::setprecision(8)<<spin;
        out.label("axis",0,-edge-1,"$\\theta=0,\\quad a/M="+spinLabel.str()+"$",true);
        out.label("regular",0,edge+1,"Kerr axis: r=0 regular");out.group(-2.8,-edge-1.5,2.8,edge+1.5);return;
    }
    if(metric=="schwarzschild"){
        out.path("right_infinity",{{1,1},{2,0},{1,-1}});out.path("left_infinity",{{-1,1},{-2,0},{-1,-1}});
        for(unsigned sign=0;sign<2;++sign){std::vector<std::pair<double,double>> zigzag;for(unsigned i=0;i<=40;++i){double x=-1+i*0.05,y=(sign?-1:1)+(i==0||i==40?0:(i%2?0.035:-0.035));zigzag.push_back({x,y});}out.path(sign?"past_singularity":"future_singularity",zigzag);}
        out.line("horizon1",-1,-1,1,1);out.line("horizon2",-1,1,1,-1);
        out.label("regionI",1,0,"I");out.label("regionII",0,0.55,"II");out.label("regionIII",-1,0,"III");out.label("regionIV",0,-0.55,"IV");
        out.label("future",0,1.3,"$r=0$",true);out.label("past",0,-1.3,"$r=0$",true);
        out.label("right",2.35,0,"$i^0$",true);out.label("left",-2.35,0,"$i^0$",true);
        out.label("null_future",1.7,0.7,"$\\mathcal{I}^+$",true);out.label("null_past",1.7,-0.7,"$\\mathcal{I}^-$",true);
        out.group(-2.8,-1.7,2.8,1.7);return;
    }
    if(metric!="minkowski")throw std::runtime_error("penrose: metriche implementate minkowski, schwarzschild, kerr (asse)");
    out.path("boundary",{{0,2},{2,0},{0,-2},{-2,0},{0,2}});
    out.label("future",0,2.35,"$i^+$",true);out.label("past",0,-2.35,"$i^-$",true);
    out.label("left",-2.35,0,"$i^0$",true);out.label("right",2.35,0,"$i^0$",true);
    out.label("null_future",1.35,1.35,"$\\mathcal{I}^+$",true);out.label("null_past",1.35,-1.35,"$\\mathcal{I}^-$",true);
    out.group(-2.8,-2.7,2.8,2.7);
}

void embedding(const Block& b,Builder& out) {
    b.allow({"metric","radius","extent","mesh","branch"});
    if(b.get("metric","schwarzschild")!="schwarzschild")throw std::runtime_error("embedding: metrica implementata schwarzschild (sezione equatoriale spaziale)");
    double rs=real(b.get("radius","1"),1e-4,1e4),extent=real(b.get("extent","4"),1.01,100);
    unsigned mesh=integer(b.get("mesh","16"),4,30);auto branch=b.get("branch","upper");if(branch!="upper"&&branch!="lower")throw std::runtime_error("branch: upper, lower");
    double sign=branch=="upper"?1:-1;std::string points="\"";
    // Use u=sqrt((r-r_s)/(r_max-r_s)): smooth sampling at the throat.
    for(unsigned i=0;i<=mesh;++i)for(unsigned j=0;j<=mesh*2;++j){
        double u=static_cast<double>(i)/mesh,r=rs*(1+(extent-1)*u*u),phi=2*std::acos(-1.0)*j/(mesh*2);
        if(i||j)points+=';';
        points+=num(r*std::cos(phi))+" "+num(r*std::sin(phi))+" "+num(sign*2*std::sqrt(rs*(r-rs)));
    }
    auto name=out.object("mesh3","surface",std::to_string(mesh+1)+" "+std::to_string(mesh*2+1)+" "+points+"\"");out.emit("fill "+name+" white");out.emit("linewidth "+name+" 0.25");
}

void light_cones(const Block& b,Builder& out) {
    b.allow({"metric","chart","radii","rows","height"});
    if(b.get("metric","schwarzschild")!="schwarzschild"||b.get("chart","painleve-gullstrand")!="painleve-gullstrand")throw std::runtime_error("light-cones: Schwarzschild in coordinate Painleve-Gullstrand ingoing");
    auto values=list(b.get("radii","[0.6, 1, 1.8, 3.2, 5]"));if(values.empty()||values.size()>16)throw std::runtime_error("radii: da 1 a 16 raggi in unita' r_s");
    unsigned rows=integer(b.get("rows","2"),1,8);double height=real(b.get("height","0.32"),0.01,0.5),maximum=1;
    std::vector<double> radii;for(const auto& value:values){double r=real(value,0.1,100);if(!radii.empty()&&r<=radii.back())throw std::runtime_error("radii devono essere crescenti");radii.push_back(r);maximum=std::max(maximum,r);}
    for(unsigned row=0;row<rows;++row)for(size_t i=0;i<radii.size();++i){
        double r=radii[i],time=1+row*1.25,flow=-std::sqrt(1/r);
        double dt=std::min(height,0.4*r/(1+std::abs(flow)));
        std::string id="row"+std::to_string(row+1)+"_cone"+std::to_string(i+1);
        out.line(id+"_ingoing",r,time,r+dt*(flow-1),time+dt,true);
        out.line(id+"_outgoing",r,time,r+dt*(flow+1),time+dt,true);
        out.path(id+"_rim",{{r+dt*(flow-1),time+dt},{r+dt*(flow+1),time+dt}});
    }
    double top=rows*1.25+0.75;
    auto horizon=out.line("horizon",1,0,1,top);out.emit("stroke "+horizon+" dashed");
    out.line("radius_axis",0,0,maximum+0.7,0,true);out.line("time_axis",0,0,0,top+0.35,true);
    out.label("radius_label",maximum+0.65,-0.3,"$r/r_s$",true);out.label("time_label",-0.35,top+0.2,"$t_{PG}/r_s$",true);
    out.label("horizon_label",1,top+0.25,"$r=r_s$",true);out.group(-0.6,-0.55,maximum+1,top+0.7);
}

void geodesic(const Block& b,Builder& out) {
    b.allow({"metric","kind","impact","extent","max-angle","max-step","abs-tol","rel-tol","max-steps","photon-sphere","view","mesh"});
    auto view=b.get("view","plane");if(view!="plane"&&view!="embedding")throw std::runtime_error("view: plane, embedding");
    if(view=="plane"&&b.properties.count("mesh"))throw std::runtime_error("mesh richiede view: embedding");
    auto photon=b.get("photon-sphere","on");if(photon!="on"&&photon!="off")throw std::runtime_error("photon-sphere: on, off");
    if(b.get("metric","schwarzschild")!="schwarzschild"||b.get("kind","null")!="null")throw std::runtime_error("geodesic: metrica Schwarzschild, geodetica nulla equatoriale");
    double impact=real(b.get("impact","3"),0.1,100),extent=real(b.get("extent","12"),2,1000),u=1/extent;
    double energy=1/(impact*impact)-u*u+u*u*u;if(energy<=0)throw std::runtime_error("impact/extent: il raggio iniziale non appartiene al ramo entrante consentito");
    numerics::Options options;options.adaptive=true;options.duration=real(b.get("max-angle","37.69911184307752"),0.01,100);
    options.maximum_step=real(b.get("max-step","0.01"),1e-6,0.05);options.absolute_tolerance=real(b.get("abs-tol","1e-10"),1e-14,1e-3);options.relative_tolerance=real(b.get("rel-tol","1e-10"),0,1e-3);options.maximum_steps=integer(b.get("max-steps","9999"),1,9999);
    auto derivative=[](const std::array<double,2>& p,double){return std::array<double,2>{p[1],1.5*p[0]*p[0]-p[0]};};
    auto event=[&](const std::array<double,2>& p,double){return p[0]>=1||(p[0]<=u&&p[1]<0);};
    auto trajectory=numerics::integrate<2>({u,std::sqrt(energy)},options,derivative,event);
    if(!trajectory.stopped)throw std::runtime_error("geodesic: max-angle raggiunto prima dell'uscita o dell'orizzonte; aumenta max-angle");
    std::vector<std::pair<double,double>> points;double left=-1,right=1,bottom=-1,top=1;
    for(size_t i=0;i<trajectory.points.size();++i){double r=1/trajectory.points[i][0],angle=trajectory.times[i];double x=r*std::cos(angle),y=r*std::sin(angle);points.push_back({x,y});left=std::min(left,x);right=std::max(right,x);bottom=std::min(bottom,y);top=std::max(top,y);}
    if(view=="embedding"){
        Block surface{"relativity.embedding",b.id,b.line,{{"extent",{num(extent),b.line}},{"mesh",{b.get("mesh","12"),b.line}}},{}};
        embedding(surface,out);
        std::vector<std::array<double,3>> lifted;
        for(const auto& p:points){double r=std::hypot(p.first,p.second);lifted.push_back({p.first,p.second,2*std::sqrt(std::max(0.0,r-1))+0.015});}
        auto ray=out.path3("ray",lifted,true);out.emit("linewidth "+ray+" 1.1");out.emit("color "+ray+" 0.15 0.32 0.55");
        std::vector<std::array<double,3>> rim;for(unsigned i=0;i<=96;++i){double angle=2*std::acos(-1.0)*i/96;rim.push_back({std::cos(angle),std::sin(angle),0.01});}out.path3("horizon",rim);
        if(photon=="on"){std::vector<std::array<double,3>> ring;for(unsigned i=0;i<=96;++i){double angle=2*std::acos(-1.0)*i/96;ring.push_back({1.5*std::cos(angle),1.5*std::sin(angle),std::sqrt(2.0)+0.01});}auto name=out.path3("photon_sphere",ring);out.emit("stroke "+name+" dashed");}
        out.object("label3","horizon_label","1.6 0 0 \"$r=r_s$\"");return;
    }
    auto horizon=out.object("circle","horizon","0 0 1");out.emit("nodefill "+horizon+" black");
    if(photon=="on"){auto sphere=out.object("circle","photon_sphere","0 0 1.5");out.emit("stroke "+sphere+" dashed");}
    out.path("ray",points);out.emit("flow "+b.id+".ray forward");
    out.object("point","caption",num((left+right)/2)+" "+num(bottom-0.5));out.group(left-0.5,bottom-0.6,right+0.5,top+0.5);
}
}
