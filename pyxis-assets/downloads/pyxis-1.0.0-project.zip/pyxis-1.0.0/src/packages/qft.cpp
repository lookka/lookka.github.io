#include "common.hpp"
namespace pyxis::packages {
struct Particle {std::string label,kind; bool anti=false;};
Particle particle(const std::string& s) {
    static const std::map<std::string,Particle> particles{
        {"electron",{"e^-","fermion",false}},{"positron",{"e^+","fermion",true}},
        {"muon",{"\\mu^-","fermion",false}},{"antimuon",{"\\mu^+","fermion",true}},
        {"photon",{"\\gamma","photon",false}},{"scalar",{"\\phi","scalar",false}},
        {"gluon",{"g","gluon",false}},
        {"ghost",{"c","ghost",false}},{"fermion",{"f","fermion",false}},
        {"antifermion",{"\\bar f","fermion",true}}};
    auto it=particles.find(s);if(it==particles.end()) throw std::runtime_error("particella non disponibile: "+s);return it->second;
}
void feynman(const Block& b,Builder& out) {
    b.allow({"channel","incoming","outgoing","mediator","labels","loop","loop-position","loop-radius","label-placement"});
    auto labelPlacement=b.get("label-placement","auto");
    if(labelPlacement!="auto"&&labelPlacement!="fixed")throw std::runtime_error("label-placement: auto, fixed");
    auto incoming=list(b.get("incoming","[electron, positron]"));
    auto outgoing=list(b.get("outgoing","[muon, antimuon]"));
    if(incoming.size()!=2||outgoing.size()!=2) throw std::runtime_error("feynman: questo layout richiede due particelle entranti e due uscenti");
    std::string channel=b.get("channel","s");
    if(channel!="s"&&channel!="t"&&channel!="u") throw std::runtime_error("canale atteso: s, t, u");
    auto mediator=particle(b.get("mediator","photon"));
    struct Leg {std::string id;double x,y,a,z;Particle p;bool in;};
    std::vector<Leg> legs;
    if(channel=="s") legs={{"in1",-2.5,1.2,-0.7,0,particle(incoming[0]),true},{"in2",-2.5,-1.2,-0.7,0,particle(incoming[1]),true},
        {"out1",0.7,0,2.5,1.2,particle(outgoing[0]),false},{"out2",0.7,0,2.5,-1.2,particle(outgoing[1]),false}};
    else {
        legs={{"in1",-2.5,1.2,0,1.2,particle(incoming[0]),true},{"in2",-2.5,-1.2,0,-1.2,particle(incoming[1]),true},
            {"out1",0,channel=="t"?1.2:-1.2,2.5,1.2,particle(outgoing[0]),false},
            {"out2",0,channel=="t"?-1.2:1.2,2.5,-1.2,particle(outgoing[1]),false}};
    }
    auto propagator=[&](const std::string& id,double x,double y,double a,double z,const Particle& p,bool reverse){
        std::string name;
        if(p.kind=="gluon"){
            std::vector<std::pair<double,double>> points;double dx=a-x,dy=z-y,length=std::hypot(dx,dy),turns=std::max(3.0,std::floor(length*6)),k=2*std::acos(-1.0)*turns;
            auto ramp=[](double value){value=std::clamp(value,0.0,1.0);return value*value*(3-2*value);};
            for(unsigned i=0;i<=static_cast<unsigned>(turns)*24;++i){
                double t=i/(turns*24);
                // Fade the first/last two turns with zero endpoint derivative.
                // The coil cannot fold back through its interaction vertex.
                double envelope=ramp(t*turns/2)*ramp((1-t)*turns/2);
                double amplitude=std::min(0.12,0.7*length/turns);
                // Sinusoidal advance gives the two endpoints matching tapers:
                // x(1-t)=length-x(t), y(1-t)=y(t) in local coordinates.
                double advance=amplitude*envelope*std::sin(k*t),side=amplitude*envelope*std::cos(k*t);
                points.push_back({x+t*dx+(advance*dx-side*dy)/length,y+t*dy+(advance*dy+side*dx)/length});
            }
            out.path(id,points);name=b.id+"."+id;
        }else name=out.line(id,x,y,a,z);
        if(p.kind=="fermion")out.emit("flow "+name+(reverse?" reverse":" forward"));
        if(p.kind=="photon")out.emit("wave "+name+" 0.1 "+std::to_string(std::max(2,static_cast<int>(std::hypot(a-x,z-y)*5))));
        if(p.kind=="scalar"||p.kind=="ghost")out.emit("stroke "+name+" dashed");
    };
    auto labels=b.properties.count("labels")?list(b.get("labels")):std::vector<std::string>{};
    if(!labels.empty()&&labels.size()!=4)throw std::runtime_error("labels richiede quattro stringhe LaTeX");
    for(size_t i=0;i<legs.size();++i){
        const auto& l=legs[i];propagator(l.id,l.x,l.y,l.a,l.z,l.p,l.p.anti);
        double x=l.in?l.x:l.a,y=l.in?l.y:l.z;
        std::string label="$"+l.p.label+"$";
        if(!labels.empty()){
            if(labels[i].size()<2||labels[i].front()!='"'||labels[i].back()!='"')throw std::runtime_error("labels: stringhe tra virgolette richieste");
            label=labels[i].substr(1,labels[i].size()-2);
        }
        out.label(l.id+"_label",x,y+(labelPlacement=="fixed"?(y>0?0.35:-0.35):0),label,true);
        if(labelPlacement=="auto")out.emit("placement "+b.id+"."+l.id+"_label auto "+(y>0?"n":"s")+" 3");
    }
    if(b.properties.count("loop")){
        auto loopParticle=particle(b.get("loop"));
        if(loopParticle.kind!="fermion"&&loopParticle.kind!="scalar"&&loopParticle.kind!="ghost"&&loopParticle.kind!="photon")throw std::runtime_error("loop: tipi implementati fermion, scalar, ghost, photon");
        double position=real(b.get("loop-position","0.5"),0.05,0.95),radius=real(b.get("loop-radius","0.25"),0.05,0.5);
        double x=channel=="s"?-0.7:0,y=channel=="s"?0:1.2,a=channel=="s"?0.7:0,z=channel=="s"?0:-1.2;
        double dx=a-x,dy=z-y,length=std::hypot(dx,dy),ux=dx/length,uy=dy/length,cx=x+position*dx,cy=y+position*dy;
        if(radius>=length*std::min(position,1-position))throw std::runtime_error("loop-radius troppo grande per la posizione richiesta");
        propagator("mediator_in",x,y,cx-radius*ux,cy-radius*uy,mediator,false);
        propagator("mediator_out",cx+radius*ux,cy+radius*uy,a,z,mediator,false);
        for(unsigned branch=0;branch<2;++branch){
            std::vector<std::pair<double,double>> points;
            unsigned samples=loopParticle.kind=="photon"?192:48;
            for(unsigned i=0;i<=samples;++i){double t=std::acos(-1.0)*(1-static_cast<double>(i)/samples),r=radius;
                if(loopParticle.kind=="photon")r*=1+0.12*std::sin(16*t)*std::pow(std::sin(t),2);
                double along=r*std::cos(t),side=(branch?-1:1)*r*std::sin(t);points.push_back({cx+along*ux-side*uy,cy+along*uy+side*ux});}
            std::string id=branch?"loop_lower":"loop_upper";out.path(id,points);
            if(loopParticle.kind=="fermion")out.emit("flow "+b.id+"."+id+(branch?" reverse":" forward"));
            else if(loopParticle.kind!="photon")out.emit("stroke "+b.id+"."+id+" dashed");
        }
    }else{
        if(b.properties.count("loop-position")||b.properties.count("loop-radius"))throw std::runtime_error("specifica loop prima delle sue opzioni");
        if(channel=="s")propagator("mediator",-0.7,0,0.7,0,mediator,false);
        else propagator("mediator",0,1.2,0,-1.2,mediator,false);
    }
    out.group(-3,-1.9,3,1.9);
}
}
