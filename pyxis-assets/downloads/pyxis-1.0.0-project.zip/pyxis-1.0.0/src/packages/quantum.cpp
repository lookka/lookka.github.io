#include "common.hpp"
namespace pyxis::packages {
void circuit(const Block& b,Builder& out) {
    if(b.order.empty()||b.order.size()>32)throw std::runtime_error("circuit: da 1 a 32 qubit");
    std::vector<std::vector<std::string>> rows;
    size_t columns=0;
    for(const auto& row:b.order){if(!identifier(row))throw std::runtime_error("nome qubit non valido: "+row);rows.push_back(split(b.get(row)));columns=std::max(columns,rows.back().size());}
    if(columns>128)throw std::runtime_error("circuit: massimo 128 colonne");
    struct Oracle {std::string label;std::vector<size_t> rows;};
    std::map<std::pair<size_t,std::string>,Oracle> oracles;
    for(size_t r=0;r<rows.size();++r)for(size_t c=0;c<rows[r].size();++c){
        const auto& gate=rows[r][c];if(gate.rfind("oracle(",0)!=0)continue;
        if(gate.back()!=')')throw std::runtime_error("oracle non chiuso");
        auto arguments=split(gate.substr(7,gate.size()-8));
        if(arguments.size()!=2||!identifier(arguments[0])||arguments[1].size()<3||arguments[1].front()!='"'||arguments[1].back()!='"')throw std::runtime_error("oracle(id,\"formula LaTeX\") atteso");
        auto text=arguments[1].substr(1,arguments[1].size()-2);if(text.size()>128)throw std::runtime_error("oracle: formula troppo lunga");
        auto& oracle=oracles[{c,arguments[0]}];if(!oracle.rows.empty()&&oracle.label!=text)throw std::runtime_error("oracle: le righe devono condividere la stessa formula");
        oracle.label=text;oracle.rows.push_back(r);
    }
    for(const auto& entry:oracles){const auto& span=entry.second.rows;if(span.size()<2)throw std::runtime_error("oracle richiede almeno due qubit contigui");for(size_t i=1;i<span.size();++i)if(span[i]!=span[i-1]+1)throw std::runtime_error("oracle richiede qubit contigui nella stessa colonna");}
    struct Endpoint{size_t row;bool target;};
    std::map<std::pair<size_t,std::string>,std::vector<Endpoint>> links;
    double step=1.3;
    for(size_t r=0;r<rows.size();++r){
        double y=-1.1*r;out.label(b.order[r]+"_label",-0.65,y,b.order[r]);
        for(size_t c=0;c<=columns;++c)out.line(b.order[r]+"_wire"+std::to_string(c),c*step-0.35,y,(c+1)*step-0.35,y);
        for(size_t c=0;c<rows[r].size();++c){
            auto gate=rows[r][c];std::string id=b.order[r]+"_step"+std::to_string(c+1);double x=(c+0.5)*step;
            if(gate=="_")continue;
            if(gate.rfind("oracle(",0)==0)continue;
            bool ctrl=gate.rfind("control(",0)==0, tgt=gate.rfind("target(",0)==0;
            if(ctrl||tgt){
                if(gate.back()!=')')throw std::runtime_error("gate di controllo non chiuso");
                auto key=gate.substr(ctrl?8:7,gate.size()-(ctrl?9:8));if(!identifier(key))throw std::runtime_error("identificatore del collegamento non valido");
                links[{c,key}].push_back({r,tgt});
                auto dot=out.object("circle",id,num(x)+" "+num(y)+" "+(ctrl?"0.055":"0.16"));
                if(ctrl)out.emit("nodefill "+dot+" black");
                if(tgt)out.line(id+"_plus",x,y-0.16,x,y+0.16);
                continue;
            }
            bool oracle=gate.rfind("gate(\"",0)==0&&gate.size()>=9&&gate.substr(gate.size()-2)=="\")";
            static const std::set<std::string> supported{"H","X","Y","Z","S","T","M"};
            if(!supported.count(gate)&&!oracle)throw std::runtime_error("gate non disponibile: "+gate);
            std::string text=oracle?gate.substr(6,gate.size()-8):gate;
            if(text.size()>12)throw std::runtime_error("gate personalizzato: massimo 12 caratteri in questa versione");
            // Segment gaps avoid any line running through gate labels.
            auto rect=out.object("gatebox",id,num(x)+" "+num(y)+" "+num(std::max(0.65,0.08*text.size()+0.25))+" 0.65");
            (void)rect;
            if(gate=="M"){
                std::vector<std::pair<double,double>> arc;for(unsigned i=0;i<=16;++i){double t=std::acos(-1.0)*i/16;arc.push_back({x+0.22*std::cos(t),y-0.1+0.22*std::sin(t)});}out.path(id+"_meter",arc);out.line(id+"_needle",x,y-0.1,x+0.17,y+0.2,true);
            } else out.label(id+"_label",x,y,text);
        }
    }
    for(const auto& entry:oracles){
        const auto& oracle=entry.second;double x=(entry.first.first+0.5)*step,y=-0.55*(oracle.rows.front()+oracle.rows.back());
        std::string id="oracle_"+entry.first.second+"_"+std::to_string(entry.first.first+1);
        out.object("gatebox",id,num(x)+" "+num(y)+" 1.05 "+num(1.1*(oracle.rows.back()-oracle.rows.front())+0.65));
        out.label(id+"_label",x,y,oracle.label,true);
    }
    for(const auto& link:links){
        auto endpoints=link.second;
        size_t targets=0;for(auto e:endpoints)targets+=e.target;
        auto oracle=oracles.find(link.first);
        if(oracle!=oracles.end()){
            if(targets)throw std::runtime_error("controllo: target e oracle con lo stesso id sono ambigui");
            endpoints.push_back({oracle->second.rows.front(),true});++targets;
        }
        if(targets!=1||endpoints.size()<2)throw std::runtime_error("controllo "+link.first.second+": un target e almeno un control nella stessa colonna richiesti");
        std::sort(endpoints.begin(),endpoints.end(),[](Endpoint a,Endpoint b){return a.row<b.row;});
        double x=(link.first.first+0.5)*step;
        // Connections precede their glyphs in the final scene via an explicit background flag.
        auto name=out.line("link_"+link.first.second+"_"+std::to_string(link.first.first+1),x,-1.1*endpoints.front().row,x,-1.1*endpoints.back().row);
        out.emit("background "+name);
    }
    out.group(-1.2,-1.1*(rows.size()-1)-0.55,(columns+1)*step,0.55);
}

void tensor_network(const Block& b,Builder& out) {
    b.allow({"sites","labels","layout","rows","columns"});auto layout=b.get("layout","mps");
    if(layout!="mps"&&layout!="peps")throw std::runtime_error("tensor-network layout: mps, peps");
    bool peps=layout=="peps";
    if(peps&&b.properties.count("sites"))throw std::runtime_error("PEPS usa rows/columns, non sites");
    if(!peps&&(b.properties.count("rows")||b.properties.count("columns")))throw std::runtime_error("MPS usa sites, non rows/columns");
    unsigned rows=peps?integer(b.get("rows","3"),1,16):1,columns=peps?integer(b.get("columns","3"),1,16):integer(b.get("sites","4"),1,32),sites=rows*columns;
    if(sites>128)throw std::runtime_error("tensor-network: massimo 128 siti");
    auto labels=b.properties.count("labels")?list(b.get("labels")):std::vector<std::string>{};
    if(!labels.empty()&&labels.size()!=sites)throw std::runtime_error("labels richiede una stringa per tensore");
    for(unsigned i=0;i<sites;++i){
        unsigned row=i/columns,column=i%columns;
        double x=1.6*column,y=-1.6*row;std::string id=peps?"r"+std::to_string(row+1)+"c"+std::to_string(column+1):"site"+std::to_string(i+1);
        auto center=out.object("circle",id,num(x)+" "+num(y)+" 0.28");
        if(column+1<columns){auto next=peps?"r"+std::to_string(row+1)+"c"+std::to_string(column+2):"site"+std::to_string(i+2);out.connect(id+"_bond",center+".center",b.id+"."+next+".center");}
        if(row+1<rows)out.connect(id+"_bond_y",center+".center",b.id+".r"+std::to_string(row+2)+"c"+std::to_string(column+1)+".center");
        auto tip=out.object("point",id+"_physical_tip",center+".center");out.emit("move "+tip+(peps?" 0.55 0.6":" 0 0.95"));
        out.connect(id+"_physical",center+".center",tip+".center");
        std::string label="$A_{"+std::to_string(i+1)+"}$";
        if(!labels.empty()){
            if(labels[i].size()<2||labels[i].front()!='"'||labels[i].back()!='"')throw std::runtime_error("labels: stringhe richieste");
            label=labels[i].substr(1,labels[i].size()-2);
        }
        auto annotation=out.object("label",id+"_label",center+".center \""+label+"\"");
        if(!peps)out.emit("move "+annotation+" 0 -0.6");
    }
    out.group(-0.6,-1.6*(rows-1)-1,1.6*(columns-1)+0.85,1.2);
}

void bloch(const Block& b,Builder& out) {
    b.allow({"theta","phi"});
    auto angle=[](const std::string& s){if(s.size()<4)throw std::runtime_error("angolo richiesto con unita': deg oppure rad");auto unit=s.substr(s.size()-3);double v=real(s.substr(0,s.size()-3),-1e6,1e6);if(unit=="deg")return v*std::acos(-1.0)/180;if(unit=="rad")return v;throw std::runtime_error("unita' angolare attesa: deg, rad");};
    double theta=angle(b.get("theta","60deg")),phi=angle(b.get("phi","35deg"));
    if(theta<0||theta>std::acos(-1.0))throw std::runtime_error("theta deve essere tra 0 e 180deg");
    auto sphere=out.object("sphere","sphere","0 0 0 1");out.emit("fill "+sphere+" none");
    for(unsigned axis=0;axis<3;++axis){std::vector<std::array<double,3>> circle;for(unsigned i=0;i<=80;++i){double t=2*std::acos(-1.0)*i/80;std::array<double,3> v{0,0,0};v[(axis+1)%3]=std::cos(t);v[(axis+2)%3]=std::sin(t);circle.push_back(v);}auto name=out.path3("circle"+std::to_string(axis),circle);out.emit("linewidth "+name+" 0.25");out.emit("stroke "+name+" dashed");}
    out.path3("x",{{-1.2,0,0},{1.2,0,0}},true);out.path3("y",{{0,-1.2,0},{0,1.2,0}},true);out.path3("z",{{0,0,-1.2},{0,0,1.2}},true);
    auto state=out.path3("state",{{0,0,0},{std::sin(theta)*std::cos(phi),std::sin(theta)*std::sin(phi),std::cos(theta)}},true);
    out.emit("linewidth "+state+" 1.3");out.emit("color "+state+" 0.18 0.36 0.55");
    out.object("label3","zero","0 0 1.4 \"$\\vert0\\rangle$\"");out.object("label3","one","0 0 -1.4 \"$\\vert1\\rangle$\"");
    out.object("label3","plus","1.4 0 0 \"$\\vert+\\rangle$\"");out.object("label3","minus","-1.4 0 0 \"$\\vert-\\rangle$\"");
}
}
