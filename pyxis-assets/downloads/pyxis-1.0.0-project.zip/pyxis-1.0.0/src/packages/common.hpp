#pragma once
#include "../semantic.hpp"
#include "../expression.hpp"
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <functional>
#include <iomanip>
#include <locale>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>


namespace pyxis::packages {
inline std::string trim(const std::string& s) {
    auto a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? "" : s.substr(a, b-a+1);
}
inline std::string clean(const std::string& s) {
    bool quote = false;
    for (size_t i=0; i<s.size(); ++i) {
        if (s[i]=='"') quote=!quote;
        if (!quote && s[i]=='#') return trim(s.substr(0,i));
    }
    return trim(s);
}
inline std::vector<std::string> split(const std::string& s) {
    std::vector<std::string> out;
    size_t start=0; int depth=0; bool quote=false;
    for (size_t i=0;i<s.size();++i) {
        char c=s[i];
        if(c=='"') quote=!quote;
        if(!quote) {
            if(c=='('||c=='[') ++depth;
            if(c==')'||c==']') --depth;
            if(depth<0) throw std::runtime_error("parentesi non bilanciate");
            if(c==',' && depth==0) {out.push_back(trim(s.substr(start,i-start)));start=i+1;}
        }
    }
    if(quote||depth) throw std::runtime_error("stringa o parentesi non chiusa");
    out.push_back(trim(s.substr(start)));
    for(const auto& v:out) if(v.empty()) throw std::runtime_error("elemento di lista vuoto");
    return out;
}
inline std::vector<std::string> list(std::string s) {
    s=trim(s);
    if(s.size()<2||s.front()!='['||s.back()!=']') throw std::runtime_error("lista attesa: [elementi]");
    s=trim(s.substr(1,s.size()-2));
    return s.empty()?std::vector<std::string>{}:split(s);
}
inline bool identifier(const std::string& s) {
    if(s.empty() || !(std::isalpha(static_cast<unsigned char>(s[0]))||s[0]=='_')) return false;
    return std::all_of(s.begin(),s.end(),[](unsigned char c){return std::isalnum(c)||c=='_';});
}
inline double real(const std::string& s, double low, double high) {
    std::istringstream in(s); in.imbue(std::locale::classic());
    double v; if(!(in>>v)||!std::isfinite(v)) throw std::runtime_error("numero finito atteso");
    in>>std::ws;
    if(!in.eof()||v<low||v>high) throw std::runtime_error("valore fuori intervallo: "+s);
    return v;
}
inline unsigned integer(const std::string& s, unsigned low,unsigned high) {
    double v=real(s,low,high);
    if(std::floor(v)!=v) throw std::runtime_error("intero atteso: "+s);
    return static_cast<unsigned>(v);
}
inline std::string num(double v) {
    std::ostringstream s; s.imbue(std::locale::classic());s<<std::setprecision(17)<<v;return s.str();
}
struct Block {
    std::string type,id; size_t line;
    std::map<std::string,SourceLine> properties;
    std::vector<std::string> order;
    std::string get(const std::string& k,const std::string& fallback="") const {
        auto it=properties.find(k);return it==properties.end()?fallback:it->second.text;
    }
    void allow(const std::set<std::string>& keys) const {
        for(const auto& p:properties) if(!keys.count(p.first))
            throw std::runtime_error("riga "+std::to_string(p.second.number)+": proprieta' sconosciuta: "+p.first);
    }
};
struct Builder {
    std::vector<SourceLine>& output; const Block& b;
    std::vector<std::string> members;
    void emit(const std::string& s) {output.push_back({s,b.line});}
    std::string object(const std::string& type,const std::string& local,const std::string& args) {
        std::string id=b.id+"."+local;
        members.push_back(id);emit(type+" "+id+" "+args);return id;
    }
    std::string line(const std::string& local,double x,double y,double a,double z,bool arrow=false) {
        return object(arrow?"arrow":"line",local,num(x)+" "+num(y)+" "+num(a)+" "+num(z));
    }
    std::string connect(const std::string& local,const std::string& from,const std::string& to) {
        auto name=object("line",local,from+" "+to);emit("clip "+name+" nodes");return name;
    }
    void label(const std::string& local,double x,double y,const std::string& text,bool tex=false) {
        object(tex?"label":"text",local,num(x)+" "+num(y)+" \""+text+"\"");
    }
    void path(const std::string& local,const std::vector<std::pair<double,double>>& points) {
        std::string s="\"";for(size_t i=0;i<points.size();++i){if(i)s+=';';s+=num(points[i].first)+" "+num(points[i].second);} object("path",local,s+"\"");
    }
    void box(const std::string& local,double x,double y,double w,double h) {
        path(local,{{x-w/2,y-h/2},{x+w/2,y-h/2},{x+w/2,y+h/2},{x-w/2,y+h/2},{x-w/2,y-h/2}});
    }
    std::string path3(const std::string& local,const std::vector<std::array<double,3>>& vertices,bool arrow=false) {
        std::string s="\"";for(size_t i=0;i<vertices.size();++i){if(i)s+=';';s+=num(vertices[i][0])+" "+num(vertices[i][1])+" "+num(vertices[i][2]);}
        auto name=object(arrow?"arrow3":"path3",local,s+"\"");emit("color "+name+" 0 0 0");return name;
    }
    void group(double x,double y,double a,double z) {
        std::string s="_group "+b.id+" "+num(x)+" "+num(y)+" "+num(a)+" "+num(z);
        for(const auto& m:members)s+=" "+m;
        emit(s);
    }
};
void feynman(const Block&, Builder&);
void circuit(const Block&, Builder&);
void tensor_network(const Block&, Builder&);
void bloch(const Block&, Builder&);
void ising(const Block&, Builder&);
void phase_flow(const Block&, Builder&);
void phase_diagram(const Block&, Builder&);
void lorenz(const Block&, Builder&);
void penrose(const Block&, Builder&);
void embedding(const Block&, Builder&);
void light_cones(const Block&, Builder&);
void geodesic(const Block&, Builder&);
}
