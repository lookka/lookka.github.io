#include "common.hpp"
#include "../numerics.hpp"
#include <tuple>
namespace pyxis::packages {
namespace {
numerics::Options integration_options(const Block& b, double duration, unsigned steps) {
    numerics::Options options;
    options.duration=duration; options.steps=steps;
    auto method=b.get("integrator","rk4");
    if(method!="rk4"&&method!="adaptive") throw std::runtime_error("integrator: rk4 oppure adaptive");
    options.adaptive=method=="adaptive";
    for(const auto& key:{"abs-tol","rel-tol","max-step","max-steps"})
        if(!options.adaptive&&b.properties.count(key)) throw std::runtime_error(std::string(key)+" richiede integrator: adaptive");
    options.absolute_tolerance=real(b.get("abs-tol","1e-8"),1e-14,1);
    options.relative_tolerance=real(b.get("rel-tol","1e-6"),0,1);
    options.maximum_step=real(b.get("max-step",num(duration/steps)),1e-12,1e4);
    options.maximum_steps=integer(b.get("max-steps","9999"),1,9999);
    return options;
}
}
void ising(const Block& b,Builder& out) {
    b.allow({"rows","columns","state","spins","dimension","layers"});
    unsigned rows=integer(b.get("rows","4"),1,32), cols=integer(b.get("columns","4"),1,32);
    unsigned dimension=integer(b.get("dimension","2"),2,3),layers=dimension==3?integer(b.get("layers","3"),1,16):1;
    if(dimension==2&&b.properties.count("layers"))throw std::runtime_error("layers richiede dimension: 3");
    if(dimension==3&&rows*cols*layers>512)throw std::runtime_error("Ising 3D: massimo 512 siti");
    auto state=b.get("state","up");
    if(state!="up"&&state!="down"&&state!="checkerboard"&&state!="domains")throw std::runtime_error("state: up, down, checkerboard, domains");
    auto spins=b.properties.count("spins")?list(b.get("spins")):std::vector<std::string>{};
    if(!spins.empty()&&spins.size()!=rows*cols*layers)throw std::runtime_error("spins: un valore +1 o -1 per sito, per strati e righe");
    if(dimension==3){
        for(unsigned layer=0;layer<layers;++layer)for(unsigned r=0;r<rows;++r)for(unsigned c=0;c<cols;++c){
            std::string id="l"+std::to_string(layer+1)+"r"+std::to_string(r+1)+"c"+std::to_string(c+1);
            std::array<double,3> p{static_cast<double>(c),-static_cast<double>(r),static_cast<double>(layer)};
            auto bond=[&](const std::string& suffix,unsigned axis,double delta){auto q=p;q[axis]+=delta;auto name=out.path3(id+suffix,{p,q});out.emit("linewidth "+name+" 0.2");out.emit("color "+name+" 0.65 0.65 0.65");};
            if(c+1<cols)bond("_bond_x",0,1);
            if(r+1<rows)bond("_bond_y",1,-1);
            if(layer+1<layers)bond("_bond_z",2,1);
            int sign=state=="down"?-1:state=="checkerboard"?((r+c+layer)%2?-1:1):state=="domains"?(c<cols/2?1:-1):1;
            if(!spins.empty()){auto spin=spins[(layer*rows+r)*cols+c];if(spin!="1"&&spin!="+1"&&spin!="-1")throw std::runtime_error("spin atteso: +1 o -1");sign=spin=="-1"?-1:1;}
            auto from=p,to=p;from[2]-=0.28*sign;to[2]+=0.28*sign;out.path3(id+"_spin",{from,to},true);
        }
        return;
    }
    for(unsigned r=0;r<rows;++r)for(unsigned c=0;c<cols;++c){
        std::string id="r"+std::to_string(r+1)+"c"+std::to_string(c+1);double x=c,y=-static_cast<double>(r);
        if(c+1<cols){auto l=out.line(id+"_bond_x",x,y,x+1,y);out.emit("stroke "+l+" dotted");}
        if(r+1<rows){auto l=out.line(id+"_bond_y",x,y,x,y-1);out.emit("stroke "+l+" dotted");}
        int sign=state=="down"?-1:state=="checkerboard"?((r+c)%2?-1:1):state=="domains"?(c<cols/2?1:-1):1;
        if(!spins.empty()){if(spins[r*cols+c]!="1"&&spins[r*cols+c]!="+1"&&spins[r*cols+c]!="-1")throw std::runtime_error("spin atteso: +1 o -1");sign=spins[r*cols+c]=="-1"?-1:1;}
        out.line(id+"_spin",x,y-0.3*sign,x,y+0.3*sign,true);
    }
    out.group(-0.6,-static_cast<double>(rows)+0.4,cols-0.4,0.6);
}

void phase_flow(const Block& b,Builder& out) {
    b.allow({"dx","dy","start","duration","steps","integrator","abs-tol","rel-tol","max-step","max-steps"});
    auto expression=[&](const std::string& key,const std::string& fallback){auto s=b.get(key,fallback);if(s.size()<2||s.front()!='"'||s.back()!='"')throw std::runtime_error("equazione tra virgolette richiesta: "+key);return s.substr(1,s.size()-2);};
    auto dx=expression("dx","\"y\""),dy=expression("dy","\"-x\"");
    auto initial=list(b.get("start","[1, 0]"));if(initial.size()!=2)throw std::runtime_error("start richiede due valori");
    double x=real(initial[0],-1e6,1e6),y=real(initial[1],-1e6,1e6);
    double duration=real(b.get("duration","6.283185307179586"),1e-6,1e4);unsigned steps=integer(b.get("steps","400"),4,9999);
    auto options=integration_options(b,duration,steps);
    auto derivative=[&](const std::array<double,2>& p,double t){std::unordered_map<std::string,double> vars{{"y",p[1]},{"t",t}};return std::array<double,2>{evaluate(dx,p[0],vars,{}),evaluate(dy,p[0],vars,{})};};
    auto trajectory=numerics::integrate<2>({x,y},options,derivative);
    std::vector<std::pair<double,double>> points;
    double left=x,right=x,bottom=y,top=y;
    for(const auto& p:trajectory.points){x=p[0];y=p[1];
        points.push_back({x,y});left=std::min(left,x);right=std::max(right,x);bottom=std::min(bottom,y);top=std::max(top,y);
    }
    out.path("orbit",points);out.emit("flow "+b.id+".orbit forward");
    out.object("point","caption",num((left+right)/2)+" "+num(bottom-0.5));
    out.group(left-0.5,bottom-0.5,right+0.5,top+0.5);
}

void phase_diagram(const Block& b,Builder& out) {
    b.allow({"model","melting","labels","point-labels","opacity"});
    if(b.get("model","schematic")!="schematic")throw std::runtime_error("phase-diagram: modello disponibile schematic");
    auto melting=b.get("melting","positive");if(melting!="positive"&&melting!="negative")throw std::runtime_error("melting: positive, negative");
    double alpha=real(b.get("opacity","0.22"),0,1);
    auto labels=b.properties.count("labels")?list(b.get("labels")):std::vector<std::string>{"\"Solid\"","\"Liquid\"","\"Gas\"","\"Supercritical\""};
    if(labels.size()!=4)throw std::runtime_error("labels: quattro stringhe per solid/liquid/gas/supercritical");
    for(auto& label:labels){if(label.size()<2||label.front()!='"'||label.back()!='"')throw std::runtime_error("labels: stringhe richieste");label=label.substr(1,label.size()-2);}
    auto pointLabels=b.properties.count("point-labels")?list(b.get("point-labels")):std::vector<std::string>{"\"TP\"","\"CP\""};
    if(pointLabels.size()!=2)throw std::runtime_error("point-labels: due stringhe per punto triplo e critico");
    for(auto& label:pointLabels){if(label.size()<2||label.front()!='"'||label.back()!='"')throw std::runtime_error("point-labels: stringhe richieste");label=label.substr(1,label.size()-2);}
    const double tx=2,ty=1.5,cx=4.6,cy=3.2,top=4.4,right=6;
    const double mx=melting=="positive"?2.65:1.1;
    std::vector<std::pair<double,double>> sublimation,vaporization;
    for(unsigned i=0;i<=40;++i){double t=static_cast<double>(i)/40;sublimation.push_back({tx*t,ty*t*t});vaporization.push_back({tx+(cx-tx)*t,ty+(cy-ty)*(0.65*t+0.35*t*t)});}
    auto region=[&](const std::string& id,std::vector<std::pair<double,double>> vertices,const std::string& color){
        std::string specification="\"";for(size_t i=0;i<vertices.size();++i){if(i)specification+=';';specification+=num(vertices[i].first)+" "+num(vertices[i].second);}auto name=out.object("region",id,specification+"\"");out.emit("color "+name+" "+color);out.emit("opacity "+name+" "+num(alpha));out.emit("outline "+name+" off");
    };
    auto solid=sublimation;solid.push_back({mx,top});solid.push_back({0,top});
    region("solid",solid,"0.25 0.45 0.7");
    auto liquid=vaporization;liquid.push_back({cx,top});liquid.push_back({mx,top});
    region("liquid",liquid,"0.3 0.65 0.48");
    auto gas=sublimation;gas.insert(gas.end(),vaporization.begin()+1,vaporization.end());gas.push_back({right,cy});gas.push_back({right,0});
    region("gas",gas,"0.9 0.64 0.2");
    region("supercritical",{{cx,cy},{right,cy},{right,top},{cx,top}},"0.62 0.46 0.7");
    out.path("sublimation",sublimation);out.path("vaporization",vaporization);out.line("melting",tx,ty,mx,top);
    out.line("temperature_axis",0,0,right+0.3,0,true);out.line("pressure_axis",0,0,0,top+0.3,true);
    out.label("temperature",right+0.25,-0.3,"$T$",true);out.label("pressure",-0.3,top+0.25,"$P$",true);
    out.label("solid_label",0.75,2.5,labels[0]);out.label("liquid_label",3.25,3.1,labels[1]);out.label("gas_label",3.8,0.65,labels[2]);out.label("supercritical_label",5.3,3.8,labels[3]);
    for(const auto& marker:std::vector<std::tuple<std::string,double,double>>{{"triple",tx,ty},{"critical",cx,cy}}){
        auto name=out.object("circle",std::get<0>(marker),num(std::get<1>(marker))+" "+num(std::get<2>(marker))+" 0.055");out.emit("nodefill "+name+" black");
        auto annotation=out.object("text",std::get<0>(marker)+"_label",name+".center \""+pointLabels[std::get<0>(marker)=="triple"?0:1]+"\"");out.emit("placement "+annotation+" auto se 4");
    }
    out.group(-0.5,-0.55,right+0.65,top+0.65);
}

void lorenz(const Block& b,Builder& out) {
    b.allow({"sigma","rho","beta","start","duration","steps","integrator","abs-tol","rel-tol","max-step","max-steps"});
    double sigma=real(b.get("sigma","10"),0.001,100),rho=real(b.get("rho","28"),0.001,100),beta=real(b.get("beta","2.6666666666666665"),0.001,100);
    auto initial=list(b.get("start","[1, 1, 1]"));if(initial.size()!=3)throw std::runtime_error("start richiede tre valori");
    std::array<double,3> p{real(initial[0],-1000,1000),real(initial[1],-1000,1000),real(initial[2],-1000,1000)};
    double duration=real(b.get("duration","30"),1e-4,100);unsigned steps=integer(b.get("steps","6000"),10,9999);double h=duration/steps;
    auto options=integration_options(b,duration,steps);
    if(!options.adaptive&&h>0.02)throw std::runtime_error("Lorenz: duration/steps deve essere <=0.02");
    if(options.adaptive&&options.maximum_step>0.02)throw std::runtime_error("Lorenz: max-step deve essere <=0.02");
    auto d=[&](const std::array<double,3>& v,double){return std::array<double,3>{sigma*(v[1]-v[0]),v[0]*(rho-v[2])-v[1],v[0]*v[1]-beta*v[2]};};
    auto trajectory=numerics::integrate<3>(p,options,d);
    auto name=out.path3("orbit",trajectory.points);out.emit("linewidth "+name+" 0.35");
}
}
