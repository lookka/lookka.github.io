#include "constraints.hpp"
#include <algorithm>
#include <cmath>
#include <map>
#include <stdexcept>
namespace pyxis {
void resolve_constraint(Scene& scene, Object& object, const std::function<void(size_t)>& resolve) {
    if(object.constraint.empty()) return;
    auto target=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object& o){return o.name==object.constraint_reference;});
    if(target==scene.objects.end())throw std::runtime_error("vincolo di "+object.name+": oggetto sconosciuto "+object.constraint_reference);
    resolve(static_cast<size_t>(target-scene.objects.begin()));
    if(object.constraint=="tangent-circle"){
        if(target->kind!=Kind::Circle)throw std::runtime_error("tangent-to richiede un cerchio: "+target->name);
        if(object.x!=0||object.y!=0)throw std::runtime_error("offset/move incompatibile con la tangenza di "+object.name);
        static const std::map<std::string,std::pair<double,double>> directions{
            {"east",{1,0}},{"west",{-1,0}},{"north",{0,1}},{"south",{0,-1}},
            {"ne",{1,1}},{"nw",{-1,1}},{"se",{1,-1}},{"sw",{-1,-1}}};
        auto direction=directions.find(object.constraint_direction);
        if(direction==directions.end())throw std::runtime_error("direction: north, south, east, west, ne, nw, se, sw");
        auto v=direction->second;double distance=target->a+object.a,length=std::hypot(v.first,v.second);
        object.x=target->x+distance*v.first/length;object.y=target->y+distance*v.second/length;
    }else{
        auto straight=[](const Object& o){return(o.kind==Kind::Line||o.kind==Kind::Arrow)&&o.bend==0&&o.controls.empty()&&o.wave_turns==0;};
        if(!straight(*target)||!straight(object))throw std::runtime_error("parallel/perpendicular richiedono segmenti rettilinei: "+object.name);
        double dx=target->a-target->x,dy=target->b-target->y,length=std::hypot(dx,dy);
        if(!std::isfinite(length)||length==0)throw std::runtime_error("direzione del vincolo non definita: "+target->name);
        dx/=length;dy/=length;
        if(object.constraint=="perpendicular"){double swap=dx;dx=-dy;dy=swap;}
        double x=object.x,y=object.y,half=object.constraint_length/2;
        object.x=x-half*dx;object.y=y-half*dy;object.a=x+half*dx;object.b=y+half*dy;
    }
}
void resolve_clipping(Scene& scene) {
    auto endpoint=[&](const std::string& anchor,double x,double y)->std::string{
        if(anchor.empty()||anchor.front()=='@')return "";
        auto dot=anchor.rfind('.');auto id=anchor.substr(0,dot);
        auto target=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object& o){return o.name==id;});
        if(target==scene.objects.end())throw std::runtime_error("nodo di clipping sconosciuto: "+id);
        if(target->kind==Kind::Point)return "";
        if(target->kind==Kind::Label||target->kind==Kind::Text){
            if(target->automatic_label||target->text.empty())throw std::runtime_error("clip richiede un'etichetta fissa non vuota: "+id);
            return id;
        }
        double dx=x-target->x,dy=y-target->y;
        if(target->kind==Kind::Circle||target->kind==Kind::Ellipse){
            double ry=target->kind==Kind::Circle?target->a:target->b;
            if(std::hypot(dx/target->a,dy/ry)<1-1e-12)return id;
            return "";
        }
        if(target->kind==Kind::GateBox){
            if(std::abs(dx)<target->a/2-1e-12&&std::abs(dy)<target->b/2-1e-12)return id;
            return "";
        }
        throw std::runtime_error("clip nodes richiede cerchi, ellissi o gatebox: "+id);
    };
    for(auto& o:scene.objects)if(o.clip_nodes){
        if(!o.constraint.empty())throw std::runtime_error("clip nodes usa from/to, non il punto through di "+o.name);
        auto namedAnchor=[](const std::string& anchor){return !anchor.empty()&&anchor.front()!='@'&&anchor.rfind('.')!=std::string::npos;};
        if(!namedAnchor(o.start_anchor)&&!namedAnchor(o.end_anchor)&&!std::any_of(o.point_anchors.begin(),o.point_anchors.end(),namedAnchor))
            throw std::runtime_error("clip nodes richiede estremi con ancoraggi nominati: "+o.name);
        if(o.kind==Kind::Line||o.kind==Kind::Arrow){o.clip_start=endpoint(o.start_anchor,o.x,o.y);o.clip_end=endpoint(o.end_anchor,o.a,o.b);}
        else if(o.kind==Kind::Path){
            o.clip_start=endpoint(o.point_anchors.front(),o.points.front().first,o.points.front().second);
            o.clip_end=endpoint(o.point_anchors.back(),o.points.back().first,o.points.back().second);
        }else throw std::runtime_error("clip nodes richiede line, arrow o path");
    }
}
}
