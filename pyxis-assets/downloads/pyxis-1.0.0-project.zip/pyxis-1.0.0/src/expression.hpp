#pragma once
#include <string>
#include <unordered_map>
namespace pyxis {
double evaluate(const std::string& expression, double x,
                const std::unordered_map<std::string, double>& variables,
                const std::unordered_map<std::string, std::string>& functions,
                unsigned depth = 0);
}
