#include "syntax.hpp"
#include "semantic.hpp"
#include <algorithm>
#include <cctype>
#include <map>
#include <sstream>
#include <stdexcept>
#include <set>

namespace pyxis {
namespace {
std::string trim(std::string value) {
    auto first = value.find_first_not_of(" \t\r\n"), last = value.find_last_not_of(" \t\r\n");
    return first == std::string::npos ? "" : value.substr(first, last - first + 1);
}
std::string without_comment(const std::string& value) {
    bool quoted = false;
    for (size_t i = 0; i < value.size(); ++i) {
        if (value[i] == '"') quoted = !quoted;
        if (!quoted && value[i] == '#') return value.substr(0, i);
    }
    return value;
}
std::string coordinates(std::string value) {
    value = trim(value);
    if (value.size() >= 2 && value.front() == '(' && value.back() == ')') value = value.substr(1, value.size() - 2);
    std::replace(value.begin(), value.end(), ',', ' ');
    return trim(value);
}
std::string call_contents(const std::string& value, const std::string& function) {
    if (value.size() <= function.size() + 2 || value.substr(0, function.size() + 1) != function + "(" || value.back() != ')') return "";
    return coordinates(value.substr(function.size() + 1, value.size() - function.size() - 2));
}
}
std::vector<SourceLine> normalize(std::istream& input) {
    const auto lines = semantic(input);
    std::vector<SourceLine> result;
    std::string raw;
    size_t line_number = 0;
    for (size_t cursor = 0; cursor < lines.size(); ++cursor) {
        raw = lines[cursor].text;
        line_number = lines[cursor].number;
        auto line = trim(without_comment(raw));
        // Braces in quoted LaTeX strings do not introduce object blocks.
        if (line.empty() || line.back() != '{' || line.find('"') != std::string::npos) { result.push_back({raw, line_number}); continue; }
        size_t header_line = line_number;
        std::istringstream header(line.substr(0, line.size() - 1));
        std::string kind, id, extra;
        if (!(header >> kind >> id) || header >> extra) throw std::runtime_error("riga " + std::to_string(line_number) + ": intestazione attesa: tipo nome {");
        const std::set<std::string> supported{"circle","ellipse","line","arrow","path","region","label","text","sphere","surface","label3","text3","point"};
        if (!supported.count(kind)) throw std::runtime_error("riga " + std::to_string(line_number) + ": tipo di oggetto non disponibile: " + kind);
        std::map<std::string, SourceLine> properties;
        bool closed = false;
        while (++cursor < lines.size()) {
            raw = lines[cursor].text;
            line_number = lines[cursor].number;
            auto property = trim(without_comment(raw));
            if (property.empty()) continue;
            if (property == "}") { closed = true; break; }
            auto colon = property.find(':');
            if (colon == std::string::npos) throw std::runtime_error("riga " + std::to_string(line_number) + ": proprieta' attesa: nome: valore");
            auto key = trim(property.substr(0, colon)), value = trim(property.substr(colon + 1));
            if (key.empty() || value.empty() || properties.count(key)) throw std::runtime_error("riga " + std::to_string(line_number) + ": proprieta' vuota o duplicata");
            properties.emplace(key, SourceLine{value, line_number});
        }
        if (!closed) throw std::runtime_error("riga " + std::to_string(header_line) + ": blocco non chiuso");
        auto value = [&](const std::string& key, const std::string& fallback) {
            auto p = properties.find(key); return p == properties.end() ? fallback : p->second.text;
        };
        auto emit = [&](const std::string& command, const std::string& property = "") {
            auto p = properties.find(property);
            result.push_back({command, p == properties.end() ? header_line : p->second.number});
        };
        std::set<std::string> allowed;
        if(kind=="point"){
            allowed={"at"};emit("point "+id+" "+coordinates(value("at","0 0")),"at");
        }else if (kind == "circle") {
            allowed = {"center","radius","stroke","tangent-to","direction"};
            if(properties.count("tangent-to")){
                if(properties.count("center"))throw std::runtime_error("riga "+std::to_string(header_line)+": center e tangent-to incompatibili");
                emit("tangent-circle "+id+" "+value("tangent-to","")+" "+value("direction","east")+" "+value("radius","1"),"tangent-to");
            }else{
                if(properties.count("direction"))throw std::runtime_error("riga "+std::to_string(header_line)+": direction richiede tangent-to");
                emit("circle " + id + " " + coordinates(value("center", "0 0")) + " " + value("radius", "1"));
            }
        } else if (kind == "ellipse") {
            allowed = {"center","radii","stroke"};
            emit("ellipse " + id + " " + coordinates(value("center", "0 0")) + " " + coordinates(value("radii", "1 0.5")));
        } else if (kind == "sphere") {
            allowed = {"center","radius","color","fill","detail","shading"};
            emit("sphere " + id + " " + coordinates(value("center", "0 0 0")) + " " + value("radius", "1"));
        } else if (kind == "line" || kind == "arrow") {
            allowed = {"from","to","path","route","stroke","markers","controls","through","parallel-to","perpendicular-to","length","clip"};
            bool parallel=properties.count("parallel-to"),perpendicular=properties.count("perpendicular-to");
            if(parallel||perpendicular){
                if(parallel&&perpendicular)throw std::runtime_error("riga "+std::to_string(header_line)+": parallel-to e perpendicular-to incompatibili");
                if(!properties.count("through")||properties.count("from")||properties.count("to"))throw std::runtime_error("riga "+std::to_string(header_line)+": vincolo richiede through, senza from/to");
                auto relation=parallel?"parallel":"perpendicular";
                emit(std::string(relation)+(kind=="arrow"?"-arrow":"")+" "+id+" "+coordinates(value("through",""))+" "+value(std::string(relation)+"-to","")+" "+value("length","2"),std::string(relation)+"-to");
            }else{
                if(properties.count("through")||properties.count("length"))throw std::runtime_error("riga "+std::to_string(header_line)+": through/length richiedono parallel-to o perpendicular-to");
                emit(kind + " " + id + " " + coordinates(value("from", "-0.5 0")) + " " + coordinates(value("to", "0.5 0")));
            }
        } else if (kind == "region") {
            allowed = {"points","color","fill","opacity","stroke","outline"};
            if(!properties.count("points"))throw std::runtime_error("riga "+std::to_string(header_line)+": region richiede points");
            emit("region "+id+" "+value("points",""),"points");
        } else if (kind == "path") {
            allowed = {"points","route","stroke","markers","controls","clip"};
            emit("path " + id + " " + value("points", "\"-0.5 0;0.5 0\""), "points");
        } else if (kind == "surface") {
            allowed = {"xrange","yrange","mesh","formula","color","fill"};
            emit("surface " + id + " " + coordinates(value("xrange", "-3 3")) + " " + coordinates(value("yrange", "-3 3")) + " " + value("mesh", "16") + " " + value("formula", "\"0\""), "formula");
        } else {
            allowed = {"at","text"};
            if(kind=="label"||kind=="text")allowed.insert({"placement","prefer","gap"});
            emit(kind + " " + id + " " + coordinates(value("at", kind == "label3" || kind == "text3" ? "0 0 0" : "0 0")) + " " + value("text", "\"\""), "text");
        }
        allowed.insert("offset");
        if(kind=="circle"||kind=="ellipse"||kind=="line"||kind=="arrow"||kind=="path")allowed.insert("color");
        if (kind != "label" && kind != "text" && kind != "label3" && kind != "text3" && kind!="point") allowed.insert("stroke-width");
        for (const auto& p : properties) if (!allowed.count(p.first))
            throw std::runtime_error("riga " + std::to_string(p.second.number) + ": proprieta' sconosciuta per " + kind + ": " + p.first);
        if(properties.count("prefer")||properties.count("gap")){
            if(value("placement","fixed")!="auto")throw std::runtime_error("riga "+std::to_string(header_line)+": prefer/gap richiedono placement: auto");
        }
        if(properties.count("placement"))emit("placement "+id+" "+value("placement","fixed")+" "+value("prefer","n")+" "+value("gap","3"),"placement");
        if (properties.count("route") && properties.count("path")) throw std::runtime_error("riga " + std::to_string(header_line) + ": scegli una sola proprieta' tra route e path");
        const std::string route_key = properties.count("route") ? "route" : "path";
        if (properties.count(route_key)) {
            auto route = properties.at(route_key).text;
            if (route == "straight") emit("bend " + id + " 0", route_key);
            else if (!call_contents(route, "arc").empty()) emit("bend " + id + " " + call_contents(route, "arc"), route_key);
            else if (!call_contents(route, "wave").empty()) emit("wave " + id + " " + call_contents(route, "wave"), route_key);
            else throw std::runtime_error("riga " + std::to_string(properties.at(route_key).number) + ": percorso atteso: straight, arc(altezza), wave(ampiezza,oscillazioni)");
        }
        for (const auto& key : {"stroke","stroke-width","markers","controls","color","fill","opacity","outline","detail","shading","offset","clip"}) if (properties.count(key)) {
            std::string property = properties.at(key).text;
            if (std::string(key) == "markers") {
                auto bracket = property.find('(');
                if (bracket != std::string::npos && property.back() == ')') property = property.substr(0, bracket) + " " + coordinates(property.substr(bracket + 1, property.size() - bracket - 2));
            }
            if (std::string(key) == "color" || std::string(key) == "offset") property = coordinates(property);
            std::string operation = key;
            if (operation == "controls") operation = "curve";
            if (operation == "stroke-width") operation = "linewidth";
            if (operation == "offset") operation = kind == "sphere" || kind == "surface" || kind == "label3" || kind == "text3" ? "move3" : "move";
            emit(operation + " " + id + " " + property, key);
        }
    }
    if (input.bad()) throw std::runtime_error("errore durante la lettura del sorgente");
    return result;
}
}
