#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <functional>
#include <stdexcept>
#include <vector>

namespace pyxis::numerics {
struct Options {
    bool adaptive = false;
    double duration = 1, absolute_tolerance = 1e-8, relative_tolerance = 1e-6;
    double maximum_step = 0.01;
    unsigned steps = 100, maximum_steps = 9999;
};
template<size_t N> struct Trajectory {
    std::vector<std::array<double,N>> points;
    std::vector<double> times;
    unsigned rejected_steps = 0;
    bool stopped = false;
};
template<size_t N, class Derivative>
std::array<double,N> rk4(const std::array<double,N>& y, double t, double h, Derivative& derivative) {
    auto add = [&](const auto& k, double scale) {
        auto value=y;
        for(size_t i=0;i<N;++i) value[i]+=scale*k[i];
        return value;
    };
    auto k1=derivative(y,t), k2=derivative(add(k1,h/2),t+h/2);
    auto k3=derivative(add(k2,h/2),t+h/2), k4=derivative(add(k3,h),t+h);
    auto next=y;
    for(size_t i=0;i<N;++i) {
        next[i]+=h*(k1[i]+2*k2[i]+2*k3[i]+k4[i])/6;
        if(!std::isfinite(next[i])) throw std::runtime_error("integrazione: stato non finito");
    }
    return next;
}
template<size_t N, class Derivative>
Trajectory<N> integrate(std::array<double,N> y, const Options& options, Derivative derivative,
                        std::function<bool(const std::array<double,N>&,double)> event = {}) {
    if(!std::isfinite(options.duration)||options.duration<=0||options.steps==0||options.maximum_steps==0)
        throw std::runtime_error("integrazione: durata e numero di passi devono essere positivi");
    if(options.adaptive&&(!std::isfinite(options.maximum_step)||options.maximum_step<=0||
       !std::isfinite(options.absolute_tolerance)||options.absolute_tolerance<=0||
       !std::isfinite(options.relative_tolerance)||options.relative_tolerance<0))
        throw std::runtime_error("integrazione: passo massimo e tolleranze non validi");
    for(double value:y) if(!std::isfinite(value)||std::abs(value)>1e6)
        throw std::runtime_error("integrazione: stato iniziale non valido");
    Trajectory<N> result{{y},{0},0};
    if(event&&event(y,0)){result.stopped=true;return result;}
    double t=0, h=options.adaptive?options.maximum_step:options.duration/options.steps;
    unsigned attempts=0;
    while(t<options.duration) {
        if(++attempts>20*options.maximum_steps) throw std::runtime_error("integrazione: troppi tentativi, modifica tolleranze o durata");
        bool final=h>=options.duration-t;
        double step=std::min(h,options.duration-t);
        if(t+step==t) throw std::runtime_error("integrazione: passo sotto la precisione disponibile");
        auto next=rk4(y,t,step,derivative);
        double error=0;
        if(options.adaptive) {
            auto half=rk4(y,t,step/2,derivative);
            auto fine=rk4(half,t+step/2,step/2,derivative);
            for(size_t i=0;i<N;++i) {
                double scale=options.absolute_tolerance+options.relative_tolerance*std::max(std::abs(y[i]),std::abs(fine[i]));
                // RK4 local error scales as h^5: two half steps have 1/16
                // of the coarse error, so their estimate is (fine-coarse)/15.
                error=std::max(error,std::abs(fine[i]-next[i])/(15*scale));
            }
            next=fine;
            double factor=error==0?2:std::clamp(0.9*std::pow(error,-0.2),0.2,2.0);
            h=std::min(options.maximum_step,step*factor);
            if(error>1) { ++result.rejected_steps; continue; }
        }
        if(event&&event(next,t+step)){
            double lo=0,hi=step;
            auto advance=[&](double dt){auto value=rk4(y,t,dt,derivative);if(options.adaptive){auto half=rk4(y,t,dt/2,derivative);value=rk4(half,t+dt/2,dt/2,derivative);}return value;};
            for(unsigned iteration=0;iteration<48;++iteration){double mid=(lo+hi)/2;if(mid==lo||mid==hi)break;if(event(advance(mid),t+mid))hi=mid;else lo=mid;}
            step=hi;next=advance(step);result.stopped=true;
        }
        for(double value:next) if(std::abs(value)>1e6) throw std::runtime_error("integrazione divergente: stato oltre 1e6");
        if(result.points.size()>=(options.adaptive?options.maximum_steps:options.steps)+1)
            throw std::runtime_error("integrazione: limite di passi raggiunto prima della durata richiesta");
        y=next;
        // Fixed stepping uses integer multiples to avoid a spurious tiny last step.
        t=result.stopped?t+step:final?options.duration:options.adaptive?t+step:result.points.size()*(options.duration/options.steps);
        result.points.push_back(y); result.times.push_back(t);
        if(result.stopped)return result;
    }
    return result;
}
}
