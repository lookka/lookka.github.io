#include "pyxis.hpp"
#include "expression.hpp"
#include "syntax.hpp"
#include "layout.hpp"
#include "constraints.hpp"
#include "asymptote_geometry.hpp"
#include "asymptote_labels.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <locale>
#include <sstream>
#include <stdexcept>
#include <functional>

namespace pyxis {
namespace {
double number(std::istringstream& in) {
    double value;
    if (!(in >> value) || !std::isfinite(value))
        throw std::runtime_error("numero finito atteso");
    return value;
}
std::string name(std::istringstream& in) {
    std::string value;
    in >> value;
    if (value.empty() || !(std::isalpha(static_cast<unsigned char>(value[0])) || value[0] == '_') ||
        !std::all_of(value.begin(), value.end(), [](unsigned char c) { return std::isalnum(c) || c == '_' || c == '.'; }) ||
        value.back() == '.' || value.find("..") != std::string::npos)
        throw std::runtime_error("nome atteso: lettere, cifre e underscore; prima lettera non numerica");
    return value;
}
std::string quoted(std::istringstream& in) {
    in >> std::ws;
    if (in.get() != '"') throw std::runtime_error("etichetta tra virgolette attesa");
    std::string result;
    char c;
    while (in.get(c)) {
        if (c == '"') return result;
        // LaTeX backslashes are preserved literally. Escaped quotes are not yet supported.
        result += c;
    }
    throw std::runtime_error("virgolette dell'etichetta non chiuse");
}
std::string escape(const std::string& text) {
    std::string out;
    for (char c : text) {
        if (c == '\\' || c == '\'') out += '\\';
        out += c;
    }
    return out;
}
void positive(double value) {
    if (value <= 0) throw std::runtime_error("dimensione strettamente positiva attesa");
}
std::string ink(const Scene& scene) {
    return scene.theme=="blackboard"?"white":scene.theme=="modern-vector"?"rgb(0.18,0.23,0.29)":"black";
}
std::string paper(const Scene& scene) {
    return scene.theme=="blackboard"?"rgb(0.07,0.12,0.12)":"white";
}
void point(std::istringstream& in, double& x, double& y, std::string& anchor) {
    std::string token;
    if (!(in >> token)) throw std::runtime_error("punto atteso");
    if (token[0] == '@' || (token.find('.') != std::string::npos && (std::isalpha(static_cast<unsigned char>(token[0])) || token[0] == '_'))) {
        anchor = token;
        return;
    }
    std::istringstream coordinate(token); coordinate.imbue(std::locale::classic());
    x = number(coordinate);
    if (coordinate.peek() != std::char_traits<char>::eof()) throw std::runtime_error("coordinata non valida");
    y = number(in);
}
std::vector<double> remaining_numbers(std::istringstream& in) {
    std::vector<double> result;
    for (;;) {
        in >> std::ws;
        if (in.peek() == '#' || in.peek() == std::char_traits<char>::eof()) return result;
        result.push_back(number(in));
        if (result.size() > 4) throw std::runtime_error("troppi parametri geometrici");
    }
}
Object& object_named(Scene& scene, const std::string& id) {
    auto it = std::find_if(scene.objects.begin(), scene.objects.end(), [&](const Object& o) { return o.name == id; });
    if (it == scene.objects.end()) throw std::runtime_error("oggetto sconosciuto: " + id);
    return *it;
}
bool is_path(const Object& object) {
    return object.kind == Kind::Line || object.kind == Kind::Arrow || object.kind == Kind::Path || object.kind == Kind::Plot;
}
std::string plain_text(const std::string& input) {
    std::string result;
    for (char c : input) {
        if (c == '\\') result += "\\textbackslash{}";
        else if (c == '^') result += "\\textasciicircum{}";
        else if (c == '~') result += "\\textasciitilde{}";
        else {
            if (c == '#' || c == '$' || c == '%' || c == '&' || c == '_' || c == '{' || c == '}') result += '\\';
            result += c;
        }
    }
    return result;
}
void resolve_anchors(Scene& scene) {
    std::vector<int> state(scene.objects.size());
    std::function<void(size_t)> resolve;
    auto anchor_point = [&](const std::string& reference) -> std::pair<double, double> {
        if (reference[0] == '@') {
            if (reference.size() != 3 || reference[1] < 'A' || reference[1] > 'G' || reference[2] < '1' || reference[2] > '7')
                throw std::runtime_error("punto della griglia atteso: @A1 ... @G7");
            return {(reference[1] - 'D') * scene.grid_step, ('4' - reference[2]) * scene.grid_step};
        }
        auto dot = reference.rfind('.');
        auto id = reference.substr(0, dot), anchor = reference.substr(dot + 1);
        auto it = std::find_if(scene.objects.begin(), scene.objects.end(), [&](const Object& o) { return o.name == id; });
        if (it == scene.objects.end()) throw std::runtime_error("oggetto dell'ancoraggio sconosciuto: " + id);
        resolve(static_cast<size_t>(it - scene.objects.begin()));
        if(it->automatic_label)throw std::runtime_error("un'etichetta automatica non definisce ancoraggi geometrici: "+reference+"; usa il nodo a cui e' associata");
        double x = it->x, y = it->y;
        if (it->kind == Kind::Path || it->kind == Kind::Plot) {
            if (anchor == "start") return it->points.front();
            if (anchor == "end") return it->points.back();
            if (anchor.size() > 4 && anchor.substr(0, 4) == "node") {
                std::istringstream index_input(anchor.substr(4));
                double index = number(index_input);
                if (index_input.peek() == std::char_traits<char>::eof() && index >= 1 && index <= it->points.size() && std::floor(index) == index)
                    return it->points[static_cast<size_t>(index) - 1];
            }
            throw std::runtime_error("ancoraggio del percorso atteso: start, end o node1, node2, ...");
        }
        if (it->kind == Kind::Line || it->kind == Kind::Arrow) {
            if (anchor == "start") return {x, y};
            if (anchor == "end") return {it->a, it->b};
            if (anchor == "center") return {x * 0.5 + it->a * 0.5, y * 0.5 + it->b * 0.5};
        } else if (it->kind == Kind::Circle || it->kind == Kind::Ellipse) {
            double ry = it->kind == Kind::Circle ? it->a : it->b;
            if (anchor == "north") return {x, y + ry};
            if (anchor == "south") return {x, y - ry};
            if (anchor == "east") return {x + it->a, y};
            if (anchor == "west") return {x - it->a, y};
            if (anchor == "center") return {x, y};
        } else if (it->kind == Kind::GateBox) {
            if (anchor == "center") return {x,y};
            if (anchor == "north") return {x,y+it->b/2};
            if (anchor == "south") return {x,y-it->b/2};
            if (anchor == "east") return {x+it->a/2,y};
            if (anchor == "west") return {x-it->a/2,y};
        } else if ((it->kind == Kind::Label || it->kind == Kind::Text || it->kind==Kind::Point) && anchor == "center") return {x, y};
        throw std::runtime_error("ancoraggio non disponibile: " + reference);
    };
    resolve = [&](size_t index) {
        if (state[index] == 2) return;
        if (state[index] == 1) throw std::runtime_error("dipendenza ciclica negli ancoraggi o vincoli: "+scene.objects[index].name);
        state[index] = 1;
        auto& object = scene.objects[index];
        if (!object.start_anchor.empty()) { auto p = anchor_point(object.start_anchor); object.x += p.first; object.y += p.second; }
        if (!object.end_anchor.empty()) { auto p = anchor_point(object.end_anchor); object.a += p.first; object.b += p.second; }
        resolve_constraint(scene,object,resolve);
        for (size_t i = 0; i < object.point_anchors.size(); ++i) {
            if (!object.point_anchors[i].empty()) {
                auto p = anchor_point(object.point_anchors[i]);
                object.points[i].first += p.first; object.points[i].second += p.second;
            }
        }
        for (const auto& p : object.points)
            if (!std::isfinite(p.first) || !std::isfinite(p.second)) throw std::runtime_error("overflow nel percorso");
        if (!std::isfinite(object.x) || !std::isfinite(object.y) || !std::isfinite(object.a) || !std::isfinite(object.b))
            throw std::runtime_error("overflow durante la risoluzione degli ancoraggi");
        state[index] = 2;
    };
    for (size_t i = 0; i < scene.objects.size(); ++i) resolve(i);
}
}

Scene parse(std::istream& source) {
    Scene scene;
    std::unordered_map<std::string, double> variables;
    std::unordered_map<std::string, std::string> functions;
    size_t line_number = 0;
    for (const auto& source_line : normalize(source)) {
        line_number = source_line.number;
        std::istringstream in(source_line.text);
        in.imbue(std::locale::classic());
        std::string command;
        in >> command;
        if (command.empty() || command[0] == '#') continue;
        try {
            if (command == "_use") {
                auto package = name(in);
                scene.packages.push_back(package);
            } else if (command == "_group") {
                Group g; g.name=name(in);g.left=number(in);g.bottom=number(in);g.right=number(in);g.top=number(in);
                if(g.left>=g.right||g.bottom>=g.top)throw std::runtime_error("limiti del gruppo non validi");
                for(;;){in>>std::ws;if(in.peek()==std::char_traits<char>::eof())break;g.members.push_back(name(in));}
                scene.groups.push_back(std::move(g));
            } else if (command == "place") {
                Placement p; p.line=line_number;p.object=name(in);in>>p.relation;p.reference=name(in);
                if(p.relation!="above"&&p.relation!="below"&&p.relation!="right-of"&&p.relation!="left-of")throw std::runtime_error("place: above, below, right-of, left-of");
                in>>std::ws;if(in.peek()!=std::char_traits<char>::eof()&&in.peek()!='#'){
                    std::string token;in>>token;if(token.rfind("gap=",0)!=0)throw std::runtime_error("place: opzione gap=numero attesa");
                    std::istringstream gap(token.substr(4));gap.imbue(std::locale::classic());p.gap=number(gap);
                    if(gap.peek()!=std::char_traits<char>::eof()||p.gap<0||p.gap>1000)throw std::runtime_error("gap tra 0 e 1000");
                }
                scene.placements.push_back(p);
            } else if(command=="placement") {
                auto& o=object_named(scene,name(in));
                if(o.kind!=Kind::Label&&o.kind!=Kind::Text)throw std::runtime_error("placement richiede label o text 2D");
                std::string mode;in>>mode;if(mode!="auto"&&mode!="fixed")throw std::runtime_error("placement: auto, fixed");
                o.automatic_label=mode=="auto";
                if(o.automatic_label&&o.text.empty())throw std::runtime_error("un'etichetta automatica deve avere testo");
                in>>std::ws;if(in.peek()!='#'&&!in.eof())in>>o.label_preference;
                const std::vector<std::string> directions{"n","ne","e","se","s","sw","w","nw"};
                if(std::find(directions.begin(),directions.end(),o.label_preference)==directions.end())throw std::runtime_error("prefer: n, ne, e, se, s, sw, w, nw");
                in>>std::ws;if(in.peek()!='#'&&!in.eof())o.label_gap_bp=number(in);
                if(o.label_gap_bp<0||o.label_gap_bp>100)throw std::runtime_error("gap delle etichette tra 0 e 100 bp");
            } else if(command=="flow"||command=="nodefill"||command=="background"||command=="clip") {
                auto& o=object_named(scene,name(in));
                if(command=="flow"){
                    if(!is_path(o))throw std::runtime_error("flow richiede un percorso");
                    in>>o.flow;if(o.flow!="none"&&o.flow!="forward"&&o.flow!="reverse")throw std::runtime_error("flow: none, forward, reverse");
                }else if(command=="nodefill"){
                    if(o.kind!=Kind::Circle)throw std::runtime_error("nodefill richiede un cerchio");
                    in>>o.node_fill;if(o.node_fill!="black"&&o.node_fill!="white"&&o.node_fill!="none")throw std::runtime_error("nodefill: black, white, none");
                }else if(command=="clip"){
                    std::string mode;in>>mode;if(mode!="nodes"&&mode!="off")throw std::runtime_error("clip: nodes, off");
                    if(o.kind!=Kind::Line&&o.kind!=Kind::Arrow&&o.kind!=Kind::Path)throw std::runtime_error("clip richiede line, arrow o path");
                    o.clip_nodes=mode=="nodes";
                }else o.background=true;
            } else if (command == "theme") {
                in >> scene.theme;
                if(scene.theme=="overleaf-classic")scene.theme="paper";
                if (scene.theme != "paper" && scene.theme != "wire" && scene.theme != "color" && scene.theme != "blackboard" && scene.theme != "modern-vector") throw std::runtime_error("tema atteso: paper, wire, color, blackboard, modern-vector, overleaf-classic");
            } else if (command == "linewidth" || command == "shading") {
                auto& object = object_named(scene, name(in));
                double value = number(in);
                if (command == "linewidth") {
                    if (object.kind == Kind::Label || object.kind == Kind::Text || object.kind == Kind::Label3 || object.kind == Kind::Text3) throw std::runtime_error("linewidth richiede una figura o percorso");
                    if (value <= 0 || value > 20) throw std::runtime_error("linewidth richiede un valore tra 0 e 20 bp, escluso 0");
                    object.stroke_width = value;
                } else {
                    if (object.kind != Kind::Sphere || value < 0 || value > 0.8) throw std::runtime_error("shading: sfera e valore tra 0 e 0.8 richiesti");
                    object.shading = value;
                }
            } else if(command=="outline") {
                auto& object=object_named(scene,name(in));if(!object.region)throw std::runtime_error("outline richiede region");
                std::string value;in>>value;if(value!="on"&&value!="off")throw std::runtime_error("outline: on, off");object.outline=value=="on";
            } else if(command=="opacity") {
                auto& object=object_named(scene,name(in));
                if(!object.region)throw std::runtime_error("opacity richiede una region");
                object.opacity=number(in);if(object.opacity<0||object.opacity>1)throw std::runtime_error("opacity tra 0 e 1");
            } else if (command == "fill" || command == "detail") {
                auto& object = object_named(scene, name(in));
                if (object.kind != Kind::Sphere && object.kind != Kind::Surface && object.kind != Kind::Mesh3 && !object.region) throw std::runtime_error("fill richiede sfera, superficie o region");
                std::string value; in >> value;
                if (command == "fill") {
                    if (value != "auto" && value != "none" && value != "white" && value != "color") throw std::runtime_error("fill: auto, none, white, color");
                    object.fill = value;
                } else {
                    if (object.kind != Kind::Sphere || (value != "minimal" && value != "outline" && value != "mesh")) throw std::runtime_error("detail: minimal, outline, mesh, soltanto per le sfere");
                    object.detail = value;
                }
            } else if (command == "camera") {
                scene.camera_x = number(in); scene.camera_y = number(in); scene.camera_z = number(in);
                if (scene.camera_x == 0 && scene.camera_y == 0 && scene.camera_z == 0) throw std::runtime_error("camera: direzione non nulla richiesta");
            } else if (command == "move3" || command == "color") {
                auto& object = object_named(scene, name(in));
                if (command=="move3"&&object.kind != Kind::Sphere && object.kind != Kind::Surface && object.kind != Kind::Label3 && object.kind != Kind::Text3 && object.kind != Kind::Path3 && object.kind != Kind::Arrow3 && object.kind != Kind::Mesh3)
                    throw std::runtime_error("comando 3D su oggetto 2D");
                double a = number(in), b = number(in), c = number(in);
                if (command == "color") {
                    if (object.kind == Kind::Label3 || object.kind == Kind::Text3 || object.kind==Kind::Label || object.kind==Kind::Text || object.kind==Kind::Point) throw std::runtime_error("color richiede una figura o un percorso");
                    if (a < 0 || a > 1 || b < 0 || b > 1 || c < 0 || c > 1) throw std::runtime_error("color richiede tre componenti tra 0 e 1");
                    object.red = a; object.green = b; object.blue = c;
                    object.explicit_color=true;
                } else {
                    object.x += a; object.y += b; object.z += c;
                    for(auto& v:object.vertices3){v[0]+=a;v[1]+=b;v[2]+=c;if(!std::isfinite(v[0])||!std::isfinite(v[1])||!std::isfinite(v[2]))throw std::runtime_error("overflow nella traslazione 3D");}
                    if (object.kind == Kind::Surface) { object.a += a; object.b += b; }
                    if (!std::isfinite(object.x) || !std::isfinite(object.y) || !std::isfinite(object.z) || !std::isfinite(object.a) || !std::isfinite(object.b)) throw std::runtime_error("overflow nella traslazione 3D");
                }
            } else if (command == "grid") {
                in >> std::ws;
                if (in.peek() == 'o') {
                    std::string option; in >> option;
                    if (option != "off" && option != "on") throw std::runtime_error("grid richiede on, off o un passo numerico");
                    scene.grid_visible = option == "on";
                } else {
                    scene.grid_step = number(in);
                    if (scene.grid_step < 1e-6 || scene.grid_step > 1e6) throw std::runtime_error("passo della griglia tra 0.000001 e 1000000");
                    scene.grid_visible = true;
                }
            } else if (command == "symbol") {
                auto id = name(in);
                if (id == "none" || id == "circle" || id == "square" || id == "triangle" || id == "diamond" || scene.symbols.count(id))
                    throw std::runtime_error("nome del simbolo gia' utilizzato o riservato");
                auto specification = quoted(in);
                std::istringstream parts(specification);
                std::vector<std::pair<double, double>> vertices;
                std::string part;
                while (std::getline(parts, part, ';')) {
                    std::istringstream coordinates(part); coordinates.imbue(std::locale::classic());
                    double x = number(coordinates), y = number(coordinates);
                    coordinates >> std::ws;
                    if (coordinates.peek() != std::char_traits<char>::eof()) throw std::runtime_error("simbolo: ogni vertice richiede x y");
                    vertices.emplace_back(x, y);
                    if (vertices.size() > 1000) throw std::runtime_error("troppi vertici nel simbolo");
                }
                if (vertices.size() < 3) throw std::runtime_error("simbolo poligonale: almeno tre vertici");
                scene.symbols.emplace(id, std::move(vertices));
            } else if (command == "stroke" || command == "markers" || command == "bend" || command == "curve" || command == "wave") {
                auto& object = object_named(scene, name(in));
                if (command == "stroke") {
                    if (object.kind == Kind::Label || object.kind == Kind::Text || object.kind == Kind::Sphere || object.kind == Kind::Surface || object.kind == Kind::Label3 || object.kind == Kind::Text3) throw std::runtime_error("stroke richiede una figura o un percorso 2D");
                    in >> object.stroke;
                    if (object.stroke != "solid" && object.stroke != "dashed" && object.stroke != "dotted")
                        throw std::runtime_error("tratto atteso: solid, dashed, dotted");
                } else {
                    if (!is_path(object)) throw std::runtime_error("il comando richiede una linea o un percorso");
                    if (command == "markers") {
                        in >> object.marker;
                        if (object.marker != "none" && object.marker != "circle" && object.marker != "square" && object.marker != "triangle" && object.marker != "diamond" && !scene.symbols.count(object.marker))
                            throw std::runtime_error("simbolo sconosciuto: " + object.marker);
                        in >> std::ws;
                        if (in.peek() != '#' && in.peek() != std::char_traits<char>::eof()) {
                            std::string fill; in >> fill;
                            if (fill != "filled" && fill != "hollow") throw std::runtime_error("riempimento atteso: filled o hollow");
                            object.marker_filled = fill == "filled";
                            in >> std::ws;
                            if (in.peek() != '#' && in.peek() != std::char_traits<char>::eof()) { object.marker_size = number(in); positive(object.marker_size); }
                        }
                    } else if (command == "wave") {
                        object.wave_amplitude = number(in);
                        double turns = number(in);
                        if (turns < 1 || turns > 64 || std::floor(turns) != turns) throw std::runtime_error("wave richiede da 1 a 64 oscillazioni intere");
                        object.wave_turns = static_cast<unsigned>(turns);
                        object.bend = 0; object.controls.clear();
                    } else if (command == "bend") {
                        object.bend = number(in);
                        object.wave_turns = 0;
                        object.controls.clear();
                    } else {
                        object.wave_turns = 0;
                        double segment = number(in);
                        size_t count = (object.kind == Kind::Line || object.kind == Kind::Arrow) ? 1 : object.points.size() - 1;
                        if (segment < 1 || segment > count || std::floor(segment) != segment) throw std::runtime_error("indice del segmento non valido (parte da 1)");
                        Controls controls; controls.segment = static_cast<size_t>(segment) - 1;
                        controls.first.first = number(in); controls.first.second = number(in);
                        controls.second.first = number(in); controls.second.second = number(in);
                        auto old = std::find_if(object.controls.begin(), object.controls.end(), [&](const Controls& c) { return c.segment == controls.segment; });
                        if (old == object.controls.end()) object.controls.push_back(controls); else *old = controls;
                    }
                }
            } else if (command == "let" || command == "function") {
                auto id = name(in);
                if (id == "x" || id == "pi" || id == "sin" || id == "cos" || id == "tan" || id == "exp" || id == "log" || id == "sqrt" || id == "abs")
                    throw std::runtime_error("nome matematico riservato: " + id);
                if (variables.count(id) || functions.count(id)) throw std::runtime_error("simbolo matematico gia' definito: " + id);
                auto expr = quoted(in);
                if (command == "let") variables.emplace(id, evaluate(expr, 0, variables, functions));
                else functions.emplace(id, expr);
            } else if (command == "width") {
                scene.width_mm = number(in);
                positive(scene.width_mm);
            } else if (command == "move") {
                auto id = name(in);
                double dx = number(in), dy = number(in);
                auto it = std::find_if(scene.objects.begin(), scene.objects.end(), [&](const Object& o) { return o.name == id; });
                if (it == scene.objects.end()) throw std::runtime_error("oggetto sconosciuto: " + id);
                if (it->kind == Kind::Sphere || it->kind == Kind::Surface || it->kind == Kind::Label3 || it->kind == Kind::Text3 || it->kind == Kind::Path3 || it->kind == Kind::Arrow3 || it->kind == Kind::Mesh3)
                    throw std::runtime_error("usa move3 per un oggetto 3D");
                it->x += dx; it->y += dy;
                if (it->kind == Kind::Line || it->kind == Kind::Arrow) { it->a += dx; it->b += dy; }
                for (auto& p : it->points) {
                    p.first += dx; p.second += dy;
                    if (!std::isfinite(p.first) || !std::isfinite(p.second)) throw std::runtime_error("overflow nella curva");
                }
                for (auto& c : it->controls) {
                    c.first.first += dx; c.first.second += dy; c.second.first += dx; c.second.second += dy;
                    if (!std::isfinite(c.first.first) || !std::isfinite(c.first.second) || !std::isfinite(c.second.first) || !std::isfinite(c.second.second)) throw std::runtime_error("overflow nei controlli della curva");
                }
                if (!std::isfinite(it->x) || !std::isfinite(it->y) || !std::isfinite(it->a) || !std::isfinite(it->b))
                    throw std::runtime_error("overflow nella traslazione");
            } else {
                Kind kind;
                if (command == "circle") kind = Kind::Circle;
                else if (command == "ellipse") kind = Kind::Ellipse;
                else if (command == "line") kind = Kind::Line;
                else if (command == "arrow") kind = Kind::Arrow;
                else if (command == "label") kind = Kind::Label;
                else if (command == "text") kind = Kind::Text;
                else if (command == "plot") kind = Kind::Plot;
                else if (command == "path" || command=="region") kind = Kind::Path;
                else if (command == "sphere") kind = Kind::Sphere;
                else if (command == "surface") kind = Kind::Surface;
                else if (command == "label3") kind = Kind::Label3;
                else if (command == "text3") kind = Kind::Text3;
                else if (command == "gatebox") kind = Kind::GateBox;
                else if (command == "path3") kind = Kind::Path3;
                else if (command == "arrow3") kind = Kind::Arrow3;
                else if (command == "mesh3") kind = Kind::Mesh3;
                else if (command == "point") kind = Kind::Point;
                else if (command == "tangent-circle") kind = Kind::Circle;
                else if(command=="parallel"||command=="perpendicular")kind=Kind::Line;
                else if(command=="parallel-arrow"||command=="perpendicular-arrow")kind=Kind::Arrow;
                else throw std::runtime_error("comando sconosciuto: " + command);
                Object object{};
                object.kind = kind; object.name = name(in);
                if (kind == Kind::Surface) object.stroke_width = 0.25;
                if (kind == Kind::Sphere) object.stroke_width = 0.45;
                if (std::any_of(scene.objects.begin(), scene.objects.end(), [&](const Object& o) { return o.name == object.name; }))
                    throw std::runtime_error("nome gia' utilizzato: " + object.name);
                if(kind==Kind::Point){
                    in>>std::ws;if(in.peek()!='#'&&!in.eof())point(in,object.x,object.y,object.start_anchor);
                    in>>std::ws;if(in.peek()!='#'&&!in.eof())throw std::runtime_error("argomenti in eccesso");
                    scene.objects.push_back(std::move(object));continue;
                }
                if(command=="tangent-circle"||command=="parallel"||command=="perpendicular"||command=="parallel-arrow"||command=="perpendicular-arrow"){
                    if(command=="tangent-circle"){
                        object.constraint=command;object.constraint_reference=name(in);in>>object.constraint_direction;object.a=number(in);positive(object.a);
                    }else{
                        object.constraint=command.rfind("parallel",0)==0?"parallel":"perpendicular";
                        point(in,object.x,object.y,object.start_anchor);object.constraint_reference=name(in);object.constraint_length=number(in);positive(object.constraint_length);
                    }
                    in>>std::ws;if(in.peek()!='#'&&!in.eof())throw std::runtime_error("argomenti in eccesso");
                    scene.objects.push_back(std::move(object));continue;
                }
                if(kind==Kind::Path3||kind==Kind::Arrow3||kind==Kind::Mesh3){
                    if(kind==Kind::Mesh3){
                        double rows=number(in),columns=number(in);
                        if(rows<2||rows>61||columns<2||columns>61||std::floor(rows)!=rows||std::floor(columns)!=columns)throw std::runtime_error("mesh3: righe e colonne intere tra 2 e 61");
                        object.mesh_rows=static_cast<unsigned>(rows);object.mesh_columns=static_cast<unsigned>(columns);
                    }
                    auto specification=quoted(in);std::istringstream parts(specification);std::string part;
                    while(std::getline(parts,part,';')){
                        std::istringstream vertex(part);vertex.imbue(std::locale::classic());
                        double x=number(vertex),y=number(vertex),z=number(vertex);vertex>>std::ws;
                        if(!vertex.eof())throw std::runtime_error("vertice 3D: tre coordinate richieste");
                        object.vertices3.push_back({x,y,z});if(object.vertices3.size()>10000)throw std::runtime_error("troppi vertici 3D");
                    }
                    if(object.vertices3.size()<2||(kind==Kind::Mesh3&&object.vertices3.size()!=object.mesh_rows*object.mesh_columns))throw std::runtime_error("numero di vertici 3D non valido");
                    in>>std::ws;if(in.peek()!='#'&&!in.eof())throw std::runtime_error("argomenti in eccesso");
                    scene.objects.push_back(std::move(object));continue;
                }
                if (kind == Kind::Sphere) {
                    auto values = remaining_numbers(in);
                    if (values.empty()) object.a = 1;
                    else if (values.size() == 1) object.a = values[0];
                    else if (values.size() == 4) { object.x = values[0]; object.y = values[1]; object.z = values[2]; object.a = values[3]; }
                    else throw std::runtime_error("sphere: nome [raggio] oppure nome x y z raggio");
                    positive(object.a);
                    scene.objects.push_back(object); continue;
                }
                if (kind == Kind::Surface) {
                    object.x = number(in); object.a = number(in); object.y = number(in); object.b = number(in);
                    double mesh = number(in);
                    if (object.x >= object.a || object.y >= object.b || mesh < 2 || mesh > 60 || std::floor(mesh) != mesh)
                        throw std::runtime_error("surface: xmin<xmax, ymin<ymax e mesh intera tra 2 e 60");
                    object.mesh = static_cast<unsigned>(mesh); object.text = quoted(in);
                    auto local_variables = variables;
                    for (unsigned i = 0; i <= object.mesh; ++i) {
                        double t = static_cast<double>(i) / object.mesh;
                        double x = (1 - t) * object.x + t * object.a;
                        for (unsigned j = 0; j <= object.mesh; ++j) {
                            double u = static_cast<double>(j) / object.mesh;
                            local_variables["y"] = (1 - u) * object.y + u * object.b;
                            object.heights.push_back(evaluate(object.text, x, local_variables, functions));
                        }
                    }
                    scene.objects.push_back(object);
                    in >> std::ws;
                    if (in.peek() != '#' && in.peek() != std::char_traits<char>::eof()) throw std::runtime_error("argomenti in eccesso");
                    continue;
                }
                if (kind == Kind::Label3 || kind == Kind::Text3) {
                    in >> std::ws;
                    if (in.peek() != '"') { object.x = number(in); object.y = number(in); object.z = number(in); }
                    object.text = quoted(in);
                    scene.objects.push_back(object);
                    in >> std::ws;
                    if (in.peek() != '#' && in.peek() != std::char_traits<char>::eof()) throw std::runtime_error("argomenti in eccesso");
                    continue;
                }
                if (kind == Kind::Circle || kind == Kind::Ellipse) {
                    in >> std::ws;
                    bool anchored = in.peek() == '@' || std::isalpha(static_cast<unsigned char>(in.peek())) || in.peek() == '_';
                    if (anchored) point(in, object.x, object.y, object.start_anchor);
                    auto values = remaining_numbers(in);
                    if (kind == Kind::Circle) {
                        if (values.empty()) object.a = 1;
                        else if (values.size() == 1) object.a = values[0];
                        else if (!anchored && values.size() == 3) { object.x = values[0]; object.y = values[1]; object.a = values[2]; }
                        else throw std::runtime_error("circle: nome [raggio] oppure nome x y raggio");
                        positive(object.a);
                    } else {
                        if (values.empty()) { object.a = 1; object.b = 0.5; }
                        else if (values.size() == 2) { object.a = values[0]; object.b = values[1]; }
                        else if (!anchored && values.size() == 4) { object.x = values[0]; object.y = values[1]; object.a = values[2]; object.b = values[3]; }
                        else throw std::runtime_error("ellipse: nome [semiasse_x semiasse_y] oppure nome x y semiasse_x semiasse_y");
                        positive(object.a); positive(object.b);
                    }
                    scene.objects.push_back(object);
                    continue;
                }
                if (kind == Kind::Path) {
                    object.region=command=="region";object.background=object.region;
                    in >> std::ws;
                    std::string specification;
                    bool list = in.peek() == '"';
                    if (list) specification = quoted(in);
                    auto read_vertex = [&](std::istringstream& vertex) {
                        double x = 0, y = 0; std::string anchor;
                        point(vertex, x, y, anchor);
                        object.points.emplace_back(x, y); object.point_anchors.push_back(anchor);
                        if (object.points.size() > 10000) throw std::runtime_error("troppi punti nel percorso");
                    };
                    if (list) {
                        std::istringstream parts(specification); std::string part;
                        while (std::getline(parts, part, ';')) {
                            std::istringstream vertex(part); vertex.imbue(std::locale::classic()); read_vertex(vertex);
                            vertex >> std::ws;
                            if (vertex.peek() != std::char_traits<char>::eof()) throw std::runtime_error("punto del percorso non valido");
                        }
                    } else {
                        for (;;) { in >> std::ws; if (in.peek() == '#' || in.peek() == std::char_traits<char>::eof()) break; read_vertex(in); }
                    }
                    if (object.points.size() < 2) throw std::runtime_error("path richiede almeno due punti");
                    if(object.region){
                        if(object.points.size()<3||object.points.size()>512)throw std::runtime_error("region richiede da 3 a 512 vertici");
                        if(object.points.front()!=object.points.back()||object.point_anchors.front()!=object.point_anchors.back()){
                            object.points.push_back(object.points.front());object.point_anchors.push_back(object.point_anchors.front());
                        }
                    }
                    scene.objects.push_back(object);
                    in >> std::ws;
                    if (in.peek() != '#' && in.peek() != std::char_traits<char>::eof()) throw std::runtime_error("argomenti in eccesso");
                    continue;
                }
                in >> std::ws;
                if ((kind == Kind::Line || kind == Kind::Arrow) && (in.peek() == '#' || in.peek() == std::char_traits<char>::eof())) {
                    object.x = -0.5; object.a = 0.5; scene.objects.push_back(object); continue;
                }
                if ((kind == Kind::Label || kind == Kind::Text) && in.peek() == '"') {}
                else if (kind == Kind::Label || kind == Kind::Text || kind == Kind::Line || kind == Kind::Arrow)
                    point(in, object.x, object.y, object.start_anchor);
                else { object.x = number(in); object.y = number(in); }
                if (kind == Kind::Plot) {
                    double count = number(in);
                    if (count < 2 || count > 10000 || std::floor(count) != count || object.x >= object.y)
                        throw std::runtime_error("plot richiede xmin < xmax e da 2 a 10000 campioni interi");
                    object.text = quoted(in);
                    for (int i = 0; i < static_cast<int>(count); ++i) {
                        double fraction = i / (count - 1);
                        double coordinate = (1 - fraction) * object.x + fraction * object.y;
                        if (!std::isfinite(coordinate)) throw std::runtime_error("intervallo non rappresentabile");
                        object.points.emplace_back(coordinate, evaluate(object.text, coordinate, variables, functions));
                    }
                } else if (kind == Kind::Label || kind == Kind::Text) object.text = quoted(in);
                else if (kind == Kind::Line || kind == Kind::Arrow) point(in, object.a, object.b, object.end_anchor);
                else {
                    object.a = number(in);
                    if (kind != Kind::Circle) object.b = number(in);
                    if (kind == Kind::Circle || kind == Kind::Ellipse) positive(object.a);
                    if (kind == Kind::Ellipse) positive(object.b);
                    if (kind == Kind::GateBox) { positive(object.a); positive(object.b); }
                }
                scene.objects.push_back(object);
            }
            in >> std::ws;
            if (in.peek() != std::char_traits<char>::eof() && in.peek() != '#')
                throw std::runtime_error("argomenti in eccesso");
        } catch (const std::exception& e) {
            throw std::runtime_error("riga " + std::to_string(line_number) + ": " + e.what());
        }
    }
    if (source.bad()) throw std::runtime_error("errore nella lettura del sorgente");
    layout(scene);
    resolve_anchors(scene);
    resolve_clipping(scene);
    for(const auto& o:scene.objects)if(o.region){
        if(o.bend!=0||o.wave_turns||!o.controls.empty()||o.flow!="none"||o.clip_nodes)throw std::runtime_error("region usa bordi poligonali senza flow o clipping: "+o.name);
        double area=0;const auto origin=o.points.front();
        for(size_t i=1;i+1<o.points.size();++i)area+=(o.points[i].first-origin.first)*(o.points[i+1].second-origin.second)-(o.points[i].second-origin.second)*(o.points[i+1].first-origin.first);
        if(!std::isfinite(area)||std::abs(area)<1e-14)throw std::runtime_error("region con area nulla o non rappresentabile: "+o.name);
        auto cross=[](const auto& a,const auto& b,const auto& c){return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);};
        auto between=[](const auto& a,const auto& b,const auto& c){return c.first>=std::min(a.first,b.first)&&c.first<=std::max(a.first,b.first)&&c.second>=std::min(a.second,b.second)&&c.second<=std::max(a.second,b.second);};
        size_t count=o.points.size()-1;
        for(size_t i=0;i<count;++i){
            const auto& a=o.points[i];const auto& b=o.points[i+1];
            if(a==b)throw std::runtime_error("region con vertici consecutivi coincidenti: "+o.name);
            for(size_t j=i+1;j<count;++j){
                if(j==i+1||(i==0&&j+1==count))continue;
                const auto& c=o.points[j];const auto& d=o.points[j+1];
                double abC=cross(a,b,c),abD=cross(a,b,d),cdA=cross(c,d,a),cdB=cross(c,d,b);
                if((((abC>0&&abD<0)||(abC<0&&abD>0))&&((cdA>0&&cdB<0)||(cdA<0&&cdB>0)))||
                   (abC==0&&between(a,b,c))||(abD==0&&between(a,b,d))||(cdA==0&&between(c,d,a))||(cdB==0&&between(c,d,b)))
                    throw std::runtime_error("region con bordi che si intersecano: "+o.name);
            }
        }
    }
    return scene;
}

namespace {
using Point = std::pair<double, double>;
void emit_point(std::ostream& out, Point p) { out << '(' << p.first << ',' << p.second << ')'; }
void emit_boundary(std::ostream& out,const Scene& scene,const std::string& id){
    if(id.empty()){out<<"nullpath";return;}
    auto target=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object& o){return o.name==id;});
    if(target==scene.objects.end())throw std::runtime_error("nodo di clipping sconosciuto: "+id);
    const auto& o=*target;
    if(o.kind==Kind::Circle)out<<"circle(("<<o.x<<','<<o.y<<"),"<<o.a<<')';
    else if(o.kind==Kind::Ellipse)out<<"shift(("<<o.x<<','<<o.y<<"))*scale("<<o.a<<','<<o.b<<")*unitcircle";
    else if(o.kind==Kind::GateBox)out<<"box(("<<o.x-o.a/2<<','<<o.y-o.b/2<<"),("<<o.x+o.a/2<<','<<o.y+o.b/2<<"))";
    else throw std::runtime_error("nodo di clipping non disponibile: "+id);
}
std::string label_owner(const Scene& scene,const Object& label){
    if(label.start_anchor.empty()||label.start_anchor.front()=='@')return "";
    const auto id=label.start_anchor.substr(0,label.start_anchor.rfind('.'));
    auto owner=std::find_if(scene.objects.begin(),scene.objects.end(),[&](const Object& o){return o.name==id;});
    if(owner!=scene.objects.end()&&(owner->kind==Kind::Circle||owner->kind==Kind::Ellipse||owner->kind==Kind::GateBox))return id;
    return "";
}
void emit_path(std::ostream& out, const Object& object, const std::vector<Point>& points) {
    if(object.region){
        for(size_t i=0;i+1<points.size();++i){if(i)out<<"--";emit_point(out,points[i]);}
        out<<"--cycle";return;
    }
    if(points.size()>128 && !object.wave_turns && object.controls.empty() && object.bend==0){
        out<<"operator --(...new guide[] {";
        for(size_t i=0;i<points.size();++i){if(i)out<<',';emit_point(out,points[i]);}
        out<<"})";return;
    }
    emit_point(out, points.front());
    for (size_t i = 1; i < points.size(); ++i) {
        if (object.wave_turns) {
            auto p = points[i - 1], q = points[i];
            double dx = q.first - p.first, dy = q.second - p.second;
            double length = std::hypot(dx, dy);
            if (length == 0 || !std::isfinite(length)) throw std::runtime_error("wave richiede segmenti di lunghezza finita e non nulla");
            double nx = -dy / length, ny = dx / length;
            unsigned pieces = object.wave_turns * 16;
            double k = 2 * std::acos(-1.0) * object.wave_turns;
            auto sample = [&](double t) -> Point {
                return {p.first + dx * t + nx * object.wave_amplitude * std::sin(k * t), p.second + dy * t + ny * object.wave_amplitude * std::sin(k * t)};
            };
            auto derivative = [&](double t) -> Point {
                return {dx + nx * object.wave_amplitude * k * std::cos(k * t), dy + ny * object.wave_amplitude * k * std::cos(k * t)};
            };
            for (unsigned j = 0; j < pieces; ++j) {
                double t0 = static_cast<double>(j) / pieces, t1 = static_cast<double>(j + 1) / pieces;
                auto a = sample(t0), b = j + 1 == pieces ? q : sample(t1), d0 = derivative(t0), d1 = derivative(t1);
                double dt = (t1 - t0) / 3;
                Point c1{a.first + dt * d0.first, a.second + dt * d0.second};
                Point c2{b.first - dt * d1.first, b.second - dt * d1.second};
                if (!std::isfinite(c1.first) || !std::isfinite(c1.second) || !std::isfinite(c2.first) || !std::isfinite(c2.second) || !std::isfinite(b.first) || !std::isfinite(b.second)) throw std::runtime_error("serpentina non rappresentabile");
                out << "..controls "; emit_point(out, c1); out << " and "; emit_point(out, c2); out << ".."; emit_point(out, b);
            }
            continue;
        }
        auto control = std::find_if(object.controls.begin(), object.controls.end(), [&](const Controls& c) { return c.segment == i - 1; });
        if (control != object.controls.end() || object.bend != 0) {
            Point c1, c2;
            if (control != object.controls.end()) { c1 = control->first; c2 = control->second; }
            else {
                auto p = points[i - 1], q = points[i];
                double dx = q.first - p.first, dy = q.second - p.second;
                double length = std::hypot(dx, dy);
                if (length == 0 || !std::isfinite(length)) throw std::runtime_error("bend richiede segmenti di lunghezza finita e non nulla");
                double nx = -dy / length, ny = dx / length;
                double h = (4.0 / 3.0) * object.bend;
                c1 = {p.first + dx / 3 + nx * h, p.second + dy / 3 + ny * h};
                c2 = {p.first + 2 * dx / 3 + nx * h, p.second + 2 * dy / 3 + ny * h};
            }
            if (!std::isfinite(c1.first) || !std::isfinite(c1.second) || !std::isfinite(c2.first) || !std::isfinite(c2.second))
                throw std::runtime_error("controlli della curva non rappresentabili");
            out << "..controls "; emit_point(out, c1); out << " and "; emit_point(out, c2); out << "..";
        } else out << "--";
        emit_point(out, points[i]);
    }
}
void emit_marker(std::ostream& out, const Scene& scene, const Object& object, Point position) {
    if (object.marker == "none") return;
    out << "filldraw(";
    if (object.marker == "circle") {
        out << "circle("; emit_point(out, position); out << ',' << object.marker_size << ')';
    } else {
        std::vector<Point> shape;
        if (object.marker == "triangle") shape = {{0,1},{-1,-1},{1,-1}};
        else if (object.marker == "square") shape = {{-1,-1},{1,-1},{1,1},{-1,1}};
        else if (object.marker == "diamond") shape = {{0,1},{1,0},{0,-1},{-1,0}};
        else shape = scene.symbols.at(object.marker);
        for (size_t i = 0; i < shape.size(); ++i) {
            Point vertex{position.first + shape[i].first * object.marker_size, position.second + shape[i].second * object.marker_size};
            if (!std::isfinite(vertex.first) || !std::isfinite(vertex.second)) throw std::runtime_error("simbolo non rappresentabile");
            if (i) out << "--";
            emit_point(out, vertex);
        }
        out << "--cycle";
    }
    out << ',' << (object.marker_filled ? ink(scene) : paper(scene)) << ',' << ink(scene) << "+linewidth(0.5bp));\n";
}
// Small stroke glyphs keep grid labels independent of the broken local TeX pipe.
void emit_grid(std::ostream& out, const Scene& scene) {
    out << "// Pyxis preview-only navigation grid\n";
    const double step = scene.grid_step;
    auto stroke = [&](const std::vector<Point>& vertices, Point origin, double scale) {
        out << "draw(";
        for (size_t i = 0; i < vertices.size(); ++i) {
            if (i) out << "--";
            emit_point(out, {origin.first + vertices[i].first * scale, origin.second + vertices[i].second * scale});
        }
        out << ",gray(0.65)+linewidth(0.3bp));\n";
    };
    const std::vector<std::vector<Point>> letters{
        {{0,0},{0.5,1},{1,0},{0.75,0.5},{0.25,0.5}},
        {{0,0},{0,1},{0.7,1},{1,0.75},{0.7,0.5},{0,0.5},{0.7,0.5},{1,0.25},{0.7,0},{0,0}},
        {{1,1},{0,1},{0,0},{1,0}},
        {{0,0},{0,1},{0.7,1},{1,0.7},{1,0.3},{0.7,0},{0,0}},
        {{1,1},{0,1},{0,0},{1,0},{0,0},{0,0.5},{0.8,0.5}},
        {{0,0},{0,1},{1,1},{0,1},{0,0.5},{0.8,0.5}},
        {{1,1},{0,1},{0,0},{1,0},{1,0.5},{0.5,0.5}}
    };
    const int masks[]{0,6,91,79,102,109,125,7};
    const std::vector<std::vector<Point>> segments{
        {{0,1},{1,1}},{{1,1},{1,0.5}},{{1,0.5},{1,0}},{{1,0},{0,0}},
        {{0,0},{0,0.5}},{{0,0.5},{0,1}},{{0,0.5},{1,0.5}}
    };
    for (int i = -3; i <= 3; ++i) {
        out << "draw((" << i * step << ',' << -3 * step << ")--(" << i * step << ',' << 3 * step << "),gray(0.9)+linewidth(0.25bp));\n";
        out << "draw((" << -3 * step << ',' << i * step << ")--(" << 3 * step << ',' << i * step << "),gray(0.9)+linewidth(0.25bp));\n";
        stroke(letters[static_cast<size_t>(i + 3)], {i * step - 0.05 * step, 3.2 * step}, 0.1 * step);
        int row = i + 4;
        for (int bit = 0; bit < 7; ++bit) if (masks[row] & (1 << bit))
            stroke(segments[static_cast<size_t>(bit)], {-3.3 * step, -i * step - 0.05 * step}, 0.1 * step);
    }
}
}

std::string asymptote(const Scene& scene, bool preview) {
    std::ostringstream out;
    out.imbue(std::locale::classic());
    out << std::setprecision(17);
    auto is3d = [](Kind kind) { return kind == Kind::Sphere || kind == Kind::Surface || kind == Kind::Label3 || kind == Kind::Text3 || kind == Kind::Path3 || kind == Kind::Arrow3 || kind == Kind::Mesh3; };
    bool three = std::any_of(scene.objects.begin(), scene.objects.end(), [&](const Object& o) { return is3d(o.kind); });
    if (three) {
        if (std::any_of(scene.objects.begin(), scene.objects.end(), [&](const Object& o) { return !is3d(o.kind); }))
            throw std::runtime_error("la combinazione di oggetti 2D e 3D nella stessa scena non e' ancora supportata");
        double norm = std::max({std::abs(scene.camera_x), std::abs(scene.camera_y), std::abs(scene.camera_z)});
        out << "// Generated by Pyxis: vector 3D projection\nimport graph3;\nsettings.render=0;\nsettings.prc=false;\nsettings.axes3=false;\nsize(" << scene.width_mm << "mm,0);\ndefaultpen(" << ink(scene) << "+linewidth(0.5bp));\n";
        out << "currentprojection=orthographic((" << scene.camera_x / norm << ',' << scene.camera_y / norm << ',' << scene.camera_z / norm << "),up=" << ((scene.camera_x == 0 && scene.camera_y == 0) ? "Y" : "Z") << ",showtarget=false,center=false);\n";
        size_t serial=0;
        for (const auto& object : scene.objects) {
            const auto symbol=std::to_string(serial++);
            out << "// " << object.name << '\n';
            std::string fill = object.fill == "auto" ? (scene.theme == "wire" ? "none" : scene.theme == "color" ? "color" : "white") : object.fill;
            std::ostringstream material;
            material.imbue(std::locale::classic()); material << std::setprecision(17);
            if (fill == "none") material << "nullpen";
            else if (fill == "white") material << "white";
            else material << "rgb(" << object.red << ',' << object.green << ',' << object.blue << ')';
            if (object.kind == Kind::Sphere) {
                out << "triple pyxis_c_" << symbol << "=(" << object.x << ',' << object.y << ',' << object.z << ");\n";
                if (fill != "none") {
                    std::string shaded = material.str(), light = "nolight";
                    if (object.detail == "minimal" && object.shading > 0) {
                        if (fill == "white") {
                            std::ostringstream sphere_material; sphere_material.imbue(std::locale::classic());
                            sphere_material << std::setprecision(17) << "material(gray(" << object.shading << "),gray(" << 0.98 - object.shading << "),black)";
                            shaded = sphere_material.str(); light = "Viewport";
                        } else light = "Headlamp";
                    }
                    out << "draw(shift(pyxis_c_" << symbol << ")*scale3(" << object.a << ")*unitsphere," << shaded << ",meshpen=" << (object.detail == "mesh" ? "black+linewidth(" + std::to_string(object.stroke_width) + "bp)" : "nullpen") << ",light=" << light << ");\n";
                }
                out << "draw(Circle(pyxis_c_" << symbol << ',' << object.a * 1.00001 << ",normal=(" << scene.camera_x / norm << ',' << scene.camera_y / norm << ',' << scene.camera_z / norm << "))," << ink(scene) << "+linewidth(" << object.stroke_width << "bp));\n";
                if (fill == "none" && object.detail == "mesh") {
                    for (unsigned meridian = 0; meridian < 8; ++meridian) {
                        double angle = std::acos(-1.0) * meridian / 8;
                        out << "draw(Circle(pyxis_c_" << symbol << ',' << object.a << ",normal=(" << std::cos(angle) << ',' << std::sin(angle) << ",0)),black+linewidth(0.3bp));\n";
                    }
                }
            } else if (object.kind == Kind::Surface) {
                if (fill == "none") {
                    auto vertex = [&](unsigned i, unsigned j) {
                        double u = static_cast<double>(i) / object.mesh, v = static_cast<double>(j) / object.mesh;
                        double z = object.heights[i * (object.mesh + 1) + j] + object.z;
                        if (!std::isfinite(z)) throw std::runtime_error("superficie traslata non rappresentabile");
                        out << '(' << (1 - u) * object.x + u * object.a << ',' << (1 - v) * object.y + v * object.b << ',' << z << ')';
                    };
                    for (unsigned i = 0; i <= object.mesh; ++i) {
                        out << "draw(";
                        for (unsigned j = 0; j <= object.mesh; ++j) { if (j) out << ".."; vertex(i,j); }
                        out << ",black+linewidth(" << object.stroke_width << "bp));\n";
                        out << "draw(";
                        for (unsigned j = 0; j <= object.mesh; ++j) { if (j) out << ".."; vertex(j,i); }
                        out << ",black+linewidth(" << object.stroke_width << "bp));\n";
                    }
                    continue;
                }
                out << "real[][] pyxis_heights_" << symbol << "={";
                for (unsigned i = 0; i <= object.mesh; ++i) {
                    if (i) out << ',';
                    out << '{';
                    for (unsigned j = 0; j <= object.mesh; ++j) {
                        if (j) out << ',';
                        double height = object.heights[i * (object.mesh + 1) + j] + object.z;
                        if (!std::isfinite(height)) throw std::runtime_error("superficie traslata non rappresentabile");
                        out << height;
                    }
                    out << '}';
                }
                out << "};\ndraw(surface(pyxis_heights_" << symbol << ",(" << object.x << ',' << object.y << "),(" << object.a << ',' << object.b << "))," << material.str() << ",meshpen=black+linewidth(" << object.stroke_width << "bp),light=nolight);\n";
            } else if(object.kind==Kind::Path3||object.kind==Kind::Arrow3){
                out<<"guide3[] pyxis_path_"<<symbol<<"={";
                for(size_t i=0;i<object.vertices3.size();++i){if(i)out<<',';auto v=object.vertices3[i];out<<'('<<v[0]<<','<<v[1]<<','<<v[2]<<')';}
                out<<"};\ndraw(operator --(...pyxis_path_"<<symbol<<')';
                if(object.red==0&&object.green==0&&object.blue==0)out<<','<<ink(scene);
                else out<<",rgb("<<object.red<<','<<object.green<<','<<object.blue<<')';
                out<<"+linewidth("<<object.stroke_width<<"bp)"<<(object.stroke=="solid"?"":"+"+object.stroke)<<(object.kind==Kind::Arrow3?",Arrow3":"")<<");\n";
            } else if(object.kind==Kind::Mesh3){
                out<<"triple[][] pyxis_mesh_"<<symbol<<"={";
                for(unsigned r=0;r<object.mesh_rows;++r){if(r)out<<',';out<<'{';for(unsigned c=0;c<object.mesh_columns;++c){if(c)out<<',';auto v=object.vertices3[r*object.mesh_columns+c];out<<'('<<v[0]<<','<<v[1]<<','<<v[2]<<')';}out<<'}';}
                out<<"};\ndraw(surface(pyxis_mesh_"<<symbol<<"),"<<material.str()<<",meshpen=black+linewidth("<<object.stroke_width<<"bp),light=nolight);\n";
            } else {
                out << "label('" << escape(object.kind == Kind::Text3 ? plain_text(object.text) : object.text) << "',(" << object.x << ',' << object.y << ',' << object.z << "));\n";
            }
        }
        out<<"shipout(bbox(xmargin=2mm,p=invisible"<<(scene.theme=="blackboard"?",filltype=Fill("+paper(scene)+")":"")<<"));\n";
        return out.str();
    }
    out << "// Generated by Pyxis 1.0. Edit the .pyxis source.\nimport graph;\nsize(" << scene.width_mm << "mm,0);\ndefaultpen(" << ink(scene) << "+linewidth(0.5bp));\n";
    const bool automatic=std::any_of(scene.objects.begin(),scene.objects.end(),[](const Object& o){return o.automatic_label;});
    if(automatic){
        out<<automatic_label_library();
        out<<"path[] pyxis_label_strokes,pyxis_label_nodes,pyxis_label_owners;\nreal[] pyxis_label_widths,pyxis_label_gaps;\nstring[] pyxis_label_texts,pyxis_label_names,pyxis_fixed_texts;\npair[] pyxis_label_anchors,pyxis_fixed_anchors;\nint[] pyxis_label_preferences,pyxis_label_arrows;\n";
    }
    if(std::any_of(scene.objects.begin(),scene.objects.end(),[](const Object& o){return !o.clip_start.empty()||!o.clip_end.empty();}))out<<clipping_library();
    if (preview && scene.grid_visible) emit_grid(out, scene);
    auto render_order = scene.objects;
    std::stable_sort(render_order.begin(),render_order.end(),[](const Object& a,const Object& b){return a.background&&!b.background;});
    size_t serial=0;
    for (const auto& o : render_order) {
        const auto symbol=std::to_string(serial++);
        if(o.kind==Kind::Point)continue;
        out << "// " << o.name << '\n';
        std::ostringstream stroke_pen; stroke_pen.imbue(std::locale::classic()); stroke_pen << std::setprecision(17);
        if(o.explicit_color&&!o.region)stroke_pen<<"rgb("<<o.red<<','<<o.green<<','<<o.blue<<')';else stroke_pen<<ink(scene);
        stroke_pen << "+linewidth(" << o.stroke_width << "bp)";
        const std::string pen = stroke_pen.str() + (o.stroke == "solid" ? std::string{} : "+" + o.stroke);
        if (o.kind == Kind::Circle) {
            if(o.node_fill=="none")out << "draw(";
            else out << "filldraw(";
            out << "circle((" << o.x << ',' << o.y << ")," << o.a << "),";
            if(o.node_fill!="none")out << (o.node_fill=="black"?ink(scene):paper(scene)) << ',';
            out << pen << ");\n";
        }
        else if(o.kind==Kind::GateBox)
            out << "filldraw(box((" << o.x-o.a/2 << ',' << o.y-o.b/2 << "),(" << o.x+o.a/2 << ',' << o.y+o.b/2 << "))," << paper(scene) << ',' << pen << ");\n";
        else if (o.kind == Kind::Ellipse)
            out << "draw(shift((" << o.x << ',' << o.y << "))*scale(" << o.a << ',' << o.b << ")*unitcircle," << pen << ");\n";
        else if (o.kind == Kind::Label || o.kind == Kind::Text) {
            const auto text=escape(o.kind==Kind::Text?plain_text(o.text):o.text);
            if(!o.automatic_label){
                out<<"label('"<<text<<"',("<<o.x<<','<<o.y<<"));\n";
                if(automatic&&!o.text.empty())out<<"pyxis_fixed_texts.push('"<<text<<"');pyxis_fixed_anchors.push(("<<o.x<<','<<o.y<<"));\n";
            }else{
                const std::vector<std::string> directions{"n","ne","e","se","s","sw","w","nw"};
                const auto preference=std::find(directions.begin(),directions.end(),o.label_preference)-directions.begin();
                out<<"pyxis_label_names.push('"<<o.name<<"');pyxis_label_texts.push('"<<text<<"');\npyxis_label_anchors.push(("<<o.x<<','<<o.y<<"));pyxis_label_preferences.push("<<preference<<");pyxis_label_gaps.push("<<o.label_gap_bp<<");\npyxis_label_owners.push(";
                emit_boundary(out,scene,label_owner(scene,o));out<<");\n";
            }
        }
        else {
            std::vector<Point> vertices = (o.kind == Kind::Line || o.kind == Kind::Arrow) ? std::vector<Point>{{o.x,o.y},{o.a,o.b}} : o.points;
            bool clipped=!o.clip_start.empty()||!o.clip_end.empty();
            auto textEndpoint=[&](const std::string& id)->const Object*{
                for(const auto& candidate:scene.objects)if(candidate.name==id&&(candidate.kind==Kind::Label||candidate.kind==Kind::Text))return &candidate;
                return nullptr;
            };
            const auto firstText=textEndpoint(o.clip_start),lastText=textEndpoint(o.clip_end);
            if(firstText||lastText){
                out<<"path pyxis_geometry_"<<symbol<<'=';emit_path(out,o,vertices);out<<";\npath pyxis_physical_clipped_"<<symbol<<";transform pyxis_clip_transform_"<<symbol<<";\n";
                auto measure=[&](const Object* label,const std::string& end){if(label)out<<"frame pyxis_clip_glyph_"<<symbol<<'_'<<end<<";label(pyxis_clip_glyph_"<<symbol<<'_'<<end<<",'"<<escape(label->kind==Kind::Text?plain_text(label->text):label->text)<<"',(0,0));\n";};
                measure(firstText,"first");measure(lastText,"last");
                if(automatic){
                    int arrow=o.kind==Kind::Arrow?(o.flow=="reverse"?4:1):o.flow=="forward"?2:o.flow=="reverse"?3:0;
                    out<<"int pyxis_clip_index_"<<symbol<<"=pyxis_label_strokes.length;pyxis_label_strokes.push(pyxis_geometry_"<<symbol<<");pyxis_label_widths.push("<<o.stroke_width<<");pyxis_label_arrows.push("<<arrow<<");\n";
                }
                out<<"currentpicture.addBox(min(pyxis_geometry_"<<symbol<<"),max(pyxis_geometry_"<<symbol<<"),(-8,-8),(8,8));\ncurrentpicture.add(new void(frame f, transform t) {\npyxis_clip_transform_"<<symbol<<"=t;\npyxis_physical_clipped_"<<symbol<<"=pyxis_trim(t*pyxis_geometry_"<<symbol<<',';
                auto boundary=[&](const Object* label,const std::string& id,const std::string& end){
                    if(label)out<<"pyxis_text_box(pyxis_clip_glyph_"<<symbol<<'_'<<end<<",("<<label->x<<','<<label->y<<"),t,"<<1.5+o.stroke_width/2<<")";
                    else{out<<"t*(";emit_boundary(out,scene,id);out<<')';}
                };
                boundary(firstText,o.clip_start,"first");out<<',';boundary(lastText,o.clip_end,"last");out<<",\""<<o.name<<"\");\n";
                if(automatic)out<<"pyxis_label_strokes[pyxis_clip_index_"<<symbol<<"]=inverse(t)*pyxis_physical_clipped_"<<symbol<<";\n";
                out<<"draw(f,"<<(o.flow=="reverse"?"reverse(":"")<<"pyxis_physical_clipped_"<<symbol<<(o.flow=="reverse"?")":"")<<','<<pen<<(o.kind==Kind::Arrow?",Arrow":o.flow!="none"?",MidArrow":"")<<");\n});\n";
                for(size_t i=0;i<vertices.size();++i){if((i==0&&!o.clip_start.empty())||(i+1==vertices.size()&&!o.clip_end.empty()))continue;emit_marker(out,scene,o,vertices[i]);}
                continue;
            }
            if(clipped){
                out<<"path pyxis_clipped_"<<symbol<<"=pyxis_trim(";emit_path(out,o,vertices);out<<',';
                emit_boundary(out,scene,o.clip_start);out<<',';emit_boundary(out,scene,o.clip_end);out<<",\""<<o.name<<"\");\n";
            }
            if(automatic&&!clipped){out<<"path pyxis_geometry_"<<symbol<<'=';emit_path(out,o,vertices);out<<";\n";}
            bool fillRegion=o.region&&o.fill!="none";
            out << (fillRegion?(o.outline?"filldraw(":"fill("):"draw(");
            if(o.flow=="reverse")out << "reverse(";
            if(clipped)out<<"pyxis_clipped_"<<symbol;
            else if(automatic)out<<"pyxis_geometry_"<<symbol;
            else emit_path(out, o, vertices);
            if(o.flow=="reverse")out << ')';
            if(fillRegion){
                if(o.fill=="white")out<<','<<paper(scene);else out<<",rgb("<<o.red<<','<<o.green<<','<<o.blue<<')';
                out<<"+opacity("<<o.opacity<<')';
            }
            if(!fillRegion||o.outline)out << ',' << pen << (o.kind == Kind::Arrow ? ",Arrow" : o.flow!="none"?",MidArrow":"");
            out<<");\n";
            if(automatic&&(!o.region||o.outline)){
                int arrow=o.kind==Kind::Arrow?(o.flow=="reverse"?4:1):o.flow=="forward"?2:o.flow=="reverse"?3:0;
                out<<"pyxis_label_strokes.push("<<(clipped?"pyxis_clipped_":"pyxis_geometry_")<<symbol<<");pyxis_label_widths.push("<<o.stroke_width<<");pyxis_label_arrows.push("<<arrow<<");\n";
            }
            for(size_t i=0;i<vertices.size();++i){
                // Endpoint markers describe the original nodes, not the clipped line.
                // Avoid planting a duplicate marker inside an endpoint node.
                if((i==0&&!o.clip_start.empty())||(i+1==vertices.size()&&!o.clip_end.empty()))continue;
                emit_marker(out,scene,o,vertices[i]);
            }
        }
        if(automatic&&(o.kind==Kind::Circle||o.kind==Kind::Ellipse||o.kind==Kind::GateBox)){
            out<<"path pyxis_node_"<<symbol<<'=';emit_boundary(out,scene,o.name);out<<";\npyxis_label_strokes.push(pyxis_node_"<<symbol<<");pyxis_label_widths.push("<<o.stroke_width<<");pyxis_label_arrows.push(0);pyxis_label_nodes.push(pyxis_node_"<<symbol<<");\n";
        }
    }
    if(automatic)out<<"pyxis_auto_labels(pyxis_label_texts,pyxis_label_anchors,pyxis_label_owners,pyxis_label_preferences,pyxis_label_gaps,pyxis_label_strokes,pyxis_label_widths,pyxis_label_arrows,pyxis_label_nodes,pyxis_fixed_texts,pyxis_fixed_anchors);\n";
    out<<"shipout(bbox(xmargin=2mm,p=invisible"<<(scene.theme=="blackboard"?",filltype=Fill("+paper(scene)+")":"")<<"));\n";
    return out.str();
}
}
