#pragma once
#include "pyxis.hpp"
namespace pyxis { void layout(Scene& scene); }
