#pragma once
#include <istream>
#include <string>
#include <vector>
namespace pyxis {
struct SourceLine { std::string text; size_t number; };
// Expand declarative blocks to the existing core commands, retaining diagnostics.
std::vector<SourceLine> normalize(std::istream& input);
}
