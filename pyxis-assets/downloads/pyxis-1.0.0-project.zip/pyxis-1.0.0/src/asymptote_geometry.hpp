#pragma once
#include <string>
namespace pyxis {
inline std::string clipping_library() {
    return R"ASY(
// Cut the actual Bezier/wave path, preserving tangents and arrow geometry.
path pyxis_text_box(frame glyph, pair anchor, transform t, real margin=1.5) {
  pair padding=(margin,margin);
  return box(t*anchor+min(glyph)-padding,t*anchor+max(glyph)+padding);
}
path pyxis_trim(path curve, path first, path last, string objectName) {
  real lo=0, hi=length(curve);
  if(length(first)>0) {
    real[][] hits=intersections(curve,first);
    if(hits.length==0) abort("clip: no exit from starting node of "+objectName);
    lo=infinity;
    for(real[] hit:hits) lo=min(lo,hit[0]);
  }
  if(length(last)>0) {
    real[][] hits=intersections(curve,last);
    if(hits.length==0) abort("clip: no entry into ending node of "+objectName);
    hi=-infinity;
    for(real[] hit:hits) hi=max(hi,hit[0]);
  }
  if(lo>=hi) abort("clip: endpoint nodes cover the path of "+objectName);
  return subpath(curve,lo,hi);
}
)ASY";
}
}
