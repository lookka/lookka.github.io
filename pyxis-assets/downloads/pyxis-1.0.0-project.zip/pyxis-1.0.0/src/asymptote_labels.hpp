#pragma once
#include <string>
namespace pyxis {
inline std::string automatic_label_library() {
    return R"ASY(
// Labels use TeX glyph bounds in physical bp, after the final picture transform.
pair[] pyxis_auto_centers;
path[] pyxis_auto_boxes;
path[] pyxis_auto_heads;
int[] pyxis_auto_directions;
real[] pyxis_auto_scores;
transform pyxis_auto_transform;

bool pyxis_bbox_overlap(path a, path b, real padding=0) {
  pair lo=min(a),hi=max(a),bl=min(b),bh=max(b);
  return hi.x+padding>=bl.x && bh.x+padding>=lo.x &&
         hi.y+padding>=bl.y && bh.y+padding>=lo.y;
}
real pyxis_box_area(path a, path b) {
  pair lo=min(a),hi=max(a),bl=min(b),bh=max(b);
  return max(0,min(hi.x,bh.x)-max(lo.x,bl.x))*
         max(0,min(hi.y,bh.y)-max(lo.y,bl.y));
}
void pyxis_auto_labels(string[] texts, pair[] anchors, path[] owners,
                       int[] preferences, real[] gaps,
                       path[] strokes, real[] widths, int[] arrows, path[] nodes,
                       string[] fixedTexts, pair[] fixedAnchors) {
  frame[] glyphs,fixedGlyphs;
  pen labelPen=currentpen;
  for(int i=0;i<texts.length;++i) {
    frame glyph; label(glyph,texts[i],(0,0),p=labelPen);
    pair dimensions=max(glyph)-min(glyph);
    if(!(dimensions.x>0 && dimensions.y>0))
      abort("automatic label has no visible glyphs: "+texts[i]);
    glyphs.push(glyph);
    pair lo=anchors[i],hi=anchors[i];
    if(length(owners[i])>0) {
      pair nl=min(owners[i]),nh=max(owners[i]);
      lo=(min(lo.x,nl.x),min(lo.y,nl.y));hi=(max(hi.x,nh.x),max(hi.y,nh.y));
    }
    // Reserve every allowed placement in the fitting bounds. Text never scales.
    pair margin=dimensions+(gaps[i],gaps[i]);
    currentpicture.addBox(lo,hi,-margin,margin);
  }
  for(string text:fixedTexts) {
    frame glyph; label(glyph,text,(0,0),p=labelPen); fixedGlyphs.push(glyph);
  }
  currentpicture.add(new void(frame f, transform t) {
    path[] used,physicalStrokes,physicalNodes;
    pyxis_auto_heads.delete();
    real[] physicalWidths;
    for(int j=0;j<strokes.length;++j) {
      path stroke=t*strokes[j];physicalStrokes.push(stroke);physicalWidths.push(widths[j]);
      if(arrows[j]>0 && arclength(stroke)>realEpsilon) {
        path g=(arrows[j]==3 || arrows[j]==4)?reverse(stroke):stroke;
        pen p=linewidth(widths[j]);
        real size=min(arrowsizelimit*arclength(g),arrowsize(p));
        real position=(arrows[j]==1 || arrows[j]==4)?length(g):arctime(g,0.5*arclength(g)+0.5*size);
        size=min(arrowsizelimit*arclength(subpath(g,position,0)),size);
        path head=DefaultHead.head(g,position,p,size);
        pyxis_auto_heads.push(head);
        physicalStrokes.push(head);physicalWidths.push(widths[j]);physicalNodes.push(head);
      }
    }
    for(path node:nodes) physicalNodes.push(t*node);
    for(int i=0;i<fixedGlyphs.length;++i) {
      pair lo=min(fixedGlyphs[i]),hi=max(fixedGlyphs[i]);
      if(hi.x>lo.x && hi.y>lo.y) {
        pair at=t*fixedAnchors[i]; used.push(box(at+lo,at+hi));
      }
    }
    // Reset per fit; picture.fit() may call this closure more than once.
    pyxis_auto_centers.delete();pyxis_auto_boxes.delete();
    pyxis_auto_directions.delete();pyxis_auto_scores.delete();
    pyxis_auto_transform=t;
    pair[] directions={(0,1),(1,1),(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(-1,1)};
    for(int i=0;i<glyphs.length;++i) {
      pair at=t*anchors[i],lo=at,hi=at;
      if(length(owners[i])>0) {path owner=t*owners[i];lo=min(owner);hi=max(owner);}
      pair half=(max(glyphs[i])-min(glyphs[i]))/2;
      real best=infinity;pair selected=at;path selectedBox=nullpath;int selectedDirection=0;
      for(int rank=0;rank<8;++rank) {
        int index=(preferences[i]+rank)%8;pair d=directions[index];
        real cx=at.x,cy=at.y;
        if(d.x>0)cx=max(at.x,hi.x)+half.x+gaps[i];
        if(d.x<0)cx=min(at.x,lo.x)-half.x-gaps[i];
        if(d.y>0)cy=max(at.y,hi.y)+half.y+gaps[i];
        if(d.y<0)cy=min(at.y,lo.y)-half.y-gaps[i];
        pair candidate=(cx,cy);
        path area=box(candidate-half,candidate+half);
        // Conservative 1 bp safety area around the measured ink box.
        path clearance=box(candidate-half-(1,1),candidate+half+(1,1));
        real score=0.001*rank;
        for(path occupied:used) score+=1e8*pyxis_box_area(clearance,occupied);
        for(path node:physicalNodes) {
          if(!pyxis_bbox_overlap(clearance,node))continue;
          if(inside(node,candidate))score+=1e7;
        }
        for(int j=0;j<physicalStrokes.length;++j) {
          path stroke=physicalStrokes[j];real padding=physicalWidths[j]/2;
          if(!pyxis_bbox_overlap(clearance,stroke,padding))continue;
          path padded=box(min(clearance)-(padding,padding),max(clearance)+(padding,padding));
          int hits=intersections(padded,stroke).length;
          if(inside(padded,point(stroke,0)))hits+=2;
          score+=1e5*hits;
        }
        if(score<best) {best=score;selected=candidate;selectedBox=area;selectedDirection=index;}
      }
      pair glyphCenter=(min(glyphs[i])+max(glyphs[i]))/2;
      add(f,shift(selected-glyphCenter)*glyphs[i]);
      used.push(selectedBox);
      pyxis_auto_centers.push(selected);pyxis_auto_boxes.push(selectedBox);
      pyxis_auto_directions.push(selectedDirection);pyxis_auto_scores.push(best);
    }
  },true);
}
)ASY";
}
}
