#pragma once
#include <istream>
#include <string>
#include <vector>
#include <utility>
#include <unordered_map>
#include <array>

namespace pyxis {
enum class Kind { Circle, Ellipse, Line, Arrow, Label, Text, Plot, Path, Sphere, Surface, Label3, Text3, GateBox, Path3, Arrow3, Mesh3, Point };
struct Controls {
    size_t segment;
    std::pair<double, double> first, second;
};
struct Object {
    Kind kind;
    std::string name;
    double x = 0, y = 0, a = 0, b = 0;
    std::string text;
    std::vector<std::pair<double, double>> points;
    std::string start_anchor, end_anchor;
    std::vector<std::string> point_anchors;
    std::vector<Controls> controls;
    std::string stroke = "solid", marker = "none";
    bool marker_filled = true;
    double marker_size = 0.08, bend = 0;
    double wave_amplitude = 0;
    unsigned wave_turns = 0;
    double z = 0;
    unsigned mesh = 16;
    std::vector<double> heights;
    double red = 0.65, green = 0.75, blue = 0.85;
    std::string fill = "auto", detail = "minimal";
    double stroke_width = 0.5, shading = 0.14;
    std::string flow = "none", node_fill = "none";
    bool background = false;
    bool region = false, explicit_color = false;
    bool outline = true;
    double opacity = 0.25;
    std::vector<std::array<double,3>> vertices3;
    unsigned mesh_rows = 0, mesh_columns = 0;
    std::string constraint, constraint_reference, constraint_direction;
    double constraint_length = 2;
    bool clip_nodes = false;
    std::string clip_start, clip_end;
    bool automatic_label = false;
    std::string label_preference = "n";
    double label_gap_bp = 3;
};
struct Group {
    std::string name;
    double left, bottom, right, top;
    std::vector<std::string> members;
};
struct Placement {
    std::string object, relation, reference;
    double gap = 1;
    size_t line;
};
struct Scene {
    double width_mm = 100;
    std::vector<Object> objects;
    double grid_step = 1;
    bool grid_visible = true;
    std::unordered_map<std::string, std::vector<std::pair<double, double>>> symbols;
    double camera_x = 5, camera_y = -7, camera_z = 5;
    std::string theme = "paper";
    std::vector<Group> groups;
    std::vector<Placement> placements;
    std::vector<std::string> packages;
};
// Parsing is transactional: an invalid source produces no partially usable scene.
Scene parse(std::istream& source);
std::string asymptote(const Scene& scene, bool preview = false);
}
