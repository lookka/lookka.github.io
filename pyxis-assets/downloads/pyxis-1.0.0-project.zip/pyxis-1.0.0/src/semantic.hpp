#pragma once
#include "syntax.hpp"
namespace pyxis {
// Domain blocks lower to the existing geometric language, preserving source lines.
std::vector<SourceLine> semantic(std::istream& input);
}
