#include "expression.hpp"
#include <cctype>
#include <cmath>
#include <sstream>
#include <locale>
#include <stdexcept>

namespace pyxis {
namespace {
class Expression {
    const std::string& text;
    size_t position = 0;
    double x;
    const std::unordered_map<std::string, double>& variables;
    const std::unordered_map<std::string, std::string>& functions;
    unsigned depth;
    void space() { while (position < text.size() && std::isspace(static_cast<unsigned char>(text[position]))) ++position; }
    bool take(char c) { space(); if (position < text.size() && text[position] == c) { ++position; return true; } return false; }
    double sum() {
        double v = product();
        for (;;) { if (take('+')) v += product(); else if (take('-')) v -= product(); else return v; }
    }
    double product() {
        double v = unary();
        for (;;) {
            if (take('*')) v *= unary();
            else if (take('/')) { double d = unary(); if (d == 0) throw std::runtime_error("divisione per zero"); v /= d; }
            else return v;
        }
    }
    double unary() { if (take('+')) return unary(); if (take('-')) return -unary(); return power(); }
    double power() { double v = atom(); if (take('^')) v = std::pow(v, unary()); return v; }
    double atom() {
        space();
        if (take('(')) { double v = sum(); if (!take(')')) throw std::runtime_error("parentesi non chiusa"); return v; }
        if (position >= text.size()) throw std::runtime_error("espressione incompleta");
        if (std::isdigit(static_cast<unsigned char>(text[position])) || text[position] == '.') {
            std::istringstream input(text.substr(position)); input.imbue(std::locale::classic());
            double v;
            if (!(input >> v)) throw std::runtime_error("numero non valido nell'espressione");
            auto used = input.tellg();
            position = used == std::streampos(-1) ? text.size() : position + static_cast<size_t>(used);
            return v;
        }
        auto start = position;
        while (position < text.size() && (std::isalnum(static_cast<unsigned char>(text[position])) || text[position] == '_')) ++position;
        if (start == position) throw std::runtime_error("simbolo inatteso nell'espressione");
        auto id = text.substr(start, position - start);
        if (take('(')) {
            double argument = sum();
            if (!take(')')) throw std::runtime_error("parentesi della funzione non chiusa");
            if (id == "sin") return std::sin(argument);
            if (id == "cos") return std::cos(argument);
            if (id == "tan") return std::tan(argument);
            if (id == "exp") return std::exp(argument);
            if (id == "log") return std::log(argument);
            if (id == "sqrt") return std::sqrt(argument);
            if (id == "abs") return std::abs(argument);
            auto f = functions.find(id);
            if (f != functions.end()) return evaluate(f->second, argument, variables, functions, depth + 1);
            throw std::runtime_error("funzione sconosciuta: " + id);
        }
        if (id == "x") return x;
        if (id == "pi") return std::acos(-1.0);
        auto v = variables.find(id);
        if (v != variables.end()) return v->second;
        throw std::runtime_error("variabile sconosciuta: " + id);
    }
public:
    Expression(const std::string& t, double value, const std::unordered_map<std::string, double>& vars,
               const std::unordered_map<std::string, std::string>& funcs, unsigned d)
        : text(t), x(value), variables(vars), functions(funcs), depth(d) {}
    double value() {
        if (depth > 64 || text.size() > 4096) throw std::runtime_error("espressione troppo profonda o troppo lunga");
        // Bound recursive syntax nesting, including repeated unary operators.
        unsigned nesting = 0, signs = 0;
        for (char c : text) {
            if (c == '(' && ++nesting > 64) throw std::runtime_error("troppe parentesi annidate");
            if (c == ')' && nesting) --nesting;
            if ((c == '+' || c == '-' || c == '^') && ++signs > 128) throw std::runtime_error("espressione troppo complessa");
        }
        double v = sum(); space();
        if (position != text.size()) throw std::runtime_error("testo inatteso dopo l'espressione");
        if (!std::isfinite(v)) throw std::runtime_error("risultato non finito o fuori dal dominio reale");
        return v;
    }
};
}
double evaluate(const std::string& expression, double x, const std::unordered_map<std::string, double>& variables,
                const std::unordered_map<std::string, std::string>& functions, unsigned depth) {
    return Expression(expression, x, variables, functions, depth).value();
}
}
