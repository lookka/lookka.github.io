#include "pyxis.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>

int main(int argc, char** argv) {
    if ((argc != 3 && argc != 4) || (argc == 4 && std::string(argv[3]) != "--preview")) {
        std::cerr << "Pyxis 1.0\nUso: pyxis input.pyxis output.asy [--preview]\n";
        return 2;
    }
    try {
        if (std::filesystem::weakly_canonical(argv[1]) == std::filesystem::weakly_canonical(argv[2]))
            throw std::runtime_error("sorgente e destinazione devono essere diversi");
        std::ifstream input(argv[1]);
        if (!input) throw std::runtime_error("impossibile aprire il sorgente");
        auto scene = pyxis::parse(input);
        auto generated = pyxis::asymptote(scene, argc == 4);
        std::ofstream output(argv[2]);
        if (!output) throw std::runtime_error("impossibile creare il file Asymptote");
        output << generated;
        output.close();
        if (!output) throw std::runtime_error("errore nella scrittura del file Asymptote");
        std::cout << "Generato " << argv[2] << " (" << scene.objects.size() << " oggetti)\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Pyxis: " << e.what() << '\n';
        return 1;
    }
}
