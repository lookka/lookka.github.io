#include "layout.hpp"
#include <algorithm>
#include <cmath>
#include <functional>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
namespace pyxis {
void layout(Scene& scene) {
    std::unordered_map<std::string,size_t> names, placements;
    std::unordered_map<std::string,Object*> objects;
    std::unordered_set<std::string> assigned;
    for(auto& o:scene.objects)objects.emplace(o.name,&o);
    for(size_t i=0;i<scene.groups.size();++i){
        const auto& g=scene.groups[i];
        if(objects.count(g.name)||!names.emplace(g.name,i).second)throw std::runtime_error("nome del gruppo gia' utilizzato: "+g.name);
        for(const auto& m:g.members){
            if(!objects.count(m))throw std::runtime_error("membro del gruppo sconosciuto: "+m);
            if(!assigned.insert(m).second)throw std::runtime_error("oggetto assegnato a piu' gruppi: "+m);
        }
    }
    for(size_t i=0;i<scene.placements.size();++i){
        auto& p=scene.placements[i];
        if(!names.count(p.object)||!names.count(p.reference))throw std::runtime_error("riga "+std::to_string(p.line)+": place richiede nomi di gruppi esistenti: "+p.object+", "+p.reference);
        if(!placements.emplace(p.object,i).second)throw std::runtime_error("riga "+std::to_string(p.line)+": disposizione duplicata per "+p.object);
    }
    std::vector<int> state(scene.groups.size());
    std::function<void(size_t)> resolve=[&](size_t i){
        if(state[i]==2)return;
        if(state[i]==1)throw std::runtime_error("dipendenza ciclica nella disposizione del gruppo "+scene.groups[i].name);
        state[i]=1;auto& g=scene.groups[i];auto it=placements.find(g.name);
        if(it!=placements.end()){
            auto& p=scene.placements[it->second];size_t j=names.at(p.reference);resolve(j);auto& target=scene.groups[j];
            double dx=(target.left+target.right-g.left-g.right)/2,dy=(target.bottom+target.top-g.bottom-g.top)/2;
            if(p.relation=="below")dy=target.bottom-p.gap-g.top;
            else if(p.relation=="above")dy=target.top+p.gap-g.bottom;
            else if(p.relation=="right-of")dx=target.right+p.gap-g.left;
            else dx=target.left-p.gap-g.right;
            const std::unordered_set<std::string> members(g.members.begin(),g.members.end());
            auto followsMember=[&](const std::string& anchor){
                if(anchor.empty()||anchor.front()=='@')return false;
                auto owner=anchor.substr(0,anchor.rfind('.'));
                if(!members.count(owner))throw std::runtime_error("ancoraggio esterno al gruppo "+g.name+": "+anchor);
                return true;
            };
            for(const auto& id:g.members){
                auto& o=*objects.at(id);
                if(o.constraint=="tangent-circle"){
                    if(!members.count(o.constraint_reference))throw std::runtime_error("tangenza esterna al gruppo "+g.name);
                }else if(!followsMember(o.start_anchor)){o.x+=dx;o.y+=dy;}
                if((o.kind==Kind::Line||o.kind==Kind::Arrow)&&!followsMember(o.end_anchor)){o.a+=dx;o.b+=dy;}
                for(size_t v=0;v<o.points.size();++v){
                    if(v<o.point_anchors.size()&&followsMember(o.point_anchors[v]))continue;
                    o.points[v].first+=dx;o.points[v].second+=dy;
                }
                for(auto& c:o.controls){c.first.first+=dx;c.first.second+=dy;c.second.first+=dx;c.second.second+=dy;}
                if(!std::isfinite(o.x)||!std::isfinite(o.y)||!std::isfinite(o.a)||!std::isfinite(o.b))throw std::runtime_error("overflow nella disposizione");
            }
            g.left+=dx;g.right+=dx;g.bottom+=dy;g.top+=dy;
        }
        state[i]=2;
    };
    for(size_t i=0;i<scene.groups.size();++i)resolve(i);
}
}
