'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
async function compilerPath(extensionPath){
    const packaged=path.join(extensionPath,'bin',process.platform==='win32'?'pyxis.exe':'pyxis');
    try{await fs.access(packaged);return packaged;}catch{}
    return path.join(extensionPath,'..','build',process.platform==='win32'?'pyxis.exe':'pyxis');
}
module.exports={compilerPath};
