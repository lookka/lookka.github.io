'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { execFile } = require('node:child_process');
const { prepareProject } = require('../tools/pyxis/project');
const { atomicWrite } = require('./cache');

async function compileDocument(sourcePath, options) {
    sourcePath=path.resolve(sourcePath);
    if(!/\.tex$/i.test(sourcePath))throw new Error('Il documento deve avere estensione .tex');
    const engine=options.engine||'pdflatex';
    if(!['pdflatex','lualatex','xelatex'].includes(engine))throw new Error('Motore LaTeX: pdflatex, lualatex oppure xelatex');
    const destination=path.resolve(options.destination||sourcePath.replace(/\.tex$/i,'.pdf'));
    if(!/\.pdf$/i.test(destination))throw new Error('La destinazione deve essere un PDF');
    const temporary=await fs.mkdtemp(path.join(os.tmpdir(),'pyxis-document-'));
    try {
        const prepared=await prepareProject(sourcePath,temporary,options);
        const derived=prepared.derived;
        const root=path.resolve(__dirname,'..');
        const environment={...process.env,TEXINPUTS:temporary.replace(/\\/g,'/')+'//'+path.delimiter+path.join(root,'latex').replace(/\\/g,'/')+'//'+path.delimiter+(process.env.TEXINPUTS||'')+path.delimiter};
        const passes=options.passes||2;
        if(!Number.isInteger(passes)||passes<1||passes>3)throw new Error('Da 1 a 3 passaggi LaTeX');
        for(let pass=0;pass<passes;++pass){
            await new Promise((resolve,reject)=>execFile(engine,['-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-output-directory='+temporary,derived],
                {cwd:path.dirname(sourcePath),env:environment,windowsHide:true,timeout:90000,maxBuffer:4*1024*1024},
                (error,stdout,stderr)=>error?reject(new Error(`Compilazione ${engine} fallita:\n${stdout}\n${stderr}`)):resolve()));
        }
        for(const [file,original] of prepared.snapshots)if(await fs.readFile(file,'utf8')!==original)throw new Error('Documento cambiato durante la compilazione: '+file);
        let result;
        try{result=await fs.readFile(path.join(temporary,path.basename(sourcePath).replace(/\.tex$/i,'')+'.pdf'));}
        catch(error){if(error.code==='ENOENT')throw new Error('Il documento compilato non contiene pagine PDF');throw error;}
        if(result.subarray(0,5).toString()!=='%PDF-')throw new Error('Il motore non ha prodotto un PDF valido');
        await atomicWrite(destination,result);
        return {destination,figures:prepared.figures,passes,files:prepared.files,sources:[...prepared.snapshots.keys()]};
    } finally { await fs.rm(temporary,{recursive:true,force:true}); }
}
module.exports={compileDocument};
