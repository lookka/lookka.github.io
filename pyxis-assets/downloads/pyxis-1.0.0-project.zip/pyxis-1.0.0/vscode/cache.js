'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const pending = new Map();
const digest = data => crypto.createHash('sha256').update(data).digest('hex');
async function atomicWrite(file, data) {
    const temp = file + '.' + crypto.randomUUID() + '.tmp';
    try {
        await fs.writeFile(temp, data);
        try { await fs.rename(temp, file); }
        catch (error) {
            if (!['EPERM', 'EACCES', 'EEXIST'].includes(error.code)) throw error;
            // Windows may forbid rename over an existing file. A brief missing
            // entry is safe: cache readers require the committed content hash.
            await fs.rm(file, { force: true });
            await fs.rename(temp, file);
        }
    } finally { await fs.rm(temp, { force: true }); }
}
function valid(format, data) {
    return format === 'pdf' ? data.subarray(0, 5).toString() === '%PDF-' : /<svg\b/.test(data.toString());
}
async function readEntry(folder, formats) {
    try {
        const manifest = JSON.parse(await fs.readFile(path.join(folder, 'manifest.json'), 'utf8'));
        const result = {};
        for (const format of formats) {
            const data = await fs.readFile(path.join(folder, `figure.${format}`));
            if (!valid(format, data) || digest(data) !== manifest[format]) return null;
            result[format] = data;
        }
        return result;
    } catch { return null; }
}
async function pinEntry(folder) {
    const manifest = JSON.parse(await fs.readFile(path.join(folder, 'manifest.json'), 'utf8'));
    if (manifest._pyxis?.pinned) return;
    manifest._pyxis = { ...(manifest._pyxis || {}), pinned: true };
    await atomicWrite(path.join(folder, 'manifest.json'), JSON.stringify(manifest));
}
async function pruneObsolete(cacheDir, owner) {
    const root = path.resolve(cacheDir);
    let entries;
    try { entries = await fs.readdir(root, { withFileTypes: true }); }
    catch (error) { if (error.code === 'ENOENT') return 0; throw error; }
    let removed = 0;
    for (const entry of entries) {
        if (!entry.isDirectory() || !/^[a-f0-9]{64}$/.test(entry.name)) continue;
        const folder = path.resolve(root, entry.name);
        const relative = path.relative(root, folder);
        if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('Cache fuori directory');
        let manifest, files;
        try {
            manifest = JSON.parse(await fs.readFile(path.join(folder, 'manifest.json'), 'utf8'));
            files = await fs.readdir(folder);
        } catch { continue; }
        const stamp = manifest._pyxis;
        // Only directories explicitly owned by Pyxis and containing its output
        // files are eligible. Never prune assets referenced by retained TeX.
        if (stamp?.schema !== 1 || stamp.pinned || stamp.compilerPath !== owner.compilerPath) continue;
        if (files.some(file => !['manifest.json', 'figure.pdf', 'figure.svg'].includes(file))) continue;
        if (stamp.compilerHash === owner.compilerHash && stamp.rendererHash === owner.rendererHash) continue;
        await fs.rm(folder, { recursive: true, force: true });
        ++removed;
    }
    return removed;
}
async function cachedRender(cacheDir, key, formats, produce, onCache, owner = {}) {
    if (!/^[a-f0-9]{64}$/.test(key)) throw new Error('Chiave cache non valida');
    const folder = path.join(path.resolve(cacheDir), key);
    const hit = await readEntry(folder, formats);
    if (hit) {
        if (owner.pinned) await pinEntry(folder);
        onCache?.({ hit: true, key }); return hit;
    }
    const lock = folder + ':' + [...formats].sort().join(',');
    if (pending.has(lock)) {
        const result = await pending.get(lock);
        if (owner.pinned) await pinEntry(folder);
        onCache?.({ hit: true, shared: true, key });
        return result;
    }
    const task = (async () => {
        const result = await produce();
        const manifest = { _pyxis: { schema: 1, ...owner } };
        try {
            const previous = JSON.parse(await fs.readFile(path.join(folder, 'manifest.json'), 'utf8'));
            if (previous._pyxis?.pinned) manifest._pyxis.pinned = true;
        } catch { /* First publication has no previous manifest. */ }
        for (const format of formats) {
            if (!Buffer.isBuffer(result[format]) || !valid(format, result[format])) throw new Error(`Risultato ${format} non valido per la cache`);
            manifest[format] = digest(result[format]);
        }
        await fs.mkdir(folder, { recursive: true });
        // Each file has a unique staging path. The manifest commits the entry last;
        // readers check content hashes, so partial/concurrent writes cannot become hits.
        for (const format of formats) await atomicWrite(path.join(folder, `figure.${format}`), result[format]);
        await atomicWrite(path.join(folder, 'manifest.json'), JSON.stringify(manifest));
        onCache?.({ hit: false, key });
        return result;
    })();
    pending.set(lock, task);
    try { return await task; } finally { pending.delete(lock); }
}
module.exports = { cachedRender, digest, atomicWrite, pruneObsolete };
