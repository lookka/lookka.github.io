'use strict';
const fields = {
    point: ['at'],
    circle: ['center', 'radius', 'stroke', 'tangent-to', 'direction'], ellipse: ['center', 'radii', 'stroke'],
    line: ['from', 'to', 'path', 'route', 'stroke', 'markers', 'controls', 'through', 'parallel-to', 'perpendicular-to', 'length', 'clip'],
    arrow: ['from', 'to', 'path', 'route', 'stroke', 'markers', 'controls', 'through', 'parallel-to', 'perpendicular-to', 'length', 'clip'],
    path: ['points', 'route', 'stroke', 'markers', 'controls', 'clip'],
    region: ['points', 'color', 'fill', 'opacity', 'outline', 'stroke'],
    sphere: ['center', 'radius', 'color', 'fill', 'detail', 'shading'], surface: ['xrange', 'yrange', 'formula', 'mesh', 'color', 'fill'],
    label: ['at', 'text', 'placement', 'prefer', 'gap'], text: ['at', 'text', 'placement', 'prefer', 'gap'], label3: ['at', 'text'], text3: ['at', 'text']
};
for (const [kind, properties] of Object.entries(fields)) if (!['text','label','text3','label3','point'].includes(kind)) properties.push('stroke-width');
for(const kind of ['circle','ellipse','line','arrow','path'])fields[kind].push('color');
const packageFields = {
    'qft.feynman': ['channel', 'incoming', 'outgoing', 'mediator', 'labels', 'loop', 'loop-position', 'loop-radius', 'label-placement'],
    'quantum.circuit': [],
    'quantum.tensor-network': ['sites', 'labels', 'layout', 'rows', 'columns'], 'quantum.bloch': ['theta', 'phi'],
    'relativity.penrose': ['metric','spin','bands'], 'relativity.embedding': ['metric', 'radius', 'extent', 'mesh', 'branch'],
    'relativity.light-cones': ['metric','chart','radii','rows','height'],
    'relativity.geodesic': ['metric','kind','impact','extent','max-angle','max-step','abs-tol','rel-tol','max-steps','photon-sphere','view','mesh'],
    'statmech.ising': ['rows', 'columns', 'state', 'spins', 'dimension', 'layers'],
    'statmech.phase-diagram': ['model', 'melting', 'labels', 'point-labels', 'opacity'],
    'statmech.phase-flow': ['dx', 'dy', 'start', 'duration', 'steps', 'integrator', 'abs-tol', 'rel-tol', 'max-step', 'max-steps'],
    'statmech.lorenz': ['sigma', 'rho', 'beta', 'start', 'duration', 'steps', 'integrator', 'abs-tol', 'rel-tol', 'max-step', 'max-steps']
};
for (const [qualified, properties] of Object.entries(packageFields)) {
    fields[qualified] = properties;
    fields[qualified.split('.')[1]] = properties;
}
function numeric(value, count) {
    const parts = value.replace(/[(),]/g, ' ').trim().split(/\s+/).map(Number);
    if (parts.length !== count || parts.some(number => !Number.isFinite(number))) throw new Error(`Servono ${count} numeri finiti.`);
    return parts;
}
function quickEdit(source, command) {
    if (typeof command !== 'string' || command.includes('\n') || command.includes('\r')) throw new Error('Un comando rapido per volta.');
    if (/^profile\s+/.test(command.trim())) return { source: command.trim() + '\n' + source, mode: 'updated' };
    if (/^use\s+/.test(command.trim())) return { source: source.replace(/\s*$/, '') + '\n' + command.trim() + '\n', mode: 'appended' };
    const global = /^(grid|camera|width|theme)\s+(.+)$/.exec(command.trim());
    if (global) {
        const newline = source.includes('\r\n') ? '\r\n' : '\n';
        const lines = source.split(/\r?\n/);
        const pattern = new RegExp(`^\\s*${global[1]}(?:\\s+|:\\s*)`);
        let index = -1;
        for (let i = 0; i < lines.length; ++i) if (pattern.test(lines[i])) index = i;
        if (index >= 0) { lines[index] = command.trim(); return { source: lines.join(newline), mode: 'updated' }; }
        return { source: source.replace(/\s*$/, '') + newline + command.trim() + newline, mode: 'appended' };
    }
    const match = /^([\w.-]+)\s+([A-Za-z_][\w.]*)(?:\s+(.*))?$/.exec(command.trim());
    if (!match) throw new Error('Comando atteso: azione nome parametri.');
    const [, action, id, argument = ''] = match;
    const supported = new Set(['move','move3','bend','wave','stroke','linewidth','shading','markers','color','fill','opacity','outline','detail','curve','flow','place','placement','clip','set', ...Object.keys(fields), 'grid','camera','width','theme','plot','let','function','symbol']);
    if (!supported.has(action)) throw new Error(`Comando non disponibile: ${action}`);
    const newline = source.includes('\r\n') ? '\r\n' : '\n';
    const lines = source.split(/\r?\n/);
    let block;
    for (let i = 0; i < lines.length; ++i) {
        const header = /^\s*([\w.-]+)\s+([A-Za-z_][\w.]*)\s*\{\s*(?:#.*)?$/.exec(lines[i]);
        if (!header || header[2] !== id) continue;
        let end = i + 1;
        while (end < lines.length && !/^\s*}\s*(?:#.*)?$/.test(lines[end])) ++end;
        if (end === lines.length) throw new Error(`Il blocco ${id} non e' chiuso.`);
        if (block) throw new Error(`Il nome ${id} compare in piu' blocchi.`);
        block = { start: i, end, kind: header[1] };
    }
    const updating = ['move','move3','bend','wave','stroke','linewidth','shading','markers','color','fill','opacity','outline','detail','clip','set'].includes(action);
    if (!block || !updating) {
        if (action === 'set') throw new Error('set richiede un oggetto definito con un blocco.');
        return { source: source.replace(/\s*$/, '') + newline + command.trim() + newline, mode: 'appended' };
    }
    if (!fields[block.kind]) throw new Error('Tipo di blocco non supportato.');
    const propertyIndex = key => {
        let found = -1;
        for (let i = block.start + 1; i < block.end; ++i) {
            const property = /^\s*([a-z][a-z-]*)\s*:/.exec(lines[i]);
            if (property?.[1] === key) { if (found >= 0) throw new Error(`Proprieta' duplicata: ${key}`); found = i; }
        }
        return found;
    };
    const remove = key => { const index = propertyIndex(key); if (index >= 0) { lines.splice(index, 1); --block.end; } };
    const update = (key, value) => {
        const isCircuit = block.kind === 'circuit' || block.kind === 'quantum.circuit';
        const semanticBlock = Object.hasOwn(packageFields, block.kind) || Object.keys(packageFields).some(type => type.split('.')[1] === block.kind);
        if ((key === 'offset' && semanticBlock) ||
            (key !== 'offset' && !(isCircuit && /^[A-Za-z_]\w*$/.test(key)) && !fields[block.kind].includes(key))) throw new Error(`La proprieta' ${key} non appartiene a ${block.kind}.`);
        const index = propertyIndex(key);
        if (index >= 0) {
            const indent = /^\s*/.exec(lines[index])[0];
            lines[index] = `${indent}${key}: ${value}`;
        } else { lines.splice(block.end, 0, `    ${key}: ${value}`); ++block.end; }
    };
    if (action === 'move' || action === 'move3') {
        const three = ['sphere','surface','label3','text3'].includes(block.kind);
        if (three !== (action === 'move3')) throw new Error(three ? 'Usa move3 per un oggetto 3D.' : 'Usa move per un oggetto 2D.');
        const count = three ? 3 : 2;
        const delta = numeric(argument, count);
        const index = propertyIndex('offset');
        const offset = index >= 0 ? numeric(lines[index].split(':').slice(1).join(':').split('#')[0], count) : Array(count).fill(0);
        const translated = offset.map((value, i) => value + delta[i]);
        if (translated.some(value => !Number.isFinite(value))) throw new Error('Traslazione non rappresentabile.');
        update('offset', `(${translated.join(',')})`);
    } else if (action === 'bend' || action === 'wave') {
        const values = numeric(argument, action === 'bend' ? 1 : 2);
        if (action === 'wave' && (!Number.isInteger(values[1]) || values[1] < 1 || values[1] > 64)) throw new Error('wave richiede da 1 a 64 oscillazioni intere.');
        const key = block.kind === 'line' || block.kind === 'arrow' ? (propertyIndex('route') >= 0 ? 'route' : 'path') : 'route';
        update(key, `${action === 'bend' ? 'arc' : 'wave'}(${values.join(',')})`);
        remove('controls');
    } else if (action === 'set') {
        const property = /^([A-Za-z_][\w-]*)\s+(.+)$/.exec(argument);
        if (!property) throw new Error('Uso: set nome proprieta valore');
        update(property[1], property[2]);
        if(property[1]==='placement'&&property[2]==='fixed'&&['label','text'].includes(block.kind)){
            remove('prefer');remove('gap');
        }
        if(property[1]==='integrator'&&property[2]==='rk4'&&['phase-flow','statmech.phase-flow','lorenz','statmech.lorenz'].includes(block.kind)){
            for(const key of ['abs-tol','rel-tol','max-step','max-steps'])remove(key);
        }
    } else {
        if (!argument) throw new Error(`Valore mancante per ${action}.`);
        if (action === 'stroke' && !['solid','dashed','dotted'].includes(argument)) throw new Error('Tratto atteso: solid, dashed, dotted.');
        update(action === 'linewidth' ? 'stroke-width' : action, argument);
    }
    return { source: lines.join(newline), mode: 'updated' };
}
module.exports = { quickEdit };
