'use strict';
const vscode = require('vscode');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const backend = require('./backend');
const { quickEdit } = require('./source');
const { compileDocument } = require('./native-latex');
const { extract } = require('../tools/pyxis/latex');
const { rootDocument } = require('../tools/pyxis/project');
const { compilerPath } = require('./environment');
let activePanels = 0;
let lastPreview = { status: 'idle' }, lastSave = { status: 'idle' };

const initialSource = '# Oggetti fisici e relazioni: Pyxis calcola le posizioni\nuse quantum\nwidth 100\ngrid off\nquantum.circuit bell {\n    q0: H, control(pair)\n    q1: _, target(pair), M\n}\n';

async function render(source, formats, extensionPath, preview = false) {
    const config = vscode.workspace.getConfiguration('pyxis');
    const compiler = config.get('executable') || await compilerPath(extensionPath);
    const asy = config.get('asymptote') || '';
    const cacheDir = path.join(vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || path.join(extensionPath, '..'), '.pyxis_cache');
    return backend.render(source, formats, { compiler, asymptote: asy, ghostscript: config.get('ghostscript') || '', preview, cacheDir });
}

function html(webview) {
    const nonce = crypto.randomBytes(16).toString('hex');
    return `<!doctype html><html lang="it"><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'nonce-${nonce}'; script-src 'nonce-${nonce}';">
<style nonce="${nonce}">
body{font-family:var(--vscode-font-family);padding:20px;color:var(--vscode-foreground);background:var(--vscode-editor-background)}
h1{font-size:24px;margin:0 0 8px}.hint{opacity:.8}main{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin:20px 0}
textarea{box-sizing:border-box;width:100%;height:55vh;resize:vertical;padding:12px;font-family:var(--vscode-editor-font-family);font-size:15px;background:var(--vscode-input-background);color:var(--vscode-input-foreground);border:1px solid var(--vscode-input-border,gray)}
.preview{background:white;min-height:300px;display:flex;align-items:center;justify-content:center;border-radius:4px}.preview img{max-width:95%;max-height:50vh}
button{padding:9px 14px;margin-right:8px;border:0;background:var(--vscode-button-background);color:var(--vscode-button-foreground);cursor:pointer}
button:disabled{opacity:.5;cursor:wait}pre{white-space:pre-wrap}details{margin-top:16px}code{font-family:var(--vscode-editor-font-family)}
.quick{display:flex;gap:8px;margin:16px 0}.quick input{flex:1;padding:10px;background:var(--vscode-input-background);color:var(--vscode-input-foreground);border:1px solid var(--vscode-input-border,gray)}
@media(max-width:700px){main{grid-template-columns:1fr}}
</style></head><body><h1>Pyxis</h1><div class="hint">Scrivi il disegno. Invio aggiorna l'anteprima; Ctrl+Invio salva.</div>
<main><textarea id="source" aria-label="Comandi Pyxis" spellcheck="false"></textarea><div class="preview"><img id="preview" alt="Anteprima della figura" hidden></div></main>
<button id="render">Aggiorna anteprima</button><button id="save">Salva figura</button><label><input type="checkbox" id="grid" checked> Griglia 2D</label> <label><input type="checkbox" id="auto" checked> Anteprima automatica</label>
<div class="quick"><input id="command" aria-label="Comando rapido" placeholder="Ritocco: move S 1 0 · bend L 0.5 · set S radius 2"><button id="apply">Applica ritocco</button></div><pre id="status" role="status"></pre>
<details><summary>Comandi disponibili</summary><pre>use quantum, qft         importa i pacchetti
set bell q0 X, control(pair)  modifica una riga del circuito
set F mediator gluon     cambia il propagatore
place bell below F       disposizione automatica
theme blackboard         tema lavagna
width 100                 larghezza in mm
circle S 0 0 1            centro x y e raggio
circle S                  cerchio unitario al centro
ellipse E 0 0 1 0.35      centro x y e semiassi
line L -1 0 1 0           estremi del segmento
arrow A -2 2 S.north      freccia verso un ancoraggio
move S 1 0                traslazione dx dy
label T 0 1.3 "$S^2$"      etichetta LaTeX
text caption 0 2 "Sfera"  testo normale
let a "0.8"               variabile matematica
function f "a*sin(x)"     funzione utente
plot P 0 6 100 "f(x)"     curva campionata
path P @A4 @D2 @G4        percorso tra punti della griglia
stroke P dashed          tratto tratteggiato
markers P triangle hollow 0.1  simboli sui vertici
bend P 0.4               incurva i segmenti
wave P 0.3 3             serpentina con 3 oscillazioni
curve P 1 -2 2 0 2       controlli liberi del segmento 1
grid 1                   passo della griglia 7x7, origine @D4
sphere S                 sfera 3D nell'origine
camera 5 -7 5            direzione della camera ortografica
surface F -3 3 -3 3 16 "-1/sqrt(x^2+y^2+0.4)"
# commento</pre></details>
<script nonce="${nonce}">
const api=acquireVsCodeApi();const source=document.getElementById('source');let revision=0;let timer;
const send=type=>api.postMessage({type,source:source.value,revision,grid:document.getElementById('grid').checked});
document.getElementById('grid').onchange=()=>{revision++;send('preview')};
document.getElementById('render').onclick=()=>send('preview');
document.getElementById('save').onclick=()=>send('save');
const apply=()=>api.postMessage({type:'quick',command:document.getElementById('command').value,source:source.value,revision});
document.getElementById('apply').onclick=apply;
document.getElementById('command').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();apply()}});
source.addEventListener('input',()=>{revision++;clearTimeout(timer);timer=setTimeout(()=>send(document.getElementById('auto').checked?'preview':'draft'),600)});
source.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.ctrlKey){e.preventDefault();send('save')}else if(e.key==='Enter'){setTimeout(()=>send('preview'),0)}});
window.addEventListener('message',e=>{const m=e.data;if(m.type==='init'){source.value=m.source;revision++;source.focus();send('preview')}
else if(m.type==='preview'&&m.revision===revision){const img=document.getElementById('preview');img.src=m.uri;img.hidden=false;document.getElementById('status').textContent=m.status}
else if(m.type==='status'){document.getElementById('status').textContent=m.status}
else if(m.type==='busy'){document.getElementById('save').disabled=m.busy}});
window.addEventListener('message',e=>{const m=e.data;if(m.type==='source'&&m.revision===revision){source.focus();source.select();if(!document.execCommand('insertText',false,m.source)){source.value=m.source;revision++}document.getElementById('command').value='';send('preview')}});
api.postMessage({type:'ready'});
</script></body></html>`;
}

async function open(context, existingUri) {
    if (!vscode.workspace.isTrusted) return vscode.window.showErrorMessage('Pyxis richiede una cartella attendibile per eseguire il compilatore.');
    const origin = vscode.window.activeTextEditor;
    const target = origin && origin.document.languageId === 'latex' ? origin : undefined;
    const initialVersion = target?.document.version;
    const position = target?.selection.active;
    let source = existingUri ? await fs.readFile(existingUri.fsPath, 'utf8') : context.workspaceState.get('draft', initialSource);
    let disposed = false, saving = false, pending, rendering = false;
    const panel = vscode.window.createWebviewPanel('pyxis', existingUri ? 'Pyxis: modifica figura' : 'Pyxis: nuova figura', vscode.ViewColumn.Beside, { enableScripts: true, retainContextWhenHidden: true, localResourceRoots: [] });
    ++activePanels;
    panel.webview.html = html(panel.webview);
    const post = message => { if (!disposed) panel.webview.postMessage(message); };
    panel.onDidDispose(() => { disposed = true; --activePanels; });

    // Coalesce requests: older renders never replace a more recent source revision.
    async function preview(message) {
        pending = message;
        if (rendering) return;
        rendering = true;
        try {
            while (pending && !disposed) {
                const request = pending; pending = undefined;
                post({ type: 'status', status: 'Generazione anteprima…' });
                const start = Date.now();
                lastPreview = { status: 'rendering' };
                try {
                    const result = await render(request.source, ['svg'], context.extensionPath, request.grid !== false);
                    if (!pending) lastPreview = { status: 'ok', elapsedMs: Date.now() - start };
                    if (!pending) post({ type: 'preview', revision: request.revision, uri: `data:image/svg+xml;base64,${result.svg.toString('base64')}`, status: `Anteprima aggiornata in ${Date.now() - start} ms` });
                } catch (error) { if (!pending) { lastPreview = { status: 'error', message: error.message }; post({ type: 'status', status: error.message }); } }
            }
        } finally { rendering = false; }
    }

    async function save(text, requestedName) {
        if (saving) return;
        saving = true; post({ type: 'busy', busy: true });
        try {
            let destination = existingUri?.fsPath;
            if (!destination) {
                if (!target || target.document.uri.scheme !== 'file') throw new Error('Apri un file LaTeX salvato su disco prima di creare la figura.');
                if (target.document.version !== initialVersion) throw new Error('Il documento LaTeX e\' cambiato: riapri Pyxis dal punto di inserimento desiderato. La bozza resta conservata.');
                const valid = value => /^[a-zA-Z][a-zA-Z0-9_-]*$/.test(value) && !/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(value);
                const name = requestedName || await vscode.window.showInputBox({ prompt: 'Nome della figura', placeHolder: 'sfera', validateInput: value => valid(value) ? undefined : 'Nome valido: lettera iniziale, lettere, numeri, - oppure _; evita nomi riservati di Windows.' });
                if (!name || disposed) return;
                if (!valid(name)) throw new Error('Nome della figura non valido.');
                const folder = vscode.workspace.getWorkspaceFolder(target.document.uri);
                const root = folder?.uri.fsPath || path.dirname(target.document.uri.fsPath);
                destination = path.join(root, 'figures', `${name}.pyxis`);
            }
            const stem = destination.slice(0, -path.extname(destination).length);
            const files = [destination, `${stem}.svg`, `${stem}.pdf`];
            if (!existingUri) {
                for (const file of files) {
                    try { await fs.access(file); throw new Error('Nome gia\' presente. Scegli un altro nome o usa Pyxis: Modifica figura esistente.'); }
                    catch (error) { if (error.code !== 'ENOENT') throw error; }
                }
            }
            post({ type: 'status', status: 'Esportazione SVG e PDF…' });
            const result = await render(text, ['svg', 'pdf'], context.extensionPath);
            if (disposed) return;
            if (!existingUri && target.document.version !== initialVersion) throw new Error('Il documento LaTeX e\' cambiato durante l\'esportazione. Riapri Pyxis; la bozza e\' conservata.');
            await fs.mkdir(path.dirname(destination), { recursive: true });
            await fs.writeFile(destination, text, 'utf8');
            await fs.writeFile(`${stem}.svg`, result.svg);
            await fs.writeFile(`${stem}.pdf`, result.pdf);
            if (!existingUri) {
                const folder = vscode.workspace.getWorkspaceFolder(target.document.uri);
                const root = folder?.uri.fsPath || path.dirname(target.document.uri.fsPath);
                const relative = path.relative(root, `${stem}.pdf`).split(path.sep).join('/');
                const snippet = `\n\\begin{figure}[ht]\n    \\centering\n    \\includegraphics{${relative}}\n\\end{figure}\n`;
                await vscode.window.showTextDocument(target.document, target.viewColumn);
                const applied = await target.edit(edit => edit.insert(position, snippet));
                if (!applied) throw new Error(`Figura salvata, ma inserimento fallito. PDF: ${stem}.pdf`);
            }
            post({ type: 'status', status: 'Figura salvata. Il documento LaTeX richiede \\usepackage{graphicx}.' });
            existingUri = vscode.Uri.file(destination);
            panel.title = `Pyxis: ${path.basename(destination)}`;
            lastSave = { status: 'ok', destination };
            return { destination };
        } catch (error) { lastSave = { status: 'error', message: error.message }; post({ type: 'status', status: error.message }); }
        finally { saving = false; post({ type: 'busy', busy: false }); }
    }

    panel.webview.onDidReceiveMessage(async message => {
        if (message.type === 'ready') { post({ type: 'init', source }); return; }
        if (typeof message.source !== 'string' || message.source.length > 1024 * 1024) return;
        source = message.source;
        await context.workspaceState.update('draft', source);
        if (message.type === 'quick') {
            try {
                const changed = quickEdit(source, message.command);
                post({ type: 'source', source: changed.source, revision: message.revision });
            } catch (error) { post({ type: 'status', status: error.message }); }
            return;
        }
        if (message.type === 'preview') await preview(message);
        if (message.type === 'save') await save(source);
    });
    return { saveFigure: (name, text) => save(text, name), close: () => panel.dispose() };
}

function activate(context) {
    const resources=path.basename(context.extensionPath)==='vscode'?path.dirname(context.extensionPath):context.extensionPath;
    context.subscriptions.push(vscode.commands.registerCommand('pyxis.guide',()=>vscode.commands.executeCommand('markdown.showPreview',vscode.Uri.file(path.join(resources,'docs','INIZIA-QUI.md')))));
    context.subscriptions.push(vscode.commands.registerCommand('pyxis.example',async()=>{
        const examples=[['QFT: scattering e loop','qft.pyxis'],['Quantistica: oracolo controllato','oracles.pyxis'],['Quantistica: sfera di Bloch','bloch.pyxis'],['Statistica: diagrammi di fase','phase-diagrams.pyxis'],['Statistica: spin 3D','ising3d.pyxis'],['Relativita: Kerr','kerr.pyxis'],['Relativita: geodetiche','geodesics.pyxis']];
        const selected=await vscode.window.showQuickPick(examples.map(([label,file])=>({label,file})),{placeHolder:'Scegli una figura del corso'});
        if(!selected)return;
        const template=await fs.readFile(path.join(resources,'examples',selected.file),'utf8');
        await context.workspaceState.update('draft',template);return open(context);
    }));
    const output=vscode.window.createOutputChannel('Pyxis');context.subscriptions.push(output);
    const jobs=new Map(),parents=new Map();let lastNative={status:'idle'};
    const canonical=file=>process.platform==='win32'?file.toLowerCase():file;
    async function buildNative(document) {
        if(!vscode.workspace.isTrusted||document.uri.scheme!=='file')throw new Error('La compilazione richiede un file locale in una cartella attendibile.');
        const key=parents.get(canonical(document.uri.fsPath))||await rootDocument(document.uri.fsPath);
        const version=document.uri.toString()+':'+document.version;
        const existing=jobs.get(key);
        if(existing){if(existing.version!==version)existing.pending=document;return existing.promise;}
        const job={version,pending:document,promise:undefined};jobs.set(key,job);
        job.promise=(async()=>{
            let result;
            while(job.pending){
                const current=job.pending;job.pending=undefined;job.version=current.uri.toString()+':'+current.version;
                const config=vscode.workspace.getConfiguration('pyxis',current.uri),start=Date.now();
                lastNative={status:'building',source:key};output.appendLine(`Compilazione: ${key}`);
                try {
                    result=await compileDocument(key,{compiler:config.get('executable')||await compilerPath(context.extensionPath),
                        asymptote:config.get('asymptote')||'',ghostscript:config.get('ghostscript')||'',engine:config.get('latexEngine')||'pdflatex'});
                    for(const file of result.sources)parents.set(canonical(file),key);
                    lastNative={status:'ok',destination:result.destination,elapsedMs:Date.now()-start};output.appendLine(`PDF pronto: ${result.destination}`);
                }catch(error){
                    lastNative={status:'error',message:error.message};output.appendLine(error.message);
                    if(!job.pending)throw error;
                }
            }
            return result;
        })();
        try{return await job.promise;}finally{jobs.delete(key);}
    }
    context.subscriptions.push(vscode.commands.registerCommand('pyxis.buildLatex',async()=>{
        const document=vscode.window.activeTextEditor?.document;
        if(!document||!(/\.tex$/i.test(document.uri.fsPath)))return vscode.window.showErrorMessage('Apri il documento LaTeX principale.');
        if(document.isDirty)await document.save();
        return buildNative(document).catch(error=>{output.show(true);vscode.window.showErrorMessage(error.message);});
    }));
    context.subscriptions.push(vscode.workspace.onDidSaveTextDocument(document=>{
        if(document.uri.scheme!=='file'||!(/\.tex$/i.test(document.uri.fsPath))||!vscode.workspace.getConfiguration('pyxis',document.uri).get('buildOnSave',true))return;
        try{if(extract(document.getText()).length||parents.has(canonical(document.uri.fsPath))||/\\usepackage\s*\{pyxis\}/.test(document.getText()))buildNative(document).catch(()=>{});}catch(error){output.appendLine(error.message);}
    }));
    context.subscriptions.push(vscode.commands.registerCommand('pyxis.open', () => open(context).catch(error => vscode.window.showErrorMessage(error.message))));
    context.subscriptions.push(vscode.commands.registerCommand('pyxis.edit', async () => {
        const files = await vscode.window.showOpenDialog({ canSelectMany: false, filters: { Pyxis: ['pyxis'] } });
        if (files?.[0]) await open(context, files[0]).catch(error => vscode.window.showErrorMessage(error.message));
    }));
    return {
        openEditor: () => open(context),
        buildDocument: document => buildNative(document),
        getDiagnostics: () => ({ activePanels, lastPreview: { ...lastPreview }, lastSave: { ...lastSave },lastNative:{...lastNative} })
    };
}
module.exports = { activate };
