'use strict';
const vscode = require('vscode');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
async function run() {
    const project = path.resolve(__dirname, '..', '..');
    const folder = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    assert.ok(folder && path.resolve(folder).startsWith(path.join(project, 'tmp') + path.sep), 'isolated workspace required');
    const lesson = path.join(folder, 'lesson.tex');
    await fs.writeFile(lesson, '\\documentclass{article}\n\\usepackage{graphicx}\n\\begin{document}\nAppunti\n\\end{document}\n');
    const document = await vscode.workspace.openTextDocument(vscode.Uri.file(lesson));
    await vscode.languages.setTextDocumentLanguage(document, 'latex');
    const editor = await vscode.window.showTextDocument(document);
    editor.selection = new vscode.Selection(new vscode.Position(4, 0), new vscode.Position(4, 0));
    const extension = vscode.extensions.getExtension('pyxis-local.pyxis');
    assert.ok(extension, 'extension registered');
    const api = await extension.activate();
    const session = await api.openEditor();
    assert.equal(api.getDiagnostics().activePanels, 1, 'editor panel opened');
    const deadline = Date.now() + 30000;
    while (!['ok','error'].includes(api.getDiagnostics().lastPreview.status) && Date.now() < deadline)
        await new Promise(resolve => setTimeout(resolve, 100));
    assert.equal(api.getDiagnostics().lastPreview.status, 'ok', api.getDiagnostics().lastPreview.message || 'webview preview not ready');
    const source = 'use quantum, qft\ngrid off\nquantum.circuit bell {\n q0: H, control(pair)\n q1: _, target(pair), M\n}\nqft.feynman F {\n mediator: photon\n loop: fermion\n}\nquantum.tensor-network net {\n layout: peps\n rows: 2\n columns: 2\n}\nplace bell below F\nplace net below bell\nmove net.r1c1 0.1 0.1\n';
    const saved = await session.saveFigure('integration-figure', source);
    assert.ok(saved, api.getDiagnostics().lastSave.message || 'save failed');
    for (const extension of ['pyxis','svg','pdf']) {
        const file = path.join(folder, 'figures', `integration-figure.${extension}`);
        assert.ok((await fs.stat(file)).size > 0, `${extension} saved`);
    }
    assert.match(document.getText(), /\\includegraphics\{figures\/integration-figure\.pdf\}/);
    session.close();
    assert.equal(api.getDiagnostics().activePanels, 0, 'panel closed');
    const nativePath=path.join(folder,'native.tex');
    const nativeText='\\documentclass{article}\n\\usepackage{pyxis}\n\\begin{document}\n\\begin{pyxis}\nprofile quantum\ncircuit C {\n q0: H\n}\n\\end{pyxis}\n\\end{document}\n';
    await fs.writeFile(nativePath,nativeText);
    const nativeDocument=await vscode.workspace.openTextDocument(vscode.Uri.file(nativePath));
    await vscode.languages.setTextDocumentLanguage(nativeDocument,'latex');
    const nativeResult=await api.buildDocument(nativeDocument);
    assert.ok((await fs.stat(nativeResult.destination)).size>0,'native document PDF compiled');
    assert.equal(await fs.readFile(nativePath,'utf8'),nativeText,'native source preserved');
    const nativeEditor=await vscode.window.showTextDocument(nativeDocument);
    await nativeEditor.edit(edit=>edit.insert(new vscode.Position(0,0),'% saved again\n'));
    await nativeDocument.save();
    const nativeDeadline=Date.now()+30000;
    while(api.getDiagnostics().lastNative.status==='building'&&Date.now()<nativeDeadline)await new Promise(resolve=>setTimeout(resolve,100));
    assert.equal(api.getDiagnostics().lastNative.status,'ok','native compilation on save');
    const mainPath=path.join(folder,'thesis.tex'),chapterPath=path.join(folder,'chapter.tex');
    await fs.writeFile(mainPath,'\\documentclass{article}\n\\usepackage{pyxis}\n\\begin{document}\n\\input{chapter}\n\\end{document}\n');
    await fs.writeFile(chapterPath,'% !TeX root = thesis.tex\n\\section{Capitolo}\n\\begin{pyxis}\ncircle C\n\\end{pyxis}\n');
    const chapterDocument=await vscode.workspace.openTextDocument(vscode.Uri.file(chapterPath));
    const chapterResult=await api.buildDocument(chapterDocument);
    assert.equal(path.basename(chapterResult.destination),'thesis.pdf','chapter builds main thesis PDF');
    assert.ok((await fs.stat(chapterResult.destination)).size>0,'recursive native document compiled');
    await fs.writeFile(path.join(project, 'tmp', 'editor-test-result.json'), JSON.stringify({ ok: true, preview: api.getDiagnostics().lastPreview, native:api.getDiagnostics().lastNative, checks: ['activation','webview preview','source','SVG','PDF','LaTeX insertion','close','native LaTeX','build on save','chapter root'] }, null, 2));
    console.log('Pyxis Extension Host integration: OK');
}
module.exports = { run };
