'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const {compileDocument}=require('../vscode/native-latex');
const {references,rootDocument}=require('../tools/pyxis/project');
async function main(){
    const temp=await fs.mkdtemp(path.join(os.tmpdir(),'pyxis-native-test-'));
    try{
        const source=path.join(temp,'lesson.tex'),pdf=path.join(temp,'lesson.pdf');
        assert.equal(references('% \\input{ignored}\n\\verb|\\input{ignored}|\n\\begin{verbatim}\n\\include{ignored}\n\\end{verbatim}\n\\input{real}\n').length,1,'input scanning ignores comments and verbatim');
        const original=String.raw`\documentclass{article}
\usepackage{pyxis}
\begin{document}
Appunti
\begin{pyxis}[width=70]
profile quantum
circuit bell {
 q0: H, control(pair)
 q1: _, target(pair)
}
\end{pyxis}
\end{document}
`;
        await fs.writeFile(source,original);
        const options={compiler:path.resolve(__dirname,'../build/pyxis.exe')};
        const result=await compileDocument(source,options);
        assert.equal(result.destination,pdf);assert.equal(result.passes,2);
        assert.equal(await fs.readFile(source,'utf8'),original);
        assert.equal((await fs.readFile(pdf)).subarray(0,5).toString(),'%PDF-');
        assert.equal(result.figures.length,1);
        const previous=await fs.readFile(pdf);
        await fs.writeFile(source,original.replace('profile quantum','profile unknown'));
        await assert.rejects(compileDocument(source,options),/profile/);
        assert.deepEqual(await fs.readFile(pdf),previous,'failed build preserves previous usable PDF');
        assert.ok(!(await fs.readdir(temp)).some(name=>/\.(aux|log)$/.test(name)),'no auxiliary files beside user document');
        const child=path.join(temp,'chapter.tex'),nested=path.join(temp,'section.tex');
        const chapter='\\section{Capitolo}\n\\input{section}\n';
        const section='\\begin{pyxis}[width=60]\nprofile qft\nfeynman F {\n}\nlabel state 0 2 "$\\ket{\\psi}$"\n\\end{pyxis}\n';
        await fs.writeFile(child,chapter);await fs.writeFile(nested,section);
        const thesis=original.replace('\\begin{document}','\\newcommand{\\ket}[1]{\\left|#1\\right\\rangle}\n\\begin{document}').replace(/\\begin\{pyxis\}[\s\S]*?\\end\{pyxis\}/,'\\include{chapter}');
        await fs.writeFile(source,thesis);
        const project=await compileDocument(source,options);assert.equal(project.files,3);assert.equal(project.figures.length,1);
        assert.equal(await fs.readFile(child,'utf8'),chapter);assert.equal(await fs.readFile(nested,'utf8'),section);
        await fs.writeFile(child,'% !TeX root = lesson.tex\n'+chapter);
        assert.equal(await rootDocument(child),source,'chapter root marker resolves main document');
        await fs.writeFile(source,thesis.replace('\\begin{document}','\\includeonly{}\n\\begin{document}'));
        const excluded=await compileDocument(source,options);assert.equal(excluded.files,1);assert.equal(excluded.figures.length,0);
        await fs.writeFile(source,thesis);await fs.writeFile(nested,'\\input{chapter}\n');
        await assert.rejects(compileDocument(source,options),/ciclico/);
        console.log('LaTeX nativo: PDF standard, originale intatto, errore senza perdita e pulizia: OK');
    }finally{await fs.rm(temp,{recursive:true,force:true});}
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
