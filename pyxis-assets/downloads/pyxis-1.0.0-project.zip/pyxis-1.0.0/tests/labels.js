'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { promisify } = require('node:util');
const execFile = promisify(require('node:child_process').execFile);
const { resolveTools, render } = require('../vscode/backend');
async function main() {
    const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'pyxis-label-test-'));
    try {
        const tools = await resolveTools();
        const compiler = path.resolve(__dirname, '../build/pyxis.exe');
        const args = ['-noView', '-nobatchView', '-f', 'pdf'];
        if (tools.ghostscript) args.push('-gs', tools.ghostscript);
        if (tools.moduleDir) args.push('-dir', tools.moduleDir);
        if (tools.library) args.push('-libgs', tools.library);
        args.push('figure.asy');
        const options = { cwd: temp, windowsHide: true, timeout: 30000, maxBuffer: 2 * 1024 * 1024 };
        async function check(source, checks) {
            await fs.writeFile(path.join(temp, 'figure.pyxis'), source);
            await execFile(compiler, ['figure.pyxis', 'figure.asy'], options);
            await fs.appendFile(path.join(temp, 'figure.asy'), '\n' + checks);
            try { return await execFile(tools.asymptote, args, options); }
            catch (error) { throw new Error(error.message + '\n' + (error.stdout || '') + '\n' + (error.stderr || '')); }
        }
        const node = 'circle C 0 0 1\nline L C.north 0 3\nlabel T C.center "$x$"\nplacement T auto n 3\n';
        const nodeChecks = `
assert(pyxis_auto_centers.length==1);
assert(pyxis_auto_directions[0]!=0); // North is occupied by the line.
assert(pyxis_auto_scores[0]<0.01); // Selected candidate has no collision cost.
path stroke=pyxis_auto_transform*( (0,1)--(0,3) );
assert(intersections(pyxis_auto_boxes[0],stroke).length==0);
frame measured;label(measured,"$x$",(0,0));
pair expected=max(measured)-min(measured),actual=max(pyxis_auto_boxes[0])-min(pyxis_auto_boxes[0]);
assert(length(actual-expected)<1e-6);
write("PYXIS_TEST "+string(actual.x)+" "+string(actual.y));
`;
        const small = await check('width 85\n' + node, nodeChecks);
        const large = await check('width 160\n' + node, nodeChecks);
        const metrics = text => text.match(/PYXIS_TEST ([\d.e+-]+) ([\d.e+-]+)/).slice(1).map(Number);
        assert.deepEqual(metrics(small.stdout), metrics(large.stdout), 'label dimensions in bp do not change when diagram width changes');
        await check('line L 0 0 4 0\nlabel short 2 0 "$x$"\nplacement short auto\nlabel long 2 0 "$\\frac{a+b}{c+d}$"\nplacement long auto\n', `
assert(pyxis_auto_boxes.length==2);
assert(pyxis_box_area(pyxis_auto_boxes[0],pyxis_auto_boxes[1])==0);
pair a=max(pyxis_auto_boxes[0])-min(pyxis_auto_boxes[0]),b=max(pyxis_auto_boxes[1])-min(pyxis_auto_boxes[1]);
assert(b.x>a.x && b.y>a.y);
assert(pyxis_auto_scores[0]<0.01 && pyxis_auto_scores[1]<0.01);
`);
        await check('arrow A 0 0 4 0\nline F 0 2 4 2\nflow F forward\nline R 0 4 4 4\nflow R reverse\nlabel T 2 6 "$k$"\nplacement T auto\n', `
assert(pyxis_auto_heads.length==3);
transform t=pyxis_auto_transform;
assert(length(point(pyxis_auto_heads[0],0)-t*(4,0))<1e-5);
assert(point(pyxis_auto_heads[1],0).x>(t*(2,2)).x);
assert(point(pyxis_auto_heads[2],0).x<(t*(2,4)).x);
`);
        await check('line L 0 0 4 0\ntext F 2 0 "WWWWWWWWWW"\nlabel T 2 0 "$x$"\nplacement T auto e 20\n', `
assert(pyxis_auto_directions[0]!=2);
assert(pyxis_auto_scores[0]<0.01);
frame fixed;label(fixed,"WWWWWWWWWW",(0,0));pair at=pyxis_auto_transform*(2,0);
assert(pyxis_box_area(pyxis_auto_boxes[0],box(at+min(fixed),at+max(fixed)))==0);
`);
        const rays = 'line N 0 0 0 3\nline NE 0 0 3 3\nline E 0 0 3 0\nline SE 0 0 3 -3\nline S 0 0 0 -3\nline SW 0 0 -3 -3\nline W 0 0 -3 0\nline NW 0 0 -3 3\n';
        await check(rays + 'label T 0 0 "$x$"\nplacement T auto\n', 'assert(pyxis_auto_centers.length==1);assert(pyxis_auto_scores[0]>1);');
        await assert.rejects(check('label T ""\nplacement T auto\n', ''), /deve avere testo|Command failed/);
        const source = await fs.readFile(path.resolve(__dirname, '../examples/auto-labels.pyxis'), 'utf8');
        const result = await render(source, ['svg', 'pdf'], { compiler });
        assert.match(result.svg.toString(), /<svg\b/);
        assert.doesNotMatch(result.svg.toString(), /<image\b/);
        assert.equal(result.pdf.subarray(0, 5).toString(), '%PDF-');
        console.log('Etichette: misure TeX, ostacoli, collisioni, dimensioni fisiche e punte delle frecce: OK');
    } finally { await fs.rm(temp, { recursive: true, force: true }); }
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
