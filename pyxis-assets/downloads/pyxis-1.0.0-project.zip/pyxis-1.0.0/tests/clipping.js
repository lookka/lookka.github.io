'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { promisify } = require('node:util');
const execFile = promisify(require('node:child_process').execFile);
const { resolveTools } = require('../vscode/backend');
async function main() {
    const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'pyxis-clip-test-'));
    try {
        const tools = await resolveTools();
        const compiler = path.resolve(__dirname, '../build/pyxis.exe');
        const args = ['-noView', '-nobatchView', '-f', 'pdf'];
        if (tools.ghostscript) args.push('-gs', tools.ghostscript);
        if (tools.moduleDir) args.push('-dir', tools.moduleDir);
        if (tools.library) args.push('-libgs', tools.library);
        args.push('figure.asy');
        const options = { cwd: temp, windowsHide: true, timeout: 30000, maxBuffer: 2 * 1024 * 1024 };
        async function compile(source, assertions = '') {
            await fs.writeFile(path.join(temp, 'figure.pyxis'), source);
            await execFile(compiler, ['figure.pyxis', 'figure.asy'], options);
            await fs.appendFile(path.join(temp, 'figure.asy'), assertions);
            try { return await execFile(tools.asymptote, args, options); }
            catch(error) { throw new Error(error.message + '\n' + (error.stdout || '') + '\n' + (error.stderr || '')); }
        }
        const nodes = 'circle A 0 0 1\nellipse B 4 0 1 0.5\n';
        const boundaryAssertions = `
pair first=point(pyxis_clipped_2,0),last=point(pyxis_clipped_2,length(pyxis_clipped_2));
// Asymptote circles are cubic Bezier approximations. Check the drawn
// boundaries precisely, and the analytic circle/ellipse within that error.
pair firstBoundary=intersectionpoint((0,0)--2*first,circle((0,0),1));
pair lastBoundary=intersectionpoint((4,0)--((4,0)+2*(last-(4,0))),shift((4,0))*scale(1,0.5)*unitcircle);
assert(length(first-firstBoundary)<1e-5);
assert(length(last-lastBoundary)<1e-5);
assert(abs(length(first)-1)<5e-4);
assert(abs((last.x-4)^2+4*last.y^2-1)<0.002);
assert(length(pyxis_clipped_2)>0);
`;
        await compile(nodes + 'arrow L A.center B.center\nclip L nodes\n', boundaryAssertions + '\nassert(abs(first.x-1)<1e-5 && abs(last.x-3)<1e-5);\n');
        await compile(nodes + 'arrow L A.center B.center\nbend L 0.5\nclip L nodes\n', boundaryAssertions + '\nassert(first.y>0 && last.y>0);\n');
        await compile(nodes + 'line L A.center B.center\nwave L 0.2 8\nclip L nodes\n', boundaryAssertions);
        await compile(nodes + 'path L A.center 2 1 B.center\nclip L nodes\n', boundaryAssertions);
        await assert.rejects(compile('circle A 0 0 2\ncircle B 1 0 2\nline L A.center B.center\nclip L nodes\n'), /Command failed/);
        const textNodes='label A 0 0 "$\\frac{a+b}{c+d}$"\nlabel B 4 0 "$\\int dx\\,f(x)$"\n';
        const textChecks=`
path firstBox=pyxis_text_box(pyxis_clip_glyph_2_first,(0,0),pyxis_clip_transform_2,1.75);
path lastBox=pyxis_text_box(pyxis_clip_glyph_2_last,(4,0),pyxis_clip_transform_2,1.75);
pair begin=point(pyxis_physical_clipped_2,0),end=point(pyxis_physical_clipped_2,length(pyxis_physical_clipped_2));
assert(abs(begin.x-max(firstBox).x)<1e-5);
assert(abs(end.x-min(lastBox).x)<1e-5);
assert(end.x>begin.x);
write("PYXIS_TEXT_WIDTH "+string(max(firstBox).x-min(firstBox).x));
`;
        const narrow=await compile('width 90\n'+textNodes+'arrow L A.center B.center\nclip L nodes\n',textChecks);
        const wide=await compile('width 160\n'+textNodes+'arrow L A.center B.center\nclip L nodes\n',textChecks);
        assert.equal(narrow.stdout.match(/PYXIS_TEXT_WIDTH ([\d.e+-]+)/)[1],wide.stdout.match(/PYXIS_TEXT_WIDTH ([\d.e+-]+)/)[1],'text clipping uses constant physical glyph dimensions');
        await compile(textNodes+'arrow L A.center B.center\nbend L 0.5\nclip L nodes\nlabel auto 2 0 "$p$"\nplacement auto auto n 4\n',`
assert(length(pyxis_physical_clipped_2)>0);
assert(pyxis_auto_centers.length==1);
assert(length(pyxis_auto_heads[0])>0);
assert(length(point(pyxis_auto_transform*pyxis_label_strokes[0],0)-point(pyxis_physical_clipped_2,0))<1e-5);
`);
        console.log('Clipping reale: segmenti, Bezier, onde, nodi e scatole TeX misurate: OK');
    } finally { await fs.rm(temp, { recursive: true, force: true }); }
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
