#include "pyxis.hpp"
#include "expression.hpp"
#include "numerics.hpp"
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>

void check(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
void rejects(const char* source) {
    std::istringstream input(source);
    bool failed = false;
    try { pyxis::parse(input); } catch (const std::runtime_error&) { failed = true; }
    check(failed, source);
}
int main() {
    try {
        std::istringstream input("circle S 0 0 1\nline L 0 0 2 3\nmove L 4 -2\nlabel T 0 1 \"$\\alpha$\" # comment\n");
        auto scene = pyxis::parse(input);
        std::istringstream regionSource("point A 0 0\npoint B 2 0\npoint C 1 1\nregion R {\n points: \"A.center;B.center;C.center\"\n color: (0.2,0.4,0.6)\n opacity: 0.3\n outline: off\n}\n");
        auto regionScene=pyxis::parse(regionSource);
        check(regionScene.objects[3].region&&regionScene.objects[3].points.size()==4,"region closes anchored vertices");
        auto regionAsy=pyxis::asymptote(regionScene);
        check(regionAsy.find("--cycle,rgb(")!=std::string::npos&&regionAsy.find("+opacity(")!=std::string::npos,"regions generate cyclic vector fills with transparency");
        rejects("region R \"0 0;1 0;2 0\"\n");
        rejects("region R \"0 0;3 3;0 3;2 0;4 1\"\n");
        rejects("region R \"0 0;1 0;1 0;0 1\"\n");
        rejects("region R \"0 0;1 0;0 1\"\nopacity R 2\n");
        rejects("line L\nopacity L 0.3\n");
        std::istringstream course("profile quantum\nuse qft\ncircuit B {\n q0: H\n}\nfeynman F {\n}\n");
        auto courseScene=pyxis::parse(course);check(courseScene.packages.size()==2,"course profile permits additional packages");
        rejects("profile unknown\n");
        std::istringstream research("profile research\nuse qft\n");check(pyxis::parse(research).packages.size()==4,"research profile imports all packages without duplicates");
        check(scene.objects.size() == 3, "object count");
        check(scene.objects[1].x == 4 && scene.objects[1].y == -2 && scene.objects[1].a == 6 && scene.objects[1].b == 1, "line translation");
        check(scene.objects[2].text == "$\\alpha$", "LaTeX preservation");
        check(pyxis::asymptote(scene).find("$\\\\alpha$") != std::string::npos, "Asymptote escaping");
        rejects("circle S 0 0 -1");
        rejects("ellipse E 0 0 1 0");
        rejects("circle S 0 0 1\ncircle S 1 1 2");
        rejects("move unknown 1 2");
        rejects("circle S 0 0 1 extra");
        rejects("circle S 0 0");
        rejects("label T 0 0 \"unclosed");
        rejects("circle S 0 0 nan");
        rejects("circle S 1e308 0 1\nmove S 1e308 0");
        check(pyxis::evaluate("-2^2", 0, {}, {}) == -4, "power before unary minus");
        check(pyxis::evaluate("2^3^2", 0, {}, {}) == 512, "right associative powers");
        check(std::abs(pyxis::evaluate("sin(pi/2)+sqrt(4)", 0, {}, {}) - 3) < 1e-12, "math functions");
        std::istringstream plot("let a \"2\"\nfunction wave \"a*sin(x)\"\nplot P 0 3.141592653589793 3 \"wave(x)\"\n");
        auto curve = pyxis::parse(plot);
        check(curve.objects[0].points.size() == 3, "sample count");
        check(std::abs(curve.objects[0].points[1].second - 2) < 1e-12, "user function");
        rejects("plot P 0 1 2 \"sqrt(-1)\"");
        rejects("plot P 0 1 2 \"1/0\"");
        rejects("plot P 0 1 1 \"x\"");
        rejects("plot P 0 1 2 \"unknown(x)\"");
        rejects("function f \"f(x)\"\nplot P 0 1 2 \"f(x)\"");
        std::istringstream anchored("circle S 0 0 1\narrow A -2 2 S.north\nmove S 3 4\ntext T S.east \"100%\"\n");
        auto annotation = pyxis::parse(anchored);
        check(annotation.objects[1].a == 3 && annotation.objects[1].b == 5, "arrow follows translated object");
        check(annotation.objects[2].x == 4 && annotation.objects[2].y == 4, "anchored text");
        check(pyxis::asymptote(annotation).find(",Arrow)") != std::string::npos, "arrow head export");
        check(pyxis::asymptote(annotation).find("100\\\\%") != std::string::npos, "plain text escaping");
        rejects("arrow A B.start B.end\narrow B A.start A.end");
        rejects("circle S 0 0 1\narrow A 0 2 S.typo");
        rejects("arrow A 0 2 missing.north");
        std::istringstream defaults("circle S\nellipse E\nline L\ntext T \"Centro\"\n");
        auto centered = pyxis::parse(defaults);
        check(centered.objects[0].x == 0 && centered.objects[0].y == 0 && centered.objects[0].a == 1, "default circle");
        check(centered.objects[1].a == 1 && centered.objects[1].b == 0.5, "default ellipse");
        check(centered.objects[2].x == -0.5 && centered.objects[2].a == 0.5, "default centered line");
        check(centered.objects[3].x == 0 && centered.objects[3].y == 0, "default text");
        std::istringstream paths("grid 0.5\npath P @A4 @D2 @G4\nstroke P dashed\nmarkers P triangle hollow 0.1\nbend P 0.4\narrow A @B1 P.node2\nmove P 1 0\n");
        auto drawing = pyxis::parse(paths);
        check(drawing.objects[0].points[0].first == -0.5 && drawing.objects[0].points[1].second == 1, "grid anchored vertices and move");
        check(drawing.objects[1].a == 1 && drawing.objects[1].b == 1, "arrow follows path vertex");
        auto exported = pyxis::asymptote(drawing);
        check(exported.find("..controls ") != std::string::npos && exported.find("+dashed") != std::string::npos, "curved dashed path");
        check(exported.find("--cycle,white") != std::string::npos, "hollow triangle markers");
        check(exported.find("preview-only") == std::string::npos, "grid excluded from export");
        check(pyxis::asymptote(drawing, true).find("preview-only") != std::string::npos, "grid included in preview");
        std::istringstream custom("symbol star \"0 1;0.3 0.3;1 0;0.3 -0.3;0 -1;-0.3 -0.3;-1 0;-0.3 0.3\"\npath P \"-1 0;1 0\"\nmarkers P star\ncurve P 1 -1 1 1 -1\nmove P 2 0\n");
        auto symbol_scene = pyxis::parse(custom);
        check(symbol_scene.symbols.at("star").size() == 8, "custom polygon symbol");
        check(symbol_scene.objects[0].controls[0].first.first == 1, "control moves with path");
        check(pyxis::asymptote(symbol_scene).find("..controls (1,1) and (3,-1)..") != std::string::npos, "free Bezier controls");
        rejects("path P @A4");
        rejects("line L @H1 @A1");
        rejects("path P @A4 @G4\ncurve P 2 0 0 1 1");
        rejects("path P @A4 @G4\nmarkers P unknown");
        rejects("symbol S \"0 0;1 0\"");
        rejects("circle S\nbend S 1");
        rejects("grid 0");
        rejects("path P P.node1 @A1");
        std::istringstream wave("circle A @A4 0.2\ncircle B @G4 0.2\nline L A.center B.center\nwave L 0.3 3\nmove B 1 0\n");
        auto serpentine = pyxis::parse(wave);
        check(serpentine.objects[2].x == -3 && serpentine.objects[2].a == 4 && serpentine.objects[2].wave_turns == 3, "wave retains anchored endpoints");
        check(pyxis::asymptote(serpentine).find("..controls ") != std::string::npos, "wave Bezier output");
        rejects("line L\nwave L 0.2 0");
        std::istringstream spatial("camera 0 0 1\nsurface F -1 1 -1 1 2 \"x^2+y^2\"\nsphere S 0 0 1 0.2\nmove3 S 1 2 3\n");
        auto space = pyxis::parse(spatial);
        check(space.objects[0].heights.size() == 9 && space.objects[0].heights[4] == 0, "two-variable surface samples");
        check(space.objects[1].x == 1 && space.objects[1].y == 2 && space.objects[1].z == 4, "3D translation");
        check(pyxis::asymptote(space).find("settings.render=0") != std::string::npos, "vector 3D mode");
        rejects("camera 0 0 0");
        rejects("surface F -1 1 -1 1 2 \"sqrt(-1)\"");
        rejects("sphere S -1");
        std::istringstream declarations("circle A {\n radius: 0.2\n center: @A4\n}\nline L {\n to: @G4\n from: A.center\n path: wave(0.3,3)\n markers: circle(hollow,0.1)\n}\n");
        auto declarative = pyxis::parse(declarations);
        check(declarative.objects[0].x == -3 && declarative.objects[1].wave_turns == 3, "declarative object properties");
        rejects("circle S {\n radius: 1\n radius: 2\n}\n");
        rejects("circle S {\n raduis: 1\n}\n");
        rejects("circle S {\n radius: 1\n");
        std::istringstream offset_block("circle S {\n center: @D4\n radius: 1\n offset: (2,3)\n}\n");
        auto translated_block = pyxis::parse(offset_block);
        check(translated_block.objects[0].x == 2 && translated_block.objects[0].y == 3, "declarative offset preserves anchor");
        std::istringstream minimal("sphere S {\n radius: 1\n detail: outline\n}\n");
        auto minimal_scene = pyxis::parse(minimal);
        auto minimal_export = pyxis::asymptote(minimal_scene);
        check(minimal_export.find("meshpen=nullpen") != std::string::npos && minimal_export.find("*unitsphere,white") != std::string::npos, "monochrome sphere without triangulation");
        rejects("sphere S\ndetail S dense");
        std::istringstream widths("surface F {\n formula: \"0\"\n stroke-width: 0.2\n fill: none\n}\nsphere S {\n shading: 0.12\n stroke-width: 0.4\n}\n");
        auto styled = pyxis::parse(widths);
        check(styled.objects[0].stroke_width == 0.2 && styled.objects[1].shading == 0.12, "editable scientific styling");
        check(pyxis::asymptote(styled).find("normal=Z") == std::string::npos, "minimal sphere without equator");
        rejects("sphere S\nshading S -1");
        rejects("line L\nlinewidth L 0");
        std::istringstream packages(
            "use qft, quantum, relativity, statmech\ntheme: overleaf-classic\n"
            "feynman scatter {\n channel: s\n}\n"
            "quantum.circuit bell {\n q0: H, control(pair)\n q1: _, target(pair), M\n}\n"
            "place bell below scatter gap=2\n"
            "text note bell.q0_step1.north \"H gate\"\n"
            "statmech.ising spins {\n rows: 2\n columns: 3\n state: checkerboard\n}\n"
            "place spins right-of bell\n");
        auto sem = pyxis::parse(packages);
        check(sem.groups.size()==3 && sem.packages.size()==4,"packages and semantic groups");
        check(std::abs(sem.groups[1].top-(sem.groups[0].bottom-2))<1e-12,"semantic layout exact gap");
        check(std::abs(sem.groups[2].left-(sem.groups[1].right+1))<1e-12,"chained group layout");
        auto named=[&](const std::string& id)->const pyxis::Object&{for(const auto& o:sem.objects)if(o.name==id)return o;throw std::runtime_error("missing semantic object: "+id);};
        check(named("scatter.in1").flow=="forward" && named("scatter.in2").flow=="reverse","antiparticle flow");
        check(named("scatter.mediator").wave_turns>0,"photon semantic rendering");
        check(named("bell.q0_step1").kind==pyxis::Kind::GateBox,"gate glyph");
        check(named("bell.q0_step2").node_fill=="black","filled quantum control");
        check(named("note").y==named("bell.q0_step1").y+named("bell.q0_step1").b/2,"external anchor follows group placement");
        check(named("spins.r1c1_spin").b>named("spins.r1c1_spin").y && named("spins.r1c2_spin").b<named("spins.r1c2_spin").y,"alternating spin directions");
        auto semAsy=pyxis::asymptote(sem);
        check(named("scatter.in1_label").automatic_label,"QFT external labels use the common placement engine by default");
        check(semAsy.find("MidArrow")!=std::string::npos && semAsy.find("reverse(")!=std::string::npos,"fermion flow code");
        check(semAsy.find("filldraw(box(")!=std::string::npos,"gate fill masks underlying wire");
        rejects("qft.feynman F {\n channel: s\n}\n");
        rejects("use unknown\n");
        rejects("use qft\nfeynman F {\n channel: z\n}\n");
        rejects("use qft\nfeynman F {\n incoming: [electron]\n}\n");
        rejects("use quantum\ncircuit C {\n q0: control(p)\n q1: _\n}\n");
        rejects("use quantum\ncircuit C {\n q0: control(p)\n q1: _, target(p)\n}\n");
        rejects("use quantum\ncircuit C {\n q0: target(p)\n q1: target(p)\n}\n");
        rejects("use quantum\ncircuit C {\n q0: UNKNOWN\n}\n");
        std::istringstream oracleSource("profile quantum\ncircuit C {\n q0: control(f)\n q1: oracle(f,\"$U_f$\")\n q2: oracle(f,\"$U_f$\")\n}\n");
        auto oracleScene=pyxis::parse(oracleSource);bool oracleBox=false,oracleControl=false;
        for(const auto& o:oracleScene.objects){if(o.name=="C.oracle_f_1")oracleBox=o.kind==pyxis::Kind::GateBox&&std::abs(o.b-1.75)<1e-12;if(o.name=="C.link_f_1")oracleControl=o.background;}
        check(oracleBox&&oracleControl,"controlled oracle spans adjacent target qubits and masks background wires");
        rejects("profile quantum\ncircuit C {\n q0: oracle(f,\"U\")\n}\n");
        rejects("profile quantum\ncircuit C {\n q0: oracle(f,\"U\")\n q1: _\n q2: oracle(f,\"U\")\n}\n");
        rejects("profile quantum\ncircuit C {\n q0: oracle(f,\"U\")\n q1: oracle(f,\"V\")\n}\n");
        rejects("use statmech\nising S {\n spins: [0]\n}\n");
        std::istringstream spin3d("use statmech\nising S {\n dimension: 3\n rows: 2\n columns: 2\n layers: 2\n state: checkerboard\n}\n");
        auto spinCube=pyxis::parse(spin3d);unsigned spins3=0,bonds3=0;
        for(const auto& o:spinCube.objects){if(o.name.find("_spin")!=std::string::npos)++spins3;else ++bonds3;}
        check(spins3==8&&bonds3==12,"Ising cube has eight spins and twelve open bonds");
        for(const auto& o:spinCube.objects)if(o.name=="S.l1r1c1_spin")check(o.vertices3.back()[2]>o.vertices3.front()[2],"first 3D checkerboard spin points up");
        for(const auto& o:spinCube.objects)if(o.name=="S.l2r1c1_spin")check(o.vertices3.back()[2]<o.vertices3.front()[2],"checkerboard alternates between layers");
        rejects("use statmech\nising S {\n layers: 2\n}\n");
        rejects("use statmech\nising S {\n dimension: 3\n spins: [1]\n}\n");
        std::istringstream phases("profile statmech\nphase-diagram P {\n melting: negative\n}\n");
        auto phaseScene=pyxis::parse(phases);unsigned regionCount=0;
        for(const auto& o:phaseScene.objects)if(o.region){++regionCount;check(!o.outline,"phase regions do not draw artificial frame edges");}
        check(regionCount==4,"phase diagram contains four filled regions");
        auto phaseObject=[&](const std::string& id)->const pyxis::Object&{for(const auto& o:phaseScene.objects)if(o.name==id)return o;throw std::runtime_error("missing phase object");};
        check(phaseObject("P.sublimation").points.back()==phaseObject("P.vaporization").points.front(),"coexistence curves meet at triple point");
        check(phaseObject("P.vaporization").points.back().first==phaseObject("P.critical").x,"vaporization curve terminates at critical point");
        check(phaseObject("P.melting").a<phaseObject("P.melting").x,"negative melting slope selected semantically");
        rejects("profile statmech\nphase-diagram P {\n model: real-water\n}\n");
        rejects("use qft\nfeynman A {\n}\nfeynman B {\n}\nplace A below B\nplace B below A\n");
        rejects("use qft\nfeynman A {\n}\nplace A below missing\n");
        rejects("use qft\nfeynman A {\n}\nfeynman B {\n}\nplace A below B\nplace A above B\n");
        std::istringstream orbit("use statmech\nphase-flow O {\n steps: 400\n}\n");
        auto orbitScene=pyxis::parse(orbit);
        auto end=orbitScene.objects[0].points.back();
        check(std::abs(end.first-1)<1e-8&&std::abs(end.second)<1e-8,"RK4 oscillator returns to initial point");
        std::istringstream orbitFine("use statmech\nphase-flow O {\n steps: 800\n}\n");
        auto fine=pyxis::parse(orbitFine).objects[0].points.back();
        check(std::hypot(fine.first-1,fine.second)<std::hypot(end.first-1,end.second)/10,"RK4 step refinement converges");
        pyxis::numerics::Options adaptive;
        adaptive.adaptive=true; adaptive.duration=5; adaptive.maximum_step=1;
        adaptive.absolute_tolerance=1e-6; adaptive.relative_tolerance=0;
        auto decay=[](const std::array<double,2>& v,double t){return std::array<double,2>{-v[0],2*t};};
        auto loose=pyxis::numerics::integrate<2>({1,0},adaptive,decay);
        adaptive.absolute_tolerance=1e-10;
        auto tight=pyxis::numerics::integrate<2>({1,0},adaptive,decay);
        check(tight.rejected_steps>0,"adaptive integration rejects inaccurate trial steps");
        check(tight.times.back()==5&&std::abs(tight.points.back()[1]-25)<1e-11,"nonautonomous integration reaches exact final time");
        check(std::abs(tight.points.back()[0]-std::exp(-5))<std::abs(loose.points.back()[0]-std::exp(-5))/100,"adaptive tolerance refinement converges against exact solution");
        check(tight.points.size()>loose.points.size(),"tighter tolerance increases accepted sample count");
        for(size_t i=1;i<tight.times.size();++i)check(tight.times[i]>tight.times[i-1]&&tight.times[i]-tight.times[i-1]<=1,"accepted times increase and respect maximum step");
        pyxis::numerics::Options eventOptions;eventOptions.adaptive=true;eventOptions.duration=2;eventOptions.maximum_step=0.5;
        auto constant=[](const std::array<double,2>&,double){return std::array<double,2>{1,0};};
        auto located=pyxis::numerics::integrate<2>({0,0},eventOptions,constant,[](const std::array<double,2>& p,double){return p[0]>=0.37;});
        check(located.stopped&&std::abs(located.times.back()-0.37)<1e-12&&std::abs(located.points.back()[0]-0.37)<1e-12,"event localization stops at analytic crossing");
        std::istringstream adaptiveOrbit("use statmech\nphase-flow A {\n integrator: adaptive\n max-step: 0.3\n abs-tol: 1e-11\n rel-tol: 1e-11\n}\n");
        auto adaptiveEnd=pyxis::parse(adaptiveOrbit).objects[0].points.back();
        check(std::hypot(adaptiveEnd.first-1,adaptiveEnd.second)<1e-8,"adaptive oscillator closes against analytic solution");
        std::istringstream pendulum("use statmech\nphase-flow A {\n dx: \"y\"\n dy: \"-sin(x)\"\n start: [1.5,0]\n duration: 15\n integrator: adaptive\n abs-tol: 1e-9\n rel-tol: 1e-9\n max-step: 0.08\n}\n");
        auto pendulumScene=pyxis::parse(pendulum);
        for(auto p:pendulumScene.objects[0].points)check(std::abs(p.second*p.second/2+1-std::cos(p.first)-(1-std::cos(1.5)))<1e-6,"adaptive pendulum approximately conserves analytic energy");
        check(pendulumScene.objects[1].kind==pyxis::Kind::Point&&pendulumScene.objects[1].name=="A.caption","phase-flow exposes an invisible caption anchor");
        rejects("use statmech\nphase-flow A {\n integrator: unknown\n}\n");
        rejects("use statmech\nphase-flow A {\n abs-tol: 1e-8\n}\n");
        rejects("use statmech\nphase-flow A {\n integrator: adaptive\n abs-tol: 0\n}\n");
        rejects("use statmech\nphase-flow A {\n integrator: adaptive\n max-step: 0.1\n max-steps: 1\n}\n");
        rejects("use statmech\nphase-flow A {\n integrator: adaptive\n dx: \"sqrt(-1)\"\n}\n");
        std::istringstream bloch("use quantum\nbloch B {\n theta: 90deg\n phi: 0deg\n}\n");
        auto blochScene=pyxis::parse(bloch);
        for(const auto& o:blochScene.objects)if(o.name=="B.state"){
            const auto v=o.vertices3.back();check(std::abs(v[0]-1)<1e-12&&std::abs(v[1])<1e-12&&std::abs(v[2])<1e-12,"Bloch plus state");
        }
        check(pyxis::asymptote(blochScene).find("triple pyxis_c_0=")!=std::string::npos,"hierarchical names produce valid Asymptote identifiers");
        std::istringstream embedding("use relativity\nembedding F {\n mesh: 4\n}\n");
        auto embedded=pyxis::parse(embedding);
        const auto& mesh=embedded.objects[0];
        check(mesh.vertices3.size()==45,"polar surface sample count");
        check(mesh.vertices3.front()[0]==1&&mesh.vertices3.front()[2]==0,"Flamm throat at r_s");
        for(auto v:mesh.vertices3){double r=std::hypot(v[0],v[1]);check(std::abs(v[2]*v[2]-4*(r-1))<1e-11,"Flamm analytic embedding relation");}
        rejects("use relativity\nembedding E {\n metric: kerr\n}\n");
        rejects("use quantum\nbloch B {\n theta: 190deg\n}\n");
        rejects("use quantum\nbloch B {\n theta: 1\n}\n");
        rejects("mesh3 M 2 2 \"0 0 0;1 0 0\"");
        std::istringstream lorenz("use statmech\nlorenz L {\n start: [0,0,0]\n duration: 1\n steps: 100\n}\n");
        auto trajectory=pyxis::parse(lorenz);
        check(trajectory.objects[0].vertices3.size()==101,"Lorenz RK4 sample count");
        for(auto v:trajectory.objects[0].vertices3)check(v[0]==0&&v[1]==0&&v[2]==0,"Lorenz fixed point preserved");
        std::istringstream adaptiveLorenz("use statmech\nlorenz A {\n integrator: adaptive\n start: [0,0,0]\n duration: 1\n max-step: 0.02\n}\n");
        auto adaptiveEquilibrium=pyxis::parse(adaptiveLorenz);
        for(auto v:adaptiveEquilibrium.objects[0].vertices3)check(v[0]==0&&v[1]==0&&v[2]==0,"adaptive Lorenz preserves equilibrium");
        std::istringstream shortLorenz("use statmech\nlorenz A {\n duration: 0.5\n steps: 5000\n}\n");
        const auto reference=pyxis::parse(shortLorenz).objects[0].vertices3.back();
        std::istringstream adaptiveShort("use statmech\nlorenz A {\n integrator: adaptive\n duration: 0.5\n max-step: 0.02\n abs-tol: 1e-10\n rel-tol: 1e-10\n}\n");
        const auto adaptiveReference=pyxis::parse(adaptiveShort).objects[0].vertices3.back();
        for(size_t i=0;i<3;++i)check(std::abs(reference[i]-adaptiveReference[i])<1e-7,"adaptive Lorenz agrees with refined RK4 on short interval");
        rejects("use statmech\nlorenz A {\n integrator: adaptive\n max-step: 0.1\n}\n");
        std::istringstream loop("use qft\nfeynman F {\n loop: fermion\n}\n");
        auto bubble=pyxis::parse(loop);unsigned loopBranches=0;
        for(const auto& o:bubble.objects)if(o.name=="F.loop_upper"||o.name=="F.loop_lower"){
            ++loopBranches;check(o.points.size()==49,"loop sample count");
            check(std::abs(o.points.front().first+0.25)<1e-12&&std::abs(o.points.back().first-0.25)<1e-12,"loop joins mediator endpoints");
        }
        check(loopBranches==2,"self energy has two graph branches");
        std::istringstream photonLoop("profile qft\nfeynman F {\n loop: photon\n}\n");
        auto photonBubble=pyxis::parse(photonLoop);
        for(const auto& o:photonBubble.objects)if(o.name=="F.loop_upper")check(o.points.size()==193&&o.flow=="none"&&o.stroke=="solid","photon bubble uses sampled undulations without fermion flow");
        rejects("use qft\nfeynman F {\n loop: fermion\n loop-position: 0.05\n loop-radius: 0.3\n}\n");
        std::istringstream strong("use qft\nfeynman F {\n mediator: gluon\n}\n");
        auto gluon=pyxis::parse(strong);bool coil=false;
        for(const auto& o:gluon.objects)if(o.name=="F.mediator"){
            coil=o.kind==pyxis::Kind::Path&&o.points.size()>50;
            check(std::abs(o.points.front().first+0.7)<1e-12&&std::abs(o.points.back().first-0.7)<1e-12,"gluon meets exact vertices");
            for(auto p:o.points)check(p.first>=-0.7-1e-12&&p.first<=0.7+1e-12,"gluon stays inside vertex endpoints");
            check(std::abs(o.points[1].second)<0.001&&std::abs(o.points[o.points.size()-2].second)<0.001,"gluon smooth endpoint tangent");
            for(size_t i=0;i<o.points.size();++i){const auto& mirror=o.points[o.points.size()-1-i];check(std::abs(o.points[i].first+mirror.first)<1e-12&&std::abs(o.points[i].second-mirror.second)<1e-12,"gluon has matching tapers at both vertices");}
        }
        check(coil,"gluon sampled cycloidal coil");
        std::istringstream kruskal("use relativity\npenrose P {\n metric: schwarzschild\n}\n");
        auto conformal=pyxis::parse(kruskal);unsigned horizons=0,singularities=0;
        for(const auto& o:conformal.objects){if(o.name.rfind("P.horizon",0)==0)++horizons;if(o.name.find("singularity")!=std::string::npos)++singularities;}
        check(horizons==2&&singularities==2,"Schwarzschild maximal extension topology");
        std::istringstream kerrSource("profile relativity\npenrose K {\n metric: kerr\n spin: 0.7\n bands: 3\n}\n");
        auto kerrScene=pyxis::parse(kerrSource);unsigned innerHorizons=0,outerHorizons=0;
        for(const auto& o:kerrScene.objects)if(o.kind==pyxis::Kind::Line){if(o.stroke=="dashed")++innerHorizons;else ++outerHorizons;}
        check(innerHorizons==8&&outerHorizons==4,"Kerr axis window distinguishes outer and Cauchy horizons");
        for(const auto& o:kerrScene.objects)check(o.name.find("singularity")==std::string::npos,"Kerr rotation axis has no ring singularity border");
        rejects("profile relativity\npenrose K {\n metric: kerr\n spin: 1\n}\n");
        rejects("profile relativity\npenrose K {\n metric: kerr\n bands: 4\n}\n");
        std::istringstream nearExtreme("profile relativity\npenrose K {\n metric: kerr\n spin: 0.999999\n}\n");
        auto nearExtremeScene=pyxis::parse(nearExtreme);
        for(const auto& o:nearExtremeScene.objects)if(o.name=="K.axis")check(o.text.find("0.999999")!=std::string::npos,"subextremal spin caption must not round to extremal one");
        std::istringstream cones("profile relativity\nlight-cones C {\n radii: [0.5,1,2]\n rows: 1\n}\n");
        auto coneScene=pyxis::parse(cones);
        for(const auto& o:coneScene.objects){
            if(o.name=="C.row1_cone1_outgoing")check(o.a<o.x&&o.b>o.y,"inside horizon both future null directions decrease radius");
            if(o.name=="C.row1_cone2_outgoing")check(o.a==o.x&&o.b>o.y,"outgoing cone generator vertical at horizon");
            if(o.name=="C.row1_cone3_outgoing")check(std::abs((o.a-o.x)/(o.b-o.y)-(1-std::sqrt(0.5)))<1e-12,"outgoing null slope satisfies Painleve-Gullstrand metric");
        }
        std::istringstream scatteringRay("profile relativity\ngeodesic G {\n impact: 3\n}\n");
        auto rayScene=pyxis::parse(scatteringRay);
        for(const auto& o:rayScene.objects)if(o.name=="G.ray"){
            check(std::abs(std::hypot(o.points.back().first,o.points.back().second)-12)<1e-8,"scattered ray exits at initial radius");
            for(auto p:o.points)check(std::hypot(p.first,p.second)>1.5,"scattering above critical impact stays outside photon sphere");
        }
        std::istringstream capturedRay("profile relativity\ngeodesic G {\n impact: 2\n}\n");
        auto capturedScene=pyxis::parse(capturedRay);
        for(const auto& o:capturedScene.objects)if(o.name=="G.ray")check(std::abs(std::hypot(o.points.back().first,o.points.back().second)-1)<1e-8,"captured ray stops at horizon");
        rejects("profile relativity\ngeodesic G {\n impact: 3\n max-angle: 0.1\n}\n");
        rejects("profile relativity\ngeodesic G {\n kind: timelike\n}\n");
        rejects("profile relativity\nlight-cones C {\n radii: [2,1]\n}\n");
        std::istringstream liftedSource("profile relativity\ngeodesic G {\n impact: 3\n extent: 6\n view: embedding\n mesh: 4\n}\n");
        auto liftedScene=pyxis::parse(liftedSource);
        for(const auto& o:liftedScene.objects)if(o.name=="G.ray"){
            check(o.kind==pyxis::Kind::Arrow3,"embedding view produces a 3D ray");
            for(auto v:o.vertices3)check(std::abs((v[2]-0.015)*(v[2]-0.015)-4*(std::hypot(v[0],v[1])-1))<1e-10,"lifted null ray follows Flamm height with rendering offset");
        }
        std::istringstream dark("theme: blackboard\nuse quantum\ncircuit C {\n q0: H\n}\n");
        auto darkAsy=pyxis::asymptote(pyxis::parse(dark));
        check(darkAsy.find("defaultpen(white+")!=std::string::npos&&darkAsy.find("filltype=Fill(rgb(0.07,0.12,0.12))")!=std::string::npos,"blackboard ink and background");
        std::istringstream constrained(
            "line perpendicularLine {\n through: A.center\n perpendicular-to: baseline\n length: 4\n}\n"
            "circle tangent {\n tangent-to: A\n radius: 0.5\n direction: ne\n}\n"
            "circle A {\n radius: 1\n}\nline baseline 0 0 3 4\nmove A 2 -1\n"
            "line parallelLine {\n through: tangent.center\n parallel-to: baseline\n length: 2\n}\n");
        auto construction=pyxis::parse(constrained);
        const auto& perpendicularLine=construction.objects[0];const auto& tangent=construction.objects[1];const auto& parallelLine=construction.objects[4];
        check(std::abs((perpendicularLine.a-perpendicularLine.x)*3+(perpendicularLine.b-perpendicularLine.y)*4)<1e-12,"perpendicular direction dot product");
        check(std::abs((perpendicularLine.x+perpendicularLine.a)/2-2)<1e-12&&std::abs((perpendicularLine.y+perpendicularLine.b)/2+1)<1e-12,"through point follows moved dependency");
        check(std::abs(std::hypot(tangent.x-2,tangent.y+1)-1.5)<1e-12,"exact external circle tangency after move");
        check(std::abs((parallelLine.a-parallelLine.x)*4-(parallelLine.b-parallelLine.y)*3)<1e-12,"parallel direction cross product");
        check(std::abs(std::hypot(parallelLine.a-parallelLine.x,parallelLine.b-parallelLine.y)-2)<1e-12,"constraint length");
        rejects("parallel A 0 0 B 2\nparallel B 0 0 A 2\n");
        rejects("tangent-circle A B east 1\ntangent-circle B A east 1\n");
        rejects("line L 0 0 0 0\nparallel P 0 0 L 2\n");
        rejects("circle A\ntangent-circle B A wrong 1\n");
        rejects("circle A\ntangent-circle B A east 1\nmove B 1 0\n");
        rejects("circle A {\n center: @A4\n tangent-to: B\n}\n");
        rejects("line L {\n perpendicular-to: P\n}\n");
        rejects("line L\nbend L 1\nparallel P 0 0 L 2\n");
        std::istringstream clipping("circle A 0 0 1\nellipse B 4 0 1 0.5\narrow L {\n from: A.center\n to: B.center\n clip: nodes\n path: arc(0.3)\n}\n");
        auto clipped=pyxis::parse(clipping);
        check(clipped.objects[2].clip_start=="A"&&clipped.objects[2].clip_end=="B","clipping resolves endpoint node owners");
        check(clipped.objects[2].x==0&&clipped.objects[2].a==4,"clipping preserves topological anchors");
        auto clippedCode=pyxis::asymptote(clipped);
        check(clippedCode.find("intersections(curve,first)")!=std::string::npos&&clippedCode.find("subpath(curve,lo,hi)")!=std::string::npos,"clip uses actual path intersections");
        check(clippedCode.find("draw(pyxis_clipped_2,")!=std::string::npos,"arrow draws clipped path");
        rejects("line L\nclip L nodes\n");
        rejects("path P \"0 0;1 1\"\nclip P nodes\n");
        rejects("line L @A4 @G4\nclip L nodes\n");
        rejects("label T \"\"\nline L T.center 2 0\nclip L nodes\n");
        std::istringstream networks("use quantum\ntensor-network chain {\n sites: 2\n}\n"
            "tensor-network net {\n layout: peps\n rows: 2\n columns: 3\n}\n"
            "place net below chain gap=2\nmove net.r1c1 0.25 0.15\n");
        auto tensors=pyxis::parse(networks);
        auto tensorObject=[&](const std::string& id)->const pyxis::Object&{for(const auto& o:tensors.objects)if(o.name==id)return o;throw std::runtime_error("missing tensor object: "+id);};
        const auto& site=tensorObject("net.r1c1");const auto& bond=tensorObject("net.r1c1_bond");
        check(bond.x==site.x&&bond.y==site.y,"PEPS bond follows moved tensor inside translated group");
        check(bond.clip_start=="net.r1c1"&&bond.clip_end=="net.r1c2","PEPS bond clips both tensor boundaries");
        check(tensorObject("net.r1c1_label").x==site.x&&tensorObject("net.r1c1_label").y==site.y,"PEPS label follows node");
        check(std::abs(tensorObject("net.r1c1_physical_tip").x-site.x-0.55)<1e-12&&std::abs(tensorObject("net.r1c1_physical_tip").y-site.y-0.6)<1e-12,"physical leg follows node with retained offset");
        check(std::abs(tensors.groups[1].top-tensors.groups[0].bottom+2)<1e-12,"internal anchors do not double translate groups");
        unsigned bonds=0;for(const auto& o:tensors.objects)if(o.name.rfind("net.",0)==0&&o.name.find("_bond")!=std::string::npos)++bonds;
        check(bonds==7,"PEPS 2x3 has seven virtual bonds");
        rejects("use quantum\ntensor-network N {\n layout: peps\n sites: 3\n}\n");
        rejects("use quantum\ntensor-network N {\n rows: 3\n}\n");
        std::istringstream invisible("point A\npoint B A.center\nmove B 1 2\nline L A.center B.center\n");
        auto points=pyxis::parse(invisible);
        check(points.objects[1].x==1&&points.objects[1].y==2&&points.objects[2].a==1&&points.objects[2].b==2,"named invisible points retain relative coordinates");
        std::istringstream automaticText("circle C\nlabel T {\n at: C.center\n text: \"$p_1+p_2$\"\n placement: auto\n prefer: sw\n gap: 4\n}\n");
        auto labeling=pyxis::parse(automaticText);
        check(labeling.objects[1].automatic_label&&labeling.objects[1].label_preference=="sw"&&labeling.objects[1].label_gap_bp==4,"automatic label properties");
        auto labelingCode=pyxis::asymptote(labeling);
        check(labelingCode.find("label(glyph,texts[i]")!=std::string::npos&&labelingCode.find("new void(frame f, transform t)")!=std::string::npos,"labels measured through TeX in final physical coordinates");
        check(labelingCode.find("pyxis_label_owners.push(circle((0,0),1))")!=std::string::npos,"label knows associated node silhouette");
        rejects("label T \"label\"\nplacement T auto wrong 3\n");
        rejects("label T \"label\"\nplacement T auto n -1\n");
        rejects("label T \"\"\nplacement T auto\n");
        rejects("circle C\nplacement C auto\n");
        rejects("label T {\n text: \"x\"\n prefer: n\n}\n");
        rejects("label T \"x\"\nplacement T auto\nline L T.center 1 0\n");
        std::istringstream textClip("label A 0 0 \"$x$\"\nlabel B 4 0 \"$y$\"\narrow L A.center B.center\nclip L nodes\n");
        auto textClipped=pyxis::parse(textClip);check(textClipped.objects[2].clip_start=="A"&&textClipped.objects[2].clip_end=="B","fixed labels become clipping targets");
        check(pyxis::asymptote(textClipped).find("pyxis_text_box(pyxis_clip_glyph_2_first")!=std::string::npos,"text clipping deferred until final transform");
        std::istringstream fixedFeynman("use qft\nfeynman F {\n label-placement: fixed\n}\n");
        auto fixedDiagram=pyxis::parse(fixedFeynman);
        for(const auto& o:fixedDiagram.objects)if(o.kind==pyxis::Kind::Label)check(!o.automatic_label,"fixed QFT layout remains available");
        std::cout << "Tutti i test del nucleo, vincoli e pacchetti sono passati.\n";
        return 0;
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
