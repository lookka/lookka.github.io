'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const { cachedRender, digest, pruneObsolete } = require('../vscode/cache');
const { extract, optionsSource, labelPreamble, latexSource, writeDocument } = require('../tools/pyxis/latex');
async function main() {
    const temporaryRoot = path.join(__dirname, '..', 'tmp');
    await fs.mkdir(temporaryRoot, { recursive: true });
    const folder = await fs.mkdtemp(path.join(temporaryRoot, 'pyxis-cache-test-'));
    try {
        let calls = 0;
        const produce = async () => { ++calls; return { pdf: Buffer.from('%PDF-test') }; };
        const key = digest('source and dependencies');
        let cache;
        await Promise.all([cachedRender(folder, key, ['pdf'], produce), cachedRender(folder, key, ['pdf'], produce)]);
        assert.equal(calls, 1, 'concurrent same-key requests share renderer');
        await cachedRender(folder, key, ['pdf'], produce, state => { cache = state; });
        assert.equal(calls, 1); assert.equal(cache.hit, true);
        await fs.writeFile(path.join(folder, key, 'figure.pdf'), '%PDF-corrupted');
        await cachedRender(folder, key, ['pdf'], produce);
        assert.equal(calls, 2, 'corrupt output cannot become a cache hit');
        await assert.rejects(cachedRender(folder, digest('bad'), ['pdf'], async () => ({ pdf: Buffer.from('bad') })), /non valido/);
        assert.equal(await fs.stat(path.join(folder, digest('bad'))).then(() => true, () => false), false, 'failed render is not published');
        const tex = String.raw`% \begin{pyxis}
\verb|\begin{pyxis}|
\begin{verbatim}
\begin{pyxis}
\end{pyxis}
\end{verbatim}
\begin{pyxis}[width=80,theme=paper]
circle S
\end{pyxis}
`;
        const blocks = extract(tex);
        assert.equal(blocks.length, 1, 'comments, inline verb and verbatim are skipped');
        assert.match(blocks[0].body, /circle S/);
        assert.equal(blocks[0].prefix, 'width 80\ntheme paper\n');
        assert.throws(() => extract('\\begin{pyxis}\ncircle S'), /non chiuso/);
        assert.throws(() => optionsSource('width=3,width=4'), /duplicata/);
        assert.throws(() => optionsSource('width=-3'), /positiva/);
        assert.equal(labelPreamble('\\usepackage{pyxis,amsmath}\n% \\usepackage{bad}\n\\begin{document}'), '\\usepackage{amsmath}');
        const macros=String.raw`\usepackage{amsmath}
\newcommand{\ket}[1]{\left|#1\right\rangle}
\DeclareMathOperator{\Tr}{Tr}
\begin{document}`;
        assert.match(labelPreamble(macros),/newcommand\{\\ket\}\[1\]/);
        assert.match(labelPreamble(macros),/DeclareMathOperator\{\\Tr\}/);
        assert.equal(latexSource('circle S % comment\nlabel T "100%"'), 'circle S # comment\nlabel T "100%"');
        const source = path.join(folder, 'source.tex');
        await fs.writeFile(source, tex);
        await assert.rejects(writeDocument(source, source, {}), /sovrascritto/);
        assert.equal(await fs.readFile(source, 'utf8'), tex, 'original document preserved');
        const owner = { compilerPath: 'compiler.exe', compilerHash: 'old', rendererHash: 'renderer' };
        await cachedRender(folder, digest('obsolete'), ['pdf'], produce, undefined, owner);
        await cachedRender(folder, digest('retained-document'), ['pdf'], produce, undefined, { ...owner, pinned: true });
        await cachedRender(folder, digest('other-compiler'), ['pdf'], produce, undefined, { ...owner, compilerPath: 'other.exe' });
        await cachedRender(folder, digest('contains-user-file'), ['pdf'], produce, undefined, owner);
        await fs.writeFile(path.join(folder, digest('contains-user-file'), 'my-source.tex'), 'user content');
        assert.equal(await pruneObsolete(folder, { ...owner, compilerHash: 'new' }), 1, 'only obsolete owned, unpinned output is pruned');
        assert.ok((await fs.stat(path.join(folder, digest('retained-document')))).isDirectory(), 'retained TeX dependency preserved');
        assert.ok((await fs.stat(path.join(folder, digest('other-compiler')))).isDirectory(), 'other backend preserved');
        assert.equal(await fs.readFile(path.join(folder, digest('contains-user-file'), 'my-source.tex'), 'utf8'), 'user content');
        console.log('Cache atomica, corruzione, concorrenza ed estrazione LaTeX: OK');
    } finally { await fs.rm(folder, { recursive: true, force: true }); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
