'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const assert=require('node:assert/strict');
const {render}=require('../vscode/backend');
async function main(){
    const temporary=await fs.mkdtemp(path.join(os.tmpdir(),'pyxis-benchmark-'));
    try{
        const source=await fs.readFile(path.resolve(__dirname,'../examples/qft.pyxis'),'utf8');
        const options={compiler:path.resolve(__dirname,'../build/pyxis.exe'),cacheDir:temporary};
        async function measure(){let state;const start=performance.now();const result=await render(source,['pdf'],{...options,onCache:value=>{state=value;}});return {milliseconds:performance.now()-start,hit:state.hit,bytes:result.pdf.length};}
        const cold=await measure(),warm=[];for(let i=0;i<5;++i)warm.push(await measure());
        assert.equal(cold.hit,false);assert.ok(warm.every(result=>result.hit));
        console.log(JSON.stringify({figure:'qft.pyxis',coldMilliseconds:Math.round(cold.milliseconds),warmAverageMilliseconds:Math.round(warm.reduce((sum,item)=>sum+item.milliseconds,0)/warm.length),warmMaximumMilliseconds:Math.round(Math.max(...warm.map(item=>item.milliseconds))),pdfBytes:cold.bytes},null,2));
    }finally{await fs.rm(temporary,{recursive:true,force:true});}
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
