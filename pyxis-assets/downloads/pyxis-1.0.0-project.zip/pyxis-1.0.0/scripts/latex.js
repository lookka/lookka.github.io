'use strict';
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs/promises');
const { execFile } = require('node:child_process');
const { writeDocument } = require('../tools/pyxis/latex');
const { atomicWrite } = require('../vscode/cache');
async function main() {
    const args = process.argv.slice(2);
    const compile = args.includes('--compile');
    const files = args.filter(arg => arg !== '--compile');
    if (!files.length || files.length > 2 || files.some(arg => arg.startsWith('--'))) throw new Error('Uso: node scripts/latex.js input.tex [output.tex] [--compile]');
    const source = path.resolve(files[0]);
    const destination = files[1] ? path.resolve(files[1]) : source.replace(/\.tex$/i, '') + '.pyxis.tex';
    if (!/\.tex$/i.test(source) || !/\.tex$/i.test(destination)) throw new Error('Sorgente e documento derivato devono avere estensione .tex');
    const root = path.resolve(__dirname, '..');
    const result = await writeDocument(source, destination, {
        compiler: path.join(root, 'build', 'pyxis.exe'),
        pinCache: !compile || !!files[1],
        asymptote: process.env.PYXIS_ASYMPTOTE || '', ghostscript: process.env.PYXIS_GHOSTSCRIPT || ''
    });
    for (const figure of result.figures) console.log(`Riga ${figure.line}: ${figure.cached ? 'cache' : 'render'} (${Math.round(figure.milliseconds)} ms)`);
    if (!compile || files[1]) console.log(destination);
    if (compile) {
        const environment = { ...process.env, TEXINPUTS: path.join(root, 'latex').replace(/\\/g, '/') + '//' + path.delimiter + (process.env.TEXINPUTS || '') + path.delimiter };
        const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'pyxis-latex-'));
        try {
            await new Promise((resolve, reject) => execFile('pdflatex', ['-interaction=nonstopmode', '-halt-on-error', '-output-directory=' + temp, destination],
                { cwd: path.dirname(source), env: environment, windowsHide: true, timeout: 60000, maxBuffer: 2 * 1024 * 1024 },
                (error, stdout, stderr) => error ? reject(new Error(stdout + '\n' + stderr)) : resolve()));
            const finalPdf = destination.replace(/\.tex$/i, '.pdf');
            await atomicWrite(finalPdf, await fs.readFile(path.join(temp, path.basename(finalPdf))));
            console.log(finalPdf);
        } finally {
            await fs.rm(temp, { recursive: true, force: true });
            if (!files[1]) await fs.rm(destination, { force: true });
        }
    }
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
