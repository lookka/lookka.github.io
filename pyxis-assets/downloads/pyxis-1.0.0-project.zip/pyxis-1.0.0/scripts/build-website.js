'use strict';
// Rebuild the public manuals and assets without copying local runtimes or caches.
// Usage: node scripts/build-website.js SITE_ROOT MARKED_MODULE_PATH
const fs=require('node:fs/promises'),path=require('node:path'),{pathToFileURL}=require('node:url');
const root=path.resolve(__dirname,'..');
const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const slug=value=>value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const plain=value=>value.replace(/<[^>]+>/g,'').replace(/&#39;|&apos;/g,"'").replace(/&quot;/g,'"').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
async function main(){
 const site=path.resolve(process.argv[2]||'website/lookka.github.io');
 const markdown=await import(pathToFileURL(path.resolve(process.argv[3])).href);
 const marked=markdown.marked;
 const assets=path.join(site,'pyxis-assets'),docs=path.join(assets,'docs');
 await fs.mkdir(docs,{recursive:true});await fs.mkdir(path.join(assets,'figures'),{recursive:true});await fs.mkdir(path.join(assets,'downloads'),{recursive:true});
 await fs.copyFile(path.join(root,'assets/pyxis-icon.svg'),path.join(assets,'pyxis-icon.svg'));
 for(const name of ['qft','oracles','phase-diagrams','geodesic-embedding'])await fs.copyFile(path.join(root,'output',`${name}.png`),path.join(assets,'figures',`${name}.png`));
 const files=(await fs.readdir(path.join(root,'docs'))).filter(f=>f.endsWith('.md'));
 const titles=[];
 const shell=(title,body)=>`<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="${escape(title)} — documentazione Pyxis 1.0, Luca Melani"><title>${escape(title)} · Pyxis</title><link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=DM+Sans:opsz,wght@9..40,400;9..40,600;9..40,700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap" rel="stylesheet"><link rel="icon" href="../pyxis-icon.svg" type="image/svg+xml"><link rel="stylesheet" href="../../style.css"><link rel="stylesheet" href="../pyxis.css?v=20261013-reference"><script defer src="../pyxis.js?v=20261013-reference"></script></head><body><header class="site-header"><a class="wordmark" href="../../index.html">Luca Melani</a><nav aria-label="Navigazione"><a href="../../pyxis.html">Pyxis</a><a href="index.html">Manuali</a><a href="../../pyxis.html#download">Download</a></nav></header><main class="docs-shell">${body}</main><footer><p>© <span id="year"></span> Luca Melani · Pyxis 1.0 · MIT</p><p><a href="../../pyxis.html">Torna al progetto</a></p></footer></body></html>`;
 for(const file of [...files,'THIRD-PARTY.md']){
  const input=await fs.readFile(path.join(root,file==='THIRD-PARTY.md'?file:'docs/'+file),'utf8');
  const title=input.match(/^# (.+)$/m)?.[1]||file;
  titles.push({file,title});await fs.writeFile(path.join(docs,file),input);
  let html=marked.parse(input,{gfm:true});html=html.replace(/<h1>.*?<\/h1>/s,'');
  html=html.replace(/href="([^"#:]+)\.md(#[^"]*)?"/g,(_m,base,hash)=>`href="${base}.html${hash||''}"`);
  const toc=[],counts=new Map();
  html=html.replace(/<h([23])>(.*?)<\/h\1>/gs,(_m,level,content)=>{const text=plain(content);const base=slug(text),count=counts.get(base)||0;counts.set(base,count+1);const id=base+(count?'-'+count:'');if(level==='2')toc.push({id,text});return `<h${level} id="${id}">${content}</h${level}>`;});
  html=html.replace(/<table>/g,'<div class="table-scroll"><table>').replace(/<\/table>/g,'</table></div>');
  html='<section class="manual-section">'+html.replace(/(<h2\b[^>]*>)/g,'</section><section class="manual-section">$1')+'</section>';
  const reference=file==='COMANDI.md',commands=[],categories=new Set();
  if(reference)html=html.replace(/<section class="manual-section">([\s\S]*?)<\/section>/g,(all,content)=>{
   const heading=content.match(/<h2\b[^>]*>(.*?)<\/h2>/s),category=content.match(/<strong>Categoria:<\/strong>\s*([^<]+)/);
   if(!heading||!category)return all;
   const command=plain(heading[1]),group=plain(category[1]).trim().replace(/\.$/,'');commands.push(command);categories.add(group);
   return `<section class="manual-section command-entry" data-command="${escape(command)}" data-category="${escape(group)}">${content}</section>`;
  });
  const lookup=reference?`<div class="reference-controls"><label for="search">Trova un comando<input class="docs-search" id="search" type="search" list="command-names" placeholder="circle, curve, qft.feynman…" autocomplete="off"></label><datalist id="command-names">${commands.sort().map(name=>`<option value="${escape(name)}"></option>`).join('')}</datalist><label for="category">Categoria<select id="category" class="reference-category"><option value="">Tutte le categorie</option>${[...categories].map(group=>`<option value="${escape(group)}">${escape(group)}</option>`).join('')}</select></label></div><p class="reference-hint">Un nome esatto apre la sua scheda; puoi cercare anche parametri e concetti. Gli esempi «Esempio completo» sono sorgenti eseguibili.</p>`:'<label for="search">Cerca in questo manuale</label><input class="docs-search" id="search" type="search" placeholder="Funzione, file o argomento…">';
  const body=`<p class="eyebrow">PYXIS / DOCUMENTAZIONE / RELEASE 1.0</p><h1>${escape(title)}</h1><div class="docs-tools"><a href="${escape(file)}" download>Scarica Markdown ↓</a><a href="../downloads/pyxis-1.0.0-documentation.zip" download>Tutti i manuali ↓</a></div>${lookup}<p class="search-status" role="status" aria-live="polite"></p><div class="docs-layout"><aside class="docs-toc"><details open><summary>Indice</summary><nav aria-label="Indice del manuale">${toc.map(item=>`<a href="#${item.id}">${escape(item.text)}</a>`).join('')}</nav></details></aside><article>${html}</article></div>`;
  await fs.writeFile(path.join(docs,file.replace(/\.md$/,'.html')),shell(title,body));
 }
 const library=`<p class="eyebrow">PYXIS / DOCUMENTAZIONE COMPLETA</p><h1>Manuali e note di progetto.</h1><p class="docs-intro">Ho raccolto qui la documentazione della release 1.0. Il riferimento COMANDI e il manuale PACCHETTI descrivono la sintassi implementata. FEYNMAN, FIGURE-TEORICHE e PYXIS-SEMANTICO conservano anche proposte di design: i loro esempi indicati come futuri non sono comandi disponibili.</p><ul class="library-list">${titles.map(item=>`<li><a href="${item.file.replace(/\.md$/,'.html')}">${escape(item.title)}</a><small><a href="${item.file}" download>Versione Markdown</a></small></li>`).join('')}</ul><a class="button" href="../downloads/pyxis-1.0.0-documentation.zip" download>Scarica tutti i manuali ↓</a>`;
 await fs.writeFile(path.join(docs,'index.html'),shell('Documentazione completa',library));
 await fs.copyFile(path.join(root,'release/pyxis-1.0.0-win32-x64.vsix'),path.join(assets,'downloads/pyxis-1.0.0-win32-x64.vsix'));
 await fs.copyFile(path.join(root,'LICENSE'),path.join(assets,'downloads/LICENSE.txt'));
 // Keep published examples equal to their downloadable, executable sources.
 let page=await fs.readFile(path.join(site,'pyxis.html'),'utf8');
 for(const [id,file] of [['qft','qft'],['quantum','oracles'],['statmech','phase-diagrams'],['relativity','geodesic-embedding']]){
  const source=await fs.readFile(path.join(root,'examples',file+'.pyxis'),'utf8');
  const pattern=new RegExp(`(id="example-${id}"[\\s\\S]*?<pre><code>)[\\s\\S]*?(<\\/code><\\/pre>)`);
  page=page.replace(pattern,(_m,before,after)=>before+escape(source.trim())+after);
 }
 await fs.writeFile(path.join(site,'pyxis.html'),page);
 console.log(`Public manuals: ${titles.length}; packaged editor, gallery and examples ready.`);
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
