param([string]$SiteRoot = '')
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
if (!$SiteRoot) { $SiteRoot = Join-Path $projectRoot 'website/lookka.github.io' }
$downloads = Join-Path ([IO.Path]::GetFullPath($SiteRoot)) 'pyxis-assets/downloads'
New-Item -ItemType Directory -Path $downloads -Force | Out-Null
$version = (Get-Content -LiteralPath (Join-Path $projectRoot 'vscode/package.json') -Raw | ConvertFrom-Json).version
Add-Type -AssemblyName System.IO.Compression

function Write-Archive([string]$destination, [object[]]$files) {
    $temporary = $destination + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew)
    $zip = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($item in $files) {
            $entry = $zip.CreateEntry($item.Name, [IO.Compression.CompressionLevel]::Optimal)
            $inputFile = [IO.File]::OpenRead($item.Path)
            $outputFile = $entry.Open()
            try { $inputFile.CopyTo($outputFile) }
            finally { $inputFile.Dispose(); $outputFile.Dispose() }
        }
        $zip.Dispose(); $stream.Dispose()
        Move-Item -LiteralPath $temporary -Destination $destination -Force
        Write-Output $destination
    } finally {
        $zip.Dispose(); $stream.Dispose()
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

$prefix = 'pyxis-' + $version + '/'
$sources = @()
foreach ($folder in @('src','vscode','tools/pyxis','latex','docs','examples','scripts','tests','assets')) {
    foreach ($file in Get-ChildItem -LiteralPath (Join-Path $projectRoot $folder) -File -Recurse) {
        $relative = $file.FullName.Substring($projectRoot.Length + 1).Replace('\','/')
        if ($relative -match '(^|/)(\.pyxis_cache|node_modules|tmp|\.git|build|output)(/|$)') { continue }
        if ($file.Extension -notin '.cpp','.hpp','.js','.json','.md','.tex','.pyxis','.sty','.ps1','.svg','.png') { continue }
        $sources += @{Name=$prefix+$relative;Path=$file.FullName}
    }
}
foreach ($name in @('README.md','LICENSE','THIRD-PARTY.md','CMakeLists.txt','Installa Pyxis.cmd','build/pyxis.exe',('release/pyxis-'+$version+'-win32-x64.vsix'))) {
    $sources += @{Name=$prefix+$name;Path=(Join-Path $projectRoot $name)}
}
Write-Archive (Join-Path $downloads ('pyxis-'+$version+'-project.zip')) $sources
$manuals = @(Get-ChildItem -LiteralPath (Join-Path $projectRoot 'docs') -File -Filter '*.md' | ForEach-Object { @{Name=('docs/'+$_.Name);Path=$_.FullName} })
foreach ($name in @('LICENSE','THIRD-PARTY.md')) { $manuals += @{Name=$name;Path=(Join-Path $projectRoot $name)} }
Write-Archive (Join-Path $downloads ('pyxis-'+$version+'-documentation.zip')) $manuals
$checksums = @(Get-ChildItem -LiteralPath $downloads -File | Where-Object {$_.Extension -in '.zip','.vsix'} | Sort-Object Name | ForEach-Object { (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() + '  ' + $_.Name })
[IO.File]::WriteAllText((Join-Path $downloads 'SHA256SUMS.txt'), (($checksums -join "`n")+"`n"), [Text.UTF8Encoding]::new($false))
