'use strict';
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { execFile } = require('node:child_process');
const { resolveTools } = require('../vscode/backend');

function invoke(executable, args, cwd, input) {
    return new Promise(resolve => {
        const child = execFile(executable, args, { cwd, windowsHide: true, timeout: 20000, maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
            resolve({ ok: !error, code: error?.code, log: (stdout + stderr).trim() });
        });
        child.stdin.on('error', () => {});
        child.stdin.end(input || '');
    });
}
async function main() {
    const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'pyxis-doctor-'));
    const tex = '\\documentclass{article}\n\\begin{document}\n$\\alpha^2$\n\\end{document}\n';
    try {
        const tools = await resolveTools({ asymptote: process.env.PYXIS_ASYMPTOTE || '', ghostscript: process.env.PYXIS_GHOSTSCRIPT || '' });
        await fs.writeFile(path.join(temp, 'label.tex'), tex);
        for (const [title, program, args, input] of [
            ['Asymptote', tools.asymptote, ['--version']],
            ...(tools.ghostscript ? [['Ghostscript', tools.ghostscript, ['--version']]] : []),
            ['LaTeX da file', 'pdflatex', ['-interaction=nonstopmode', '-halt-on-error', 'label.tex']],
            ['LaTeX via pipe', 'latex', ['\\scrollmode'], tex],
            ['LaTeX via pipe con NUL', 'latex', ['NUL', '\\scrollmode'], tex]
        ]) {
            const result = await invoke(program, args, temp, input);
            console.log(`${title}: ${result.ok ? 'OK' : 'ERRORE'}${result.code ? ` (${result.code})` : ''}`);
            console.log(result.log.slice(-1800));
        }
    } finally { await fs.rm(temp, { recursive: true, force: true }); }
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
