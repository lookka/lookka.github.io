$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$codeCommand = Get-Command code.cmd -ErrorAction Stop
$editorExecutable = Join-Path (Split-Path -Parent (Split-Path -Parent $codeCommand.Source)) 'Code.exe'
$testDirectory = Join-Path $projectRoot ('tmp/editor-test-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $testDirectory -Force | Out-Null
$testWorkspace = Join-Path $testDirectory 'workspace'
New-Item -ItemType Directory -Path $testWorkspace -Force | Out-Null
try {
    $arguments = @(
        '--disable-gpu', '--skip-welcome', '--skip-release-notes', '--disable-workspace-trust',
        ('--user-data-dir="' + (Join-Path $testDirectory 'profile') + '"'),
        ('--extensions-dir="' + (Join-Path $testDirectory 'extensions') + '"'),
        ('--extensionDevelopmentPath="' + (Join-Path $projectRoot 'vscode') + '"'),
        ('--extensionTestsPath="' + (Join-Path $projectRoot 'tests/editor') + '"'),
        ('"' + $testWorkspace + '"')
    )
    $testProcess = Start-Process -FilePath $editorExecutable -ArgumentList $arguments -WindowStyle Hidden -PassThru -Wait
    if ($testProcess.ExitCode -ne 0) { throw ('Test Extension Host fallito: ' + $testProcess.ExitCode) }
    Get-Content -LiteralPath (Join-Path $projectRoot 'tmp/editor-test-result.json')
    Remove-Item -LiteralPath (Join-Path $projectRoot 'tmp/editor-test-result.json') -Force
} finally {
    # Remove only the unique directory this invocation created, after containment verification.
    $absoluteTarget = [System.IO.Path]::GetFullPath($testDirectory)
    $allowedRoot = [System.IO.Path]::GetFullPath((Join-Path $projectRoot 'tmp')) + [System.IO.Path]::DirectorySeparatorChar
    if (!$absoluteTarget.StartsWith($allowedRoot, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Directory di test fuori workspace' }
    Remove-Item -LiteralPath $absoluteTarget -Recurse -Force -ErrorAction SilentlyContinue
}
