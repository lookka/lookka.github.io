'use strict';
const path=require('node:path');
const {compileDocument}=require('../vscode/native-latex');
async function main(){
    const args=process.argv.slice(2),files=args.filter(arg=>!arg.startsWith('--'));
    const engineArgs=args.filter(arg=>arg.startsWith('--engine='));
    if(files.length!==1||engineArgs.length>1||args.some(arg=>arg.startsWith('--')&&!arg.startsWith('--engine=')))throw new Error('Uso: node scripts/build-latex.js documento.tex [--engine=pdflatex|lualatex|xelatex]');
    const result=await compileDocument(files[0],{compiler:path.resolve(__dirname,'../build/pyxis.exe'),engine:engineArgs[0]?.slice(9)||'pdflatex',asymptote:process.env.PYXIS_ASYMPTOTE||'',ghostscript:process.env.PYXIS_GHOSTSCRIPT||''});
    for(const figure of result.figures)console.log(`Riga ${figure.line}: ${figure.cached?'cache':'render'}`);
    console.log(result.destination);
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
