param(
    [string]$Source = 'examples/geometry.pyxis',
    [ValidateSet('svg', 'pdf')][string]$Format = 'svg',
    [switch]$Preview
)
$ErrorActionPreference = 'Stop'
if ($Preview) { & node (Join-Path $PSScriptRoot 'render.js') $Source $Format --preview }
else { & node (Join-Path $PSScriptRoot 'render.js') $Source $Format }
if ($LASTEXITCODE -ne 0) { throw 'Esportazione Pyxis fallita: controlla i messaggi sopra.' }
