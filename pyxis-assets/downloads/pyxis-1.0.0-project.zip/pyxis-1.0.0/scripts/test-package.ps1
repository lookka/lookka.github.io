$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$manifest = Get-Content -LiteralPath (Join-Path $projectRoot 'vscode/package.json') -Raw | ConvertFrom-Json
$package = Join-Path $projectRoot ('release/pyxis-' + $manifest.version + '-win32-x64.vsix')
$code = Get-Command code.cmd -ErrorAction Stop
$editor = Join-Path (Split-Path -Parent (Split-Path -Parent $code.Source)) 'Code.exe'
$temporary = Join-Path $projectRoot ('tmp/package-test-' + [guid]::NewGuid().ToString('N'))
$profile = Join-Path $temporary 'profile'
$extensions = Join-Path $temporary 'extensions'
$workspace = Join-Path $temporary 'workspace'
New-Item -ItemType Directory -Path $workspace -Force | Out-Null
try {
    & $code.Source --user-data-dir $profile --extensions-dir $extensions --install-extension $package --force
    if ($LASTEXITCODE -ne 0) { throw 'Il VSIX non e installabile' }
    $installed = (& $code.Source --user-data-dir $profile --extensions-dir $extensions --locate-extension pyxis-local.pyxis | Select-Object -Last 1).Trim()
    $installedManifest = Get-Content -LiteralPath (Join-Path $installed 'package.json') -Raw | ConvertFrom-Json
    if ($installedManifest.version -ne $manifest.version) { throw 'Versione installata errata' }
    if (!(Test-Path -LiteralPath (Join-Path $installed 'bin/pyxis.exe'))) { throw 'Compilatore non incluso nel VSIX' }
    $runtime = @{schema=1;asymptote=(Join-Path $projectRoot '.tools/asymptote/asy.exe');ghostscript=(Join-Path $projectRoot '.tools/ghostscript/bin/gswin64c.exe')}
    [IO.File]::WriteAllText((Join-Path $installed 'pyxis-runtime.json'), ($runtime | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
    $arguments = @('--disable-gpu','--skip-welcome','--skip-release-notes','--disable-workspace-trust',
        ('--user-data-dir="' + $profile + '"'), ('--extensions-dir="' + $extensions + '"'),
        ('--extensionDevelopmentPath="' + $installed + '"'),
        ('--extensionTestsPath="' + (Join-Path $projectRoot 'tests/editor') + '"'), ('"' + $workspace + '"'))
    $process = Start-Process -FilePath $editor -ArgumentList $arguments -WindowStyle Hidden -PassThru
    if (!$process.WaitForExit(90000)) { Stop-Process -Id $process.Id -Force; throw 'Timeout del profilo di prova' }
    if ($process.ExitCode -ne 0) { throw 'Test del pacchetto installato fallito' }
    Get-Content -LiteralPath (Join-Path $projectRoot 'tmp/editor-test-result.json')
    Remove-Item -LiteralPath (Join-Path $projectRoot 'tmp/editor-test-result.json') -Force
} finally {
    $target = [IO.Path]::GetFullPath($temporary)
    $allowed = [IO.Path]::GetFullPath((Join-Path $projectRoot 'tmp')) + [IO.Path]::DirectorySeparatorChar
    if (!$target.StartsWith($allowed, [StringComparison]::OrdinalIgnoreCase)) { throw 'Profilo di prova fuori workspace' }
    Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue
}
