'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const { render } = require('../vscode/backend');
async function main() {
    const source = path.resolve(process.argv[2] || 'examples/geometry.pyxis');
    const format = process.argv[3] || 'svg';
    const preview = process.argv[4] === '--preview';
    if (process.argv[4] && !preview) throw new Error('Opzione attesa: --preview');
    const projectRoot = path.join(__dirname, '..');
    const result = await render(await fs.readFile(source, 'utf8'), [format], {
        compiler: path.join(projectRoot, 'build', 'pyxis.exe'),
        cacheDir: path.join(projectRoot, '.pyxis_cache'),
        asymptote: process.env.PYXIS_ASYMPTOTE || '',
        ghostscript: process.env.PYXIS_GHOSTSCRIPT || '', preview
    });
    const folder = path.join(projectRoot, 'output');
    await fs.mkdir(folder, { recursive: true });
    const destination = path.join(folder, `${path.basename(source, path.extname(source))}${preview ? '.preview' : ''}.${format}`);
    await fs.writeFile(destination, result[format]);
    console.log(destination);
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
