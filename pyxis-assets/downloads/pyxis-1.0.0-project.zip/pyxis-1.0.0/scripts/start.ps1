param([string]$Folder = '')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
if (!(Test-Path -LiteralPath (Join-Path $projectRoot 'build\pyxis.exe'))) { & (Join-Path $PSScriptRoot 'build.ps1') }
if (!$Folder) { $Folder = Join-Path $projectRoot 'examples' }
$folderPath = (Resolve-Path -LiteralPath $Folder).Path
$codeCommand = Get-Command code.cmd -ErrorAction SilentlyContinue
if (!$codeCommand) { throw 'VS Code non trovato nel PATH. Apri il progetto in VS Code e premi F5.' }
& $codeCommand.Source --new-window "--extensionDevelopmentPath=$projectRoot\vscode" $folderPath
if ($LASTEXITCODE -ne 0) { throw 'Avvio VS Code fallito' }
