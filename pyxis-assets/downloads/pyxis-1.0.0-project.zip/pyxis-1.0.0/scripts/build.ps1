param([string]$Compiler = 'C:\msys64\ucrt64\bin\g++.exe', [switch]$Release)
$ErrorActionPreference = 'Stop'
$env:PATH = "$(Split-Path -Parent $Compiler);$env:PATH"
$projectRoot = Split-Path -Parent $PSScriptRoot
$buildPath = Join-Path $projectRoot 'build'
New-Item -ItemType Directory -Force -Path $buildPath | Out-Null
$packageSources = @(Get-ChildItem -LiteralPath (Join-Path $projectRoot 'src/packages') -Filter '*.cpp' | ForEach-Object { $_.FullName })
$compileFlags = @('-std=c++17','-Wall','-Wextra','-Wpedantic','-static')
if ($Release) { $compileFlags += @('-O2','-s') } else { $compileFlags += '-g' }
& $Compiler @compileFlags @packageSources "${projectRoot}\src\syntax.cpp" "${projectRoot}\src\semantic.cpp" "${projectRoot}\src\layout.cpp" "${projectRoot}\src\constraints.cpp" "${projectRoot}\src\expression.cpp" "${projectRoot}\src\pyxis.cpp" "${projectRoot}\src\main.cpp" -o "${buildPath}\pyxis.exe"
if ($LASTEXITCODE -ne 0) { throw 'Compilazione Pyxis fallita' }
& $Compiler @compileFlags @packageSources "${projectRoot}\src\syntax.cpp" "${projectRoot}\src\semantic.cpp" "${projectRoot}\src\layout.cpp" "${projectRoot}\src\constraints.cpp" "${projectRoot}\src\expression.cpp" "${projectRoot}\src\pyxis.cpp" "${projectRoot}\tests\core.cpp" -I "${projectRoot}\src" -o "${buildPath}\pyxis_tests.exe"
if ($LASTEXITCODE -ne 0) { throw 'Compilazione test fallita' }
& "${buildPath}\pyxis_tests.exe"
if ($LASTEXITCODE -ne 0) { throw 'Test falliti' }
