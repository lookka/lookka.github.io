param([switch]$SkipBuild)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
if (!$SkipBuild) { & (Join-Path $PSScriptRoot 'build.ps1') -Release }
$manifest = Get-Content -LiteralPath (Join-Path $projectRoot 'vscode/package.json') -Raw | ConvertFrom-Json
$releaseFolder = Join-Path $projectRoot 'release'
New-Item -ItemType Directory -Path $releaseFolder -Force | Out-Null
$destination = Join-Path $releaseFolder ('pyxis-' + $manifest.version + '-win32-x64.vsix')
$temporaryArchive = $destination + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
Add-Type -AssemblyName System.IO.Compression
$stream = [IO.File]::Open($temporaryArchive, [IO.FileMode]::CreateNew)
$archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create)
function Add-TextEntry([string]$name, [string]$text) {
    $entry = $archive.CreateEntry($name, [IO.Compression.CompressionLevel]::Optimal)
    $writer = [IO.StreamWriter]::new($entry.Open(), [Text.UTF8Encoding]::new($false))
    try { $writer.Write($text) } finally { $writer.Dispose() }
}
function Add-FileEntry([string]$name, [string]$file) {
    $entry = $archive.CreateEntry($name, [IO.Compression.CompressionLevel]::Optimal)
    $inputFile = [IO.File]::OpenRead($file)
    $entryStream = $entry.Open()
    try { $inputFile.CopyTo($entryStream) } finally { $entryStream.Dispose(); $inputFile.Dispose() }
}
try {
    $manifest.main = './vscode/extension.js'
    $manifest.contributes.languages[0].configuration = './vscode/language-configuration.json'
    $manifest.contributes.grammars[0].path = './vscode/pyxis.tmLanguage.json'
    Add-TextEntry 'extension/package.json' ($manifest | ConvertTo-Json -Depth 30)
    foreach ($folder in @('vscode','tools/pyxis','latex','docs','examples','src','tests','scripts','assets')) {
        $absoluteFolder = Join-Path $projectRoot $folder
        foreach ($file in Get-ChildItem -LiteralPath $absoluteFolder -File -Recurse) {
            if ($file.Extension -notin '.js','.json','.md','.tex','.pyxis','.sty','.cpp','.hpp','.ps1','.svg','.png') { continue }
            $relative = $file.FullName.Substring($projectRoot.Length + 1).Replace('\','/')
            if ($relative -match '(^|/)(\.pyxis_cache|node_modules|tmp|build|output)(/|$)') { continue }
            Add-FileEntry ('extension/' + $relative) $file.FullName
        }
    }
    foreach ($name in @('README.md','LICENSE','THIRD-PARTY.md','CMakeLists.txt')) { Add-FileEntry ('extension/' + $name) (Join-Path $projectRoot $name) }
    Add-FileEntry 'extension/bin/pyxis.exe' (Join-Path $projectRoot 'build/pyxis.exe')
    $version = [Security.SecurityElement]::Escape($manifest.version)
    Add-TextEntry 'extension.vsixmanifest' @"
<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011">
  <Metadata>
    <Identity Language="en-US" Id="pyxis" Version="$version" Publisher="pyxis-local" TargetPlatform="win32-x64" />
    <DisplayName>Pyxis</DisplayName>
    <Description xml:space="preserve">Figure scientifiche semantiche e ambienti LaTeX</Description>
    <License>extension/LICENSE</License>
    <Properties><Property Id="Microsoft.VisualStudio.Code.Engine" Value="^1.90.0" /><Property Id="Microsoft.VisualStudio.Code.ExtensionKind" Value="workspace" /></Properties>
  </Metadata>
  <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code" /></Installation>
  <Dependencies />
  <Assets><Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true" /><Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true" /></Assets>
</PackageManifest>
"@
    $types = @('json','js','md','tex','pyxis','sty','cpp','hpp','ps1','exe','txt') | ForEach-Object { '<Default Extension="' + $_ + '" ContentType="application/octet-stream" />' }
    Add-TextEntry '[Content_Types].xml' ('<?xml version="1.0" encoding="utf-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="vsixmanifest" ContentType="text/xml" /><Override PartName="/extension/LICENSE" ContentType="text/plain" />' + ($types -join '') + '</Types>')
    $archive.Dispose(); $stream.Dispose()
    Move-Item -LiteralPath $temporaryArchive -Destination $destination -Force
    Write-Output $destination
} finally {
    $archive.Dispose(); $stream.Dispose()
    if (Test-Path -LiteralPath $temporaryArchive) { Remove-Item -LiteralPath $temporaryArchive -Force }
}
