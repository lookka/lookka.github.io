param([switch]$SkipBuild)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$code = Get-Command code.cmd -ErrorAction Stop
$manifest = Get-Content -LiteralPath (Join-Path $projectRoot 'vscode/package.json') -Raw | ConvertFrom-Json
$package = Join-Path $projectRoot ('release/pyxis-' + $manifest.version + '-win32-x64.vsix')
if (!$SkipBuild -or !(Test-Path -LiteralPath $package)) { & (Join-Path $PSScriptRoot 'package.ps1') -SkipBuild:$SkipBuild }
& $code.Source --install-extension $package --force
if ($LASTEXITCODE -ne 0) { throw 'Installazione VS Code fallita' }
$installedPath = (& $code.Source --locate-extension pyxis-local.pyxis | Select-Object -Last 1).Trim()
if (!$installedPath -or !(Test-Path -LiteralPath (Join-Path $installedPath 'package.json'))) { throw 'Estensione installata non trovata' }
$installedManifest = Get-Content -LiteralPath (Join-Path $installedPath 'package.json') -Raw | ConvertFrom-Json
if ($installedManifest.name -ne 'pyxis' -or $installedManifest.publisher -ne 'pyxis-local') { throw 'Cartella installata non riconosciuta' }
$runtime = @{ schema=1; asymptote=(Join-Path $projectRoot '.tools/asymptote/asy.exe'); ghostscript=(Join-Path $projectRoot '.tools/ghostscript/bin/gswin64c.exe') }
[IO.File]::WriteAllText((Join-Path $installedPath 'pyxis-runtime.json'), ($runtime | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
Write-Output 'Pyxis installato. Ricarica la finestra VS Code per usarlo.'
