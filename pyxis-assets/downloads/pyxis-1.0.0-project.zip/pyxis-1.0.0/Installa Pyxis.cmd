@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" -SkipBuild
set "PYXIS_INSTALL_RESULT=%errorlevel%"
echo.
if not "%PYXIS_INSTALL_RESULT%"=="0" echo Installazione non completata. Leggi il messaggio sopra.
pause
exit /b %PYXIS_INSTALL_RESULT%
