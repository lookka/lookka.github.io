# Pyxis 1.0

Riferimenti: [manuale dei comandi](docs/COMANDI.md), con una scheda per comando,
e [lettura del codice C++ reale](docs/CODICE-CPP.md), con motivazioni e sorgenti completi.

Pyxis e' un linguaggio per figure scientifiche, con nucleo C++ e backend Asymptote.
Sorgente `.pyxis` o ambiente LaTeX → modello semantico → scena → SVG/PDF vettoriale.
La release include estensione installabile Windows x64, nucleo C++17, quattro
pacchetti combinabili, esempi, guida d'uso e guida di sviluppo. Licenza MIT.

Apri `Installa Pyxis.cmd`, poi ricarica VS Code. La [guida rapida](docs/INIZIA-QUI.md)
spiega come creare una figura, compilarla negli appunti e usarla nei capitoli della tesi.
Nella palette trovi Pyxis: Nuova figura, Figura da esempio del corso,
Compila documento LaTeX e Guida rapida.

La 1.0 aggiunge regioni e diagrammi di fase, Ising 3D, profili di corso,
oracoli su piu' qubit, clipping dei bordi TeX, Kerr sull'asse subestremale,
coni di luce e raggi nulli Schwarzschild, vista Flamm e compilazione ricorsiva
dei capitoli con macro LaTeX condivise. Le ipotesi dei modelli sono documentate;
il programma non deriva da solo la fisica del problema.

L'incremento 0.5 aggiunge RK4 adattivo a phase-flow e Lorenz, con tolleranze
assolute/relative, limite del passo e diagnostica quando la durata richiesta
non puo' essere completata. Prova `examples/adaptive-flow.pyxis`: pendolo libero
e smorzato, disposti senza coordinate manuali. Il passo fisso resta il default.

L'incremento 0.4 introduce etichette automatiche 2D con misure reali LaTeX:
`placement: auto` sceglie fra otto direzioni, considerando testo gia' presente,
nodi, tratti e punte delle frecce. Prova `examples/auto-labels.pyxis`.
I diagrammi QFT le usano per default; `label-placement: fixed` conserva
le posizioni del modello precedente.

Per imparare a sviluppare il progetto partendo dal C++, leggi la
[guida di sviluppo](docs/GUIDA-SVILUPPO.md): pipeline, lettura del codice,
esempi eseguibili, test ed esercizi per lavorare insieme.

L'incremento 0.3 aggiunge vincoli parallel/perpendicular e tangenza fra cerchi,
clipping sulle curve reali, punti nominati invisibili e reti PEPS con connessioni
che seguono i tensori. Esempi: `examples/constraints.pyxis` e
`examples/tensor-networks.pyxis`.

## Figure semantiche e pacchetti

Ora sono disponibili quattro pacchetti combinabili: `qft`, `quantum`,
`relativity`, `statmech`. Descrivi il contenuto fisico e Pyxis calcola il layout.
Le primitive e tutti gli esempi precedenti rimangono disponibili.

```text
use qft, quantum
qft.feynman scattering {
    mediator: photon
    loop: fermion
}
quantum.circuit bell {
    q0: H, control(pair)
    q1: _, target(pair), M
}
place bell below scattering
```

Prova `./scripts/render.ps1 -Source examples/semantic.pyxis -Format pdf`.
Il [manuale dei pacchetti](docs/PACCHETTI.md) elenca sintassi e limiti effettivi.
Il catalogo dei quattro domini e' descritto nel manuale, insieme alle convenzioni
dei modelli e alle estensioni future. Le primitive restano disponibili per rifinire
le figure e costruire altri oggetti.

Gli ambienti LaTeX vengono compilati al salvataggio nell'estensione. Da terminale:

```powershell
node scripts/build-latex.js examples/semantic-notes.tex
node scripts/build-latex.js examples/thesis/main.tex
```

I sorgenti originali restano intatti. Il PDF usa il nome standard del documento;
derivati, ausiliari e log sono temporanei. Il comando precedente scripts/latex.js
rimane disponibile per ispezionare il documento derivato e il preprocessore.
La cache `.pyxis_cache` e' usata anche da script di rendering ed editor VS Code.
I cambiamenti al sorgente, al compilatore, ai moduli Asymptote e alle dipendenze
dichiarate invalidano i risultati; dettagli nel manuale.

## Avvio su questo PC

Da PowerShell nella cartella del progetto:

```powershell
./scripts/build.ps1
./scripts/install.ps1 -SkipBuild
./scripts/render.ps1
./scripts/render.ps1 -Source examples/functions.pyxis
```

GCC e' configurato in `C:/msys64/ucrt64/bin/g++.exe`; puoi passare `-Compiler` per cambiarlo.
Node.js, Asymptote e una distribuzione LaTeX devono essere disponibili. CMake e' facoltativo:
il progetto include un `CMakeLists.txt`, ma lo script diretto non ne richiede l'installazione.

## Comandi iniziali

| Comando | Significato |
| --- | --- |
| `width 100` | Larghezza finale della figura in mm |
| `circle S x y r` | Cerchio nominato, centro e raggio positivo |
| `ellipse E x y a b` | Ellisse con semiassi positivi |
| `line L x1 y1 x2 y2` | Segmento tra due estremi |
| `label T x y "$\alpha$"` | Etichetta LaTeX; nel file usa un singolo backslash |
| `move S dx dy` | Traslazione dell'oggetto nominato |
| `arrow A x1 y1 x2 y2` | Segmento con punta di freccia |
| `arrow A -2 2 S.north` | Freccia verso un punto nominato |
| `text T x y "Superficie"` | Testo normale, con caratteri TeX speciali protetti |
| `let a "0.8"` | Variabile matematica |
| `function f "a*sin(x)"` | Funzione utente a un argomento, chiamato x |
| `plot P 0 6 100 "f(x)"` | Curva y=f(x), intervallo e numero di campioni |

Una istruzione per riga; `#` introduce un commento fuori dalle etichette.
Coordinate geometriche con asse y verso l'alto; decimali con punto.
I nomi sono unici. Le etichette sono stringhe tra virgolette: virgolette interne
non ancora supportate. La larghezza riguarda l'intera figura, comprese le etichette.

I punti di linee, frecce ed etichette possono essere coordinate `x y` oppure
ancoraggi `Oggetto.nome`. Cerchi ed ellissi espongono `center`, `north`, `south`,
`east`, `west`; linee e frecce espongono `start`, `end`, `center`.
Gli ancoraggi vengono risolti sulla scena finale: seguono gli spostamenti dei bersagli.
Le dipendenze cicliche vengono rifiutate.

### Nuovi comandi di costruzione

```text
circle S                  # centro (0,0), raggio 1
circle T 2                # centro (0,0), raggio 2
ellipse E 2 1             # centro (0,0), semiassi 2 e 1
line L                    # segmento da (-0.5,0) a (0.5,0)
text title "Titolo"       # testo al centro
path P @A4 @D2 @G4        # percorso tra punti nominati
stroke P dashed           # solid, dashed oppure dotted
markers P triangle hollow 0.1
bend P 0.4                # incurva ciascun segmento
curve P 1 -2 2 0 2        # due controlli Bezier del segmento 1
symbol kite "0 1;0.6 0;0 -1;-0.6 0"
markers P kite filled 0.1 # simbolo poligonale personalizzato
```

Restano valide le forme estese con coordinate. `ellipse E` usa semiassi 1 e 0.5;
anche `arrow A` e le etichette senza coordinate sono centrati nell'origine.
Un percorso numerico puo' essere scritto `path P "-2 0;0 1;2 0"`.
Gli ancoraggi dei percorsi sono `P.start`, `P.end`, `P.node1`, `P.node2`, ecc.

La griglia e' 7x7: A-G da sinistra a destra, 1-7 dall'alto al basso, origine
`@D4`. Con passo 1, `@A1=(-3,3)` e `@G7=(3,-3)`. `grid 0.5` cambia il passo;
`grid off` la nasconde senza eliminare gli ancoraggi. Conta il passo finale
del sorgente, cosi' cambiarlo riposiziona gli oggetti agganciati.

L'export ordinario esclude sempre la griglia; la preview la include su richiesta:

```powershell
./scripts/render.ps1 -Source examples/paths.pyxis
./scripts/render.ps1 -Source examples/paths.pyxis -Preview
```

I marcatori disponibili sono circle, square, triangle, diamond, none e poligoni
definiti con `symbol`. `filled` riempie in nero; `hollow` usa un interno bianco
per coprire il tratto sottostante. La dimensione e' in unita' geometriche.
Simboli curvi e composti personalizzati sono un'estensione futura.

`bend` usa Bezier cubiche: non e' un arco circolare esatto. Mantiene gli estremi
e sposta il punto medio dell'altezza richiesta, a sinistra della direzione del
percorso. `curve` imposta controlli assoluti liberi per un segmento e non forza
continuita' di tangente al successivo. Un `bend` successivo elimina i controlli
manuali precedenti; `move` trasla anche i controlli. Tratto e marcatori rimangono
indipendenti dalla forma della curva.

Il mockup `-p-p-p` non e' ancora una sintassi implementata: i comandi espliciti
permettono di verificare geometria e marcatori prima di fissare abbreviazioni.

Le espressioni supportano `+ - * / ^`, parentesi, `pi`, `sin`, `cos`, `tan`,
`exp`, `log`, `sqrt`, `abs`. Le funzioni trigonometriche usano radianti; `log`
e' il logaritmo naturale. Potenze associate da destra; `-2^2` vale -4.
Variabili e funzioni sono disponibili dal momento della definizione; le curve
vengono campionate al comando `plot`. Un dominio non reale o un valore non finito
produce un errore. Il campionamento e' uniforme e non rileva tutte le discontinuita'.

## Come leggere il codice

1. `src/pyxis.hpp`: una scena contiene oggetti e la larghezza richiesta.
2. `src/pyxis.cpp`, `parse`: legge i comandi, verifica i parametri e costruisce la scena.
3. `src/pyxis.cpp`, `asymptote`: traduce la scena in codice del backend.
4. `src/main.cpp`: gestisce file e messaggi; non contiene la geometria.
5. `src/expression.cpp`: valuta le formule matematiche.
6. `src/semantic.cpp` e `src/packages/`: risolvono import e traducono gli oggetti fisici in primitive.
7. `src/layout.cpp`: dispone gruppi con dipendenze e controlla cicli/conflitti.
8. `vscode/backend.js`: chiama il nucleo e Asymptote in una cartella temporanea isolata, poi la elimina; `cache.js` conserva risultati verificati.
9. `tools/pyxis/latex.js`: estrae gli ambienti e prepara il documento derivato.
7. `scripts/render.ps1`: avvia la stessa pipeline usata dall'estensione.

Questo parser lineare e' intenzionalmente piccolo. Le formule hanno gia' un parser
dedicato; il linguaggio completo avra' lexer, parser e albero della sintassi
senza richiedere di riscrivere il backend.

## Funzionalita' verificate e sviluppi successivi

- [x] Oggetti nominati, validazione, traslazione, etichette e generazione Asymptote.
- [x] Test di errori, duplicati, traslazioni ed escaping LaTeX.
- [x] Espressioni, funzioni utente, curve campionate, frecce e ancoraggi di base.
- [x] Posizioni predefinite, percorsi, marcatori, simboli poligonali, Bezier e griglia di preview.
- [x] Anteprima automatica e misurazione della latenza.
- [x] Estensione VS Code con scorciatoia, editor/anteprima e inserimento LaTeX.
- [ ] Linguaggio matematico completo, cicli e sintassi stabile.
- [ ] Stili, gruppi e relazioni geometriche piu' generali.
- [x] Prime scene 3D: sfere, superfici z=f(x,y), camera ortografica, etichette.
- [x] Catalogo semantico nei quattro pacchetti di fisica, con modelli documentati.
- [x] Installazione VSIX Windows x64, licenza MIT e verifica del pacchetto installato.
- [x] Build nativa al salvataggio, input/include/includeonly, macro del preambolo e TeX root.

Le directory `build` e `output` contengono risultati rigenerabili del progetto.
Non vengono aggiunte al controllo di versione. Nessun file personale viene cancellato.

## Sviluppo dell'estensione VS Code

Apri questa cartella in VS Code, premi F5 e scegli `Pyxis: prova estensione VS Code`.
Nella nuova finestra apri una cartella con gli appunti e un file `.tex` salvato.
Premi Ctrl+Alt+F oppure esegui `Pyxis: Nuova figura` dalla palette comandi.
L'estensione presenta editor e anteprima; Invio aggiorna, Ctrl+Invio avvia il salvataggio.
`Pyxis: Modifica figura esistente` riapre un sorgente `.pyxis`.
La prima versione conserva una bozza nell'area di lavoro di VS Code.

I file delle figure sono salvati nella directory `figures` alla radice dell'area
di lavoro. I percorsi LaTeX sono riferiti a tale radice: un progetto con documento
principale in un'altra directory dovra' adattare il percorso. Serve `graphicx`.
Il salvataggio della figura e' distinto dal salvataggio del documento LaTeX.

## Stato di verifica

Il nucleo C++ compila con GCC e i test passano. Il backend locale usa Asymptote
3.15 e Ghostscript 10.08.0, conservati in `.tools`. Test della pipeline:

```powershell
node tests/backend.js
```

SVG/PDF, etichette LaTeX e scene 3D sono verificati. Gli SVG controllati non
contengono immagini raster incorporate. In 3D lo SVG deriva dal PDF tramite
`dvisvgm --pdf --no-fonts`. Un test nell'Extension Host reale ha verificato
attivazione, anteprima nella webview, salvataggio dei tre file e inserimento
LaTeX attraverso le API dell'editor. Non e' un test di ogni interazione manuale.
L'anteprima del caso di prova ha richiesto circa 1.9 secondi su questo PC.

Per configurare backend diversi usa `pyxis.asymptote` e `pyxis.ghostscript`
nell'estensione, oppure `PYXIS_ASYMPTOTE` e `PYXIS_GHOSTSCRIPT` per gli script.
Le installazioni esistenti e la configurazione globale LaTeX non sono state sostituite.

## Sorgente dichiarativo e 3D

Si possono modificare direttamente gli attributi degli oggetti; i comandi rapidi aggiornano questi blocchi.

```text
circle A {
    center: @A4
    radius: 0.2
}
line L {
    from: A.center
    to: @G4
    path: wave(0.3,3)
    markers: triangle(hollow,0.1)
    stroke-width: 0.4
}
```

Esempi completi: examples/declarative.pyxis e examples/spacetime-blocks.pyxis.
In 3D: sphere, surface, camera, label3, text3 e move3.
Una superficie usa xrange, yrange, mesh e formula in x,y; fill: none lascia solo la griglia.
Le sfere usano center, radius, detail: minimal e shading: 0.12; niente equatore.
stroke-width e' in bp, indipendente dalla geometria. camera x y z imposta la vista ortografica.
Le scene miste 2D/3D non sono ancora supportate. Lo stato preciso e' in docs/STATO.md.
